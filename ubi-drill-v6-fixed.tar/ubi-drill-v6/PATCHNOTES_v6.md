# UBI Cyber Drill v6 — Operational Patch Notes

Scope of this patch: **fix deployment / interface / functional breakage only.**
All intentionally-vulnerable behaviour is preserved unchanged. No security control
was added that would neutralise a drill scenario.

> Ransomware scenario (#5) was intentionally left **out of scope** at the operator's
> request — none of its files, code, or comments were modified, deployed, or analysed.

---

## Root causes that were fixed

### 1. PHP source disclosure / login dead / "broken" UI  *(deployment)*
**File:** `apache/ubibank.conf`
The vhost forced `SetHandler application/x-httpd-php` for all `.php`. That is the
**mod_php** handler. On RHEL/CentOS 8/9/Stream 9 PHP runs as **php-fpm** (no mod_php),
so the handler was never resolved and Apache served `.php` files as **plain text** —
producing the reported symptoms simultaneously: source code leaking in the browser,
login form posting to a non-executing page ("login doesn't work"), and a garbled UI
("frontend broken").

**Fix:** the mod_php handler is now wrapped in `<IfModule mod_php.c>` /
`mod_php7.c` / `mod_php5.c`, so it only applies where mod_php is actually loaded
(e.g. CentOS 7 + Remi). On php-fpm systems the OS-provided `/etc/httpd/conf.d/php.conf`
now routes `.php` to php-fpm correctly instead of being overridden.
Directory-listing (`+Indexes` on `/backup`), CORS headers, `ServerTokens Full`, and all
other intentional misconfigurations were left untouched.

### 2. php-fpm never started  *(deployment)*
**Files:** `00_prereq.sh`, `01_configure.sh`
On php-fpm systems the socket was never enabled/started, so even a correct handler would
return 503. Both scripts now `enable`/`(re)start` `php-fpm` **only when the unit exists**
(no-op on mod_php systems).

### 3. `get_user_account()` undefined → API 500s  *(backend functional)*
**File:** `app/includes/auth.php`
`api/v1/login.php`, `api/v1/accounts.php`, and `api/v1/transfer.php` all called
`get_user_account()`, which was **not defined anywhere** → fatal
"Call to undefined function". API login, the customer account-lookup path, and **all**
transfers failed.

**Fix:** added a single ownership-scoped helper to `auth.php`:
```php
function get_user_account($user_id) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM accounts WHERE user_id = ? AND is_active = 1 ORDER BY id LIMIT 1');
    $stmt->execute([(int)$user_id]);
    return $stmt->fetch() ?: null;
}
```
This is a normal user-scoped lookup; it is **not** an injection/BOLA path. The intended
weaknesses remain in the individual endpoints (raw concat in `accounts.php`, missing
ownership check in `statement.php`/`account.php`, etc.).

### 4. Missing `.toast` styles  *(interface, minor)*
**File:** `app/assets/css/style.css`
`assets/js/app.js` references a `showToast()` notification component that had no CSS.
Added minimal `.toast` styling for completeness.

---

## Retained vulnerabilities — verified intact after patch (8 of 9; #5 excluded)

| # | Scenario            | Entry point                                   | Verified |
|---|---------------------|-----------------------------------------------|----------|
| 1 | Mass Assignment     | `POST /api/v1/register.php` (`role` honoured) | ✓ admin self-registration |
| 2 | SQL Injection       | `GET /api/v1/accounts.php?acc_no=`            | ✓ UNION dumped users + hashes |
| 3 | IDOR                | `GET /account.php?id=` / `api/v1/account.php` | ✓ cross-user account read |
| 4 | Stored XSS + hijack | `support.php` → `admin/tickets.php` (httponly=0)| ✓ raw `<script>` reflected to admin |
| 6 | BOLA                | `GET /api/v1/statement.php?account_number=`   | ✓ cross-user statement read |
| 7 | Directory Listing   | `GET /backup/`                                | ✓ `+Indexes` + backup files present |
| 8 | Hardcoded Creds     | `config/database.php` (644) + `backup/config_backup.txt` | ✓ plaintext creds readable |
| 9 | Telnet (cleartext)  | `tcp/23`, `bankops` user, sim cron            | ✓ setup retained |

## Workflow (unchanged)
```
sudo bash 00_reset.sh        # between teams
# extract tar
sudo bash 00_prereq.sh       # first time only
sudo bash 01_configure.sh
sudo bash 02_run.sh
```

## Test accounts (unchanged)
admin / Admin@UBI2024 · priya.mehta / Priya@1234 · ankit.sharma / Ankit@Pass1 (+ other customers)
OS/Telnet: bankops / BankOps@2024
