#!/usr/bin/env bash
# =============================================================
#  UBI Cyber Drill v6 – Prerequisite Installer
#  Target: CentOS 7 / CentOS 8 / RHEL 7 / RHEL 8 / RHEL 9 / CentOS Stream 9
#  Run as root
# =============================================================
set -e
LOGFILE="/var/log/ubi_prereq.log"
exec > >(tee -a "$LOGFILE") 2>&1

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC}  $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERR]${NC} $1"; }
banner() { echo -e "\n${GREEN}══════════════════════════════════════════${NC}"; echo -e "${GREEN}  $1${NC}"; echo -e "${GREEN}══════════════════════════════════════════${NC}"; }

[ "$(id -u)" -ne 0 ] && { err "Must run as root"; exit 1; }

banner "Detecting OS..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_NAME="$ID"
    OS_VERSION="${VERSION_ID%%.*}"
    ok "Detected: $PRETTY_NAME (Version: $OS_VERSION)"
else
    err "Cannot detect OS"; exit 1
fi

detect_pkg_mgr() {
    if command -v dnf &>/dev/null; then PKG="dnf"; elif command -v yum &>/dev/null; then PKG="yum"; else err "No package manager found"; exit 1; fi
    ok "Package manager: $PKG"
}
detect_pkg_mgr

banner "Installing EPEL repository..."
if [[ "$OS_VERSION" == "7" ]]; then
    $PKG install -y epel-release 2>/dev/null || warn "EPEL may already be installed"
    $PKG install -y https://rpms.remirepo.net/enterprise/remi-release-7.rpm 2>/dev/null || warn "Remi repo may already be installed"
    yum-config-manager --enable remi-php74 2>/dev/null || true
    ok "EPEL + Remi PHP74 repo configured"
elif [[ "$OS_VERSION" == "8" ]]; then
    $PKG install -y epel-release 2>/dev/null || warn "EPEL may already be installed"
    $PKG module reset php -y 2>/dev/null || true
    $PKG module enable php:7.4 -y 2>/dev/null || true
    ok "EPEL repo configured (PHP 7.4)"
else
    $PKG install -y epel-release 2>/dev/null || warn "EPEL may already be installed"
    ok "EPEL repo configured"
fi

banner "Installing Apache + PHP + SQLite..."
PKGS_CORE="httpd php php-pdo php-mbstring php-json php-common php-cli"
$PKG install -y $PKGS_CORE || { err "Core package install failed"; exit 1; }
ok "Apache + PHP installed"

# PHP extensions
$PKG install -y php-xml php-curl 2>/dev/null || warn "Some optional PHP extensions unavailable"

banner "Installing SQLite tools..."
$PKG install -y sqlite 2>/dev/null || warn "sqlite CLI not available, will use php"
$PKG install -y sqlite-devel 2>/dev/null || true
ok "SQLite configured"

banner "Installing Telnet server..."
if [[ "$OS_VERSION" == "7" ]]; then
    $PKG install -y telnet-server xinetd || warn "Telnet install failed"
    ok "Telnet server (xinetd-based) installed"
else
    $PKG install -y telnet-server || warn "Telnet install failed"
    ok "Telnet server (systemd socket-based) installed"
fi

banner "Installing network tools..."
$PKG install -y net-tools tcpdump nmap-ncat 2>/dev/null || true
$PKG install -y lsof 2>/dev/null || true
$PKG install -y expect 2>/dev/null || true
$PKG install -y python3 python3-pip 2>/dev/null || warn "Python3 not available"
ok "Network tools installed"

banner "Installing OpenSSL (for ransomware simulation)..."
$PKG install -y openssl || warn "OpenSSL install failed"
ok "OpenSSL installed"

banner "Installing additional utilities..."
$PKG install -y curl wget unzip tar gzip bc 2>/dev/null || true
ok "Utilities installed"

banner "Enabling and starting Apache..."
systemctl enable httpd && systemctl start httpd && ok "Apache (httpd) started" || {
    warn "httpd failed to start; attempting restart..."
    systemctl restart httpd || err "Apache could not be started"
}

banner "Configuring Telnet service..."
if [[ "$OS_VERSION" == "7" ]]; then
    if [ -f /etc/xinetd.d/telnet ]; then
        sed -i 's/disable\s*=\s*yes/disable = no/' /etc/xinetd.d/telnet
        ok "Telnet enabled in xinetd"
    else
        cat > /etc/xinetd.d/telnet << 'EOF'
service telnet
{
    flags           = REUSE
    socket_type     = stream
    wait            = no
    user            = root
    server          = /usr/sbin/in.telnetd
    log_on_failure  += USERID
    disable         = no
}
EOF
        ok "Telnet xinetd config created"
    fi
    systemctl enable xinetd && systemctl restart xinetd && ok "xinetd restarted"
else
    systemctl enable telnet.socket 2>/dev/null && systemctl start telnet.socket 2>/dev/null \
        && ok "Telnet socket service enabled" \
        || warn "Telnet socket could not be started (will retry in configure)"
fi

banner "Disabling security features for drill environment..."
# Disable SELinux enforcement (needed for SQLite + web app in non-default path)
if command -v setenforce &>/dev/null; then
    setenforce 0 2>/dev/null && ok "SELinux set to Permissive" || warn "Could not set SELinux mode"
    sed -i 's/^SELINUX=enforcing/SELINUX=permissive/' /etc/selinux/config 2>/dev/null || true
    sed -i 's/^SELINUX=enabled/SELINUX=permissive/' /etc/selinux/config 2>/dev/null || true
fi

# Disable firewalld (or add rules)
if systemctl is-active firewalld &>/dev/null; then
    systemctl stop firewalld && systemctl disable firewalld \
        && ok "firewalld disabled" || warn "Could not disable firewalld"
else
    ok "firewalld not running"
fi

# Disable iptables if running
if systemctl is-active iptables &>/dev/null; then
    systemctl stop iptables && systemctl disable iptables \
        && ok "iptables disabled" || warn "Could not disable iptables"
fi

banner "Creating bankops OS user (Telnet scenario #9)..."
if ! id bankops &>/dev/null; then
    useradd -m -s /bin/bash bankops
    echo "bankops:BankOps@2024" | chpasswd
    ok "bankops user created (password: BankOps@2024)"
else
    echo "bankops:BankOps@2024" | chpasswd
    ok "bankops user already exists (password reset)"
fi

# Enable pts logins for Telnet
for pts in pts/0 pts/1 pts/2 pts/3; do
    grep -qxF "$pts" /etc/securetty 2>/dev/null || echo "$pts" >> /etc/securetty
done
ok "Telnet pts login enabled in /etc/securetty"

banner "Verifying PHP and SQLite..."
PHP_VER=$(php -r "echo PHP_VERSION;" 2>/dev/null || echo "unknown")
ok "PHP version: $PHP_VER"
php -r "new PDO('sqlite::memory:'); echo 'PDO SQLite: OK';" 2>/dev/null && echo "" || warn "PDO SQLite not working!"

echo ""
echo -e "${GREEN}══════════════════════════════════════════${NC}"
echo -e "${GREEN}  Prerequisites installed successfully!${NC}"
echo -e "${GREEN}  Next step: sudo bash 01_configure.sh${NC}"
echo -e "${GREEN}══════════════════════════════════════════${NC}"
