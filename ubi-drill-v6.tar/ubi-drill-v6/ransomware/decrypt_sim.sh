#!/bin/bash
# ================================================================
#  Union Bank of India – Cyber Drill Scenario #5
#  RANSOMWARE RECOVERY – Decrypt and restore data files
#  Usage: sudo ./decrypt_sim.sh
# ================================================================

TARGET_DIR="/var/lib/ubibank/data"
KEY_FILE="/tmp/.drill_key"
GREEN='\033[0;32m'; CYAN='\033[0;36m'; RED='\033[0;31m'; RESET='\033[0m'

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}[ERROR] Run as root: sudo ./decrypt_sim.sh${RESET}"
    exit 1
fi

if [[ ! -f "$KEY_FILE" ]]; then
    echo -e "${RED}[ERROR] Key file not found: $KEY_FILE${RESET}"
    echo "       Run ransom_sim.sh first, or locate the key manually."
    exit 1
fi

PASSPHRASE=$(cat "$KEY_FILE")
echo -e "${CYAN}[*] Starting decryption of $TARGET_DIR ...${RESET}"

DECRYPTED=0
FAILED=0

while IFS= read -r -d '' FILE; do
    ORIG="${FILE%.enc}"
    if openssl enc -aes-256-cbc -d -salt -pbkdf2 -iter 10000 \
        -in "$FILE" -out "$ORIG" -pass "pass:$PASSPHRASE" 2>/dev/null; then
        rm -f "$FILE"
        echo -e "  ${GREEN}RESTORED:${RESET} $(basename "$ORIG")"
        ((DECRYPTED++))
    else
        echo -e "  ${RED}FAILED:${RESET} $(basename "$FILE")"
        ((FAILED++))
    fi
done < <(find "$TARGET_DIR" -name "*.enc" -type f -print0)

# Remove ransom note
rm -f "${TARGET_DIR}/RANSOM_NOTE.txt"

echo ""
echo -e "${GREEN}════════════════════════════════════════════"
echo "  RECOVERY COMPLETE"
echo "  Files Restored : $DECRYPTED"
echo "  Failed         : $FAILED"
echo -e "════════════════════════════════════════════${RESET}"
echo ""

# Re-run db init to restore data files
echo -e "${CYAN}[*] Re-generating data files via db_init.php ...${RESET}"
php /var/www/html/db/db_init.php 2>/dev/null | tail -5
echo -e "${GREEN}[✓] Data restore complete.${RESET}"
