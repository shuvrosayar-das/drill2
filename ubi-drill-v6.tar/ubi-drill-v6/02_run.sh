#!/usr/bin/env bash
# =============================================================
#  UBI Cyber Drill v6 – Run / Monitor Script
#  Validates config, starts all services, monitors continuously
# =============================================================
LOGFILE="/var/log/ubi_run.log"
exec > >(tee -a "$LOGFILE") 2>&1

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; PURPLE='\033[0;35m'; NC='\033[0m'
ok()    { echo -e "${GREEN}[✓]${NC} $1"; }
fail()  { echo -e "${RED}[✗]${NC} $1"; FAIL_COUNT=$((FAIL_COUNT+1)); }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
info()  { echo -e "${CYAN}[-]${NC} $1"; }

[ "$(id -u)" -ne 0 ] && { echo -e "${RED}Must run as root${NC}"; exit 1; }

WEBROOT="/var/www/html"
DB_PATH="/var/lib/ubibank/banking.db"
INTERVAL=30
FAIL_COUNT=0

print_banner() {
cat << 'BANNER'
  ██╗   ██╗██████╗ ██╗    ██████╗██╗   ██╗██████╗ ███████╗██████╗     ██████╗ ██████╗ ██╗██╗     ██╗
  ██║   ██║██╔══██╗██║   ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗    ██╔══██╗██╔══██╗██║██║     ██║
  ██║   ██║██████╔╝██║   ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝    ██║  ██║██████╔╝██║██║     ██║
  ██║   ██║██╔══██╗██║   ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗    ██║  ██║██╔══██╗██║██║     ██║
  ╚██████╔╝██████╔╝██║   ╚██████╗   ██║   ██████╔╝███████╗██║  ██║    ██████╔╝██║  ██║██║███████╗███████╗
   ╚═════╝ ╚═════╝ ╚═╝    ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝
BANNER
echo -e "${PURPLE}  Union Bank of India — Cyber Drill v6 — Service Monitor${NC}"
echo -e "  ─────────────────────────────────────────────────────────"
}

get_ip() {
    IP=$(ip route get 8.8.8.8 2>/dev/null | awk '/src/{print $7; exit}')
    [ -z "$IP" ] && IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    [ -z "$IP" ] && IP="127.0.0.1"
    echo "$IP"
}

ensure_port_open() {
    local port=$1; local proto=${2:-tcp}
    if command -v firewall-cmd &>/dev/null && systemctl is-active firewalld &>/dev/null; then
        firewall-cmd --permanent --add-port="$port/$proto" &>/dev/null
        firewall-cmd --reload &>/dev/null
    fi
    if command -v iptables &>/dev/null; then
        iptables -I INPUT -p "$proto" --dport "$port" -j ACCEPT 2>/dev/null || true
    fi
}

check_service() {
    local svc=$1; local name=$2
    if systemctl is-active "$svc" &>/dev/null; then
        ok "$name (systemctl: $svc) is running"
        return 0
    else
        fail "$name is NOT running"
        info "Attempting to start $svc..."
        systemctl start "$svc" 2>/dev/null && ok "$svc started successfully" || warn "$svc could not be started"
        return 1
    fi
}

check_port() {
    local port=$1; local proto=${2:-tcp}; local label=$3
    if ss -tlnp 2>/dev/null | grep -q ":$port " || netstat -tlnp 2>/dev/null | grep -q ":$port "; then
        ok "Port $port/$proto ($label) is OPEN"
        return 0
    else
        warn "Port $port/$proto ($label) not open — opening..."
        ensure_port_open "$port" "$proto"
        return 1
    fi
}

check_file() {
    local path=$1; local label=$2
    [ -f "$path" ] && ok "$label exists: $path" || fail "$label MISSING: $path"
}

check_db() {
    if php -r "
        try {
            \$db = new PDO('sqlite:$DB_PATH');
            \$c = \$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
            echo 'USERS:'.\$c;
            \$a = \$db->query('SELECT COUNT(*) FROM accounts')->fetchColumn();
            echo ' ACCOUNTS:'.\$a;
        } catch(Exception \$e) { echo 'ERR:'.\$e->getMessage(); }
    " 2>/dev/null | grep -q "USERS:"; then
        DBINFO=$(php -r "
            \$db = new PDO('sqlite:$DB_PATH');
            \$u = \$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
            \$a = \$db->query('SELECT COUNT(*) FROM accounts')->fetchColumn();
            \$t = \$db->query('SELECT COUNT(*) FROM transactions')->fetchColumn();
            echo \$u.' users, '.\$a.' accounts, '.\$t.' transactions';
        " 2>/dev/null)
        ok "SQLite DB accessible — $DBINFO"
    else
        fail "SQLite DB not accessible at $DB_PATH"
    fi
}

check_vuln() {
    local label=$1; local file=$2; local pattern=$3
    if [ -f "$file" ] && grep -q "$pattern" "$file" 2>/dev/null; then
        ok "Vulnerability present: $label"
    else
        warn "Vulnerability check failed: $label — $file"
    fi
}

check_telnet() {
    local port=23
    local os_ver=$(. /etc/os-release; echo "${VERSION_ID%%.*}")
    if [[ "$os_ver" == "7" ]]; then
        systemctl is-active xinetd &>/dev/null && ok "Telnet service (xinetd) running" || {
            warn "xinetd not running, starting..."
            systemctl start xinetd 2>/dev/null && ok "xinetd started"
        }
    else
        systemctl is-active telnet.socket &>/dev/null && ok "Telnet socket service running" || {
            warn "telnet.socket not running, starting..."
            systemctl start telnet.socket 2>/dev/null && ok "telnet.socket started" || warn "Telnet socket could not start"
        }
    fi
    check_port 23 tcp "Telnet (Scenario #9)"
}

run_full_check() {
    FAIL_COUNT=0
    echo ""
    echo -e "${CYAN}┌─────────────────────────────────────────────────────────┐${NC}"
    echo -e "${CYAN}│  HEALTH CHECK: $(date '+%Y-%m-%d %H:%M:%S')${NC}"
    echo -e "${CYAN}└─────────────────────────────────────────────────────────┘${NC}"

    echo ""
    echo -e "${PURPLE}  [A] SERVICES${NC}"
    check_service httpd "Apache HTTP Server"

    echo ""
    echo -e "${PURPLE}  [B] PORTS${NC}"
    ensure_port_open 80 tcp
    check_port 80 tcp "HTTP / Banking App"
    check_telnet

    echo ""
    echo -e "${PURPLE}  [C] CRITICAL FILES${NC}"
    check_file "$WEBROOT/index.php"          "Landing page"
    check_file "$WEBROOT/login.php"          "Login page"
    check_file "$WEBROOT/dashboard.php"      "Dashboard"
    check_file "$WEBROOT/account.php"        "Account (IDOR)"
    check_file "$WEBROOT/transfer.php"       "Transfer (NEFT/RTGS)"
    check_file "$WEBROOT/support.php"        "Support (XSS)"
    check_file "$WEBROOT/admin/tickets.php"  "Admin Tickets (XSS trigger)"
    check_file "$WEBROOT/api/v1/register.php" "API Register (Mass Assignment)"
    check_file "$WEBROOT/api/v1/accounts.php" "API Accounts (SQLi)"
    check_file "$WEBROOT/api/v1/statement.php" "API Statement (BOLA)"
    check_file "$WEBROOT/config/database.php"  "Config (Hardcoded Creds)"
    check_file "$WEBROOT/backup/db_backup_20241201.sql" "DB Backup (Dir Listing)"
    check_file "$WEBROOT/backup/config_backup.txt"      "Config Backup (Creds Exposed)"
    check_file "$DB_PATH"                    "SQLite Database"

    echo ""
    echo -e "${PURPLE}  [D] DATABASE${NC}"
    check_db

    echo ""
    echo -e "${PURPLE}  [E] VULNERABILITY CONFIGURATION${NC}"
    check_vuln "#1 Mass Assignment"  "$WEBROOT/api/v1/register.php"   "role"
    check_vuln "#2 SQL Injection"    "$WEBROOT/api/v1/accounts.php"   "acc_no"
    check_vuln "#3 IDOR"             "$WEBROOT/account.php"           "IDOR"
    check_vuln "#4 Stored XSS"       "$WEBROOT/admin/tickets.php"     "XSS"
    check_vuln "#6 BOLA"             "$WEBROOT/api/v1/statement.php"  "account_number"
    check_vuln "#7 Dir Listing"      "/etc/httpd/conf.d/ubibank.conf" "Indexes"
    check_vuln "#8 Hardcoded Creds"  "$WEBROOT/config/database.php"   "DB_PASS"
    check_vuln "#9 Telnet"           "/etc/securetty"                 "pts/0"

    echo ""
    echo -e "${PURPLE}  [F] APACHE CONFIGURATION${NC}"
    if apachectl configtest 2>/dev/null | grep -q "Syntax OK" || apachectl configtest 2>&1 | grep -q "Syntax OK"; then
        ok "Apache config syntax OK"
    else
        warn "Apache config test warning (app may still work)"
    fi

    # PHP cookie config
    PHP_HTTPONLY=$(php -r "echo ini_get('session.cookie_httponly');" 2>/dev/null)
    [ "$PHP_HTTPONLY" = "0" ] || [ "$PHP_HTTPONLY" = "" ] && ok "PHP session.cookie_httponly = 0 (XSS scenario enabled)" || warn "session.cookie_httponly might block XSS demo"

    echo ""
    if [ "$FAIL_COUNT" -eq 0 ]; then
        echo -e "${GREEN}  All checks passed! ($FAIL_COUNT failures)${NC}"
    else
        echo -e "${YELLOW}  $FAIL_COUNT check(s) failed — attempting auto-remediation...${NC}"
        # Restart httpd if needed
        systemctl restart httpd 2>/dev/null || true
    fi
}

print_connection_info() {
    VM_IP=$(get_ip)
    echo ""
    echo -e "${PURPLE}╔═════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║           UNION BANK OF INDIA – CYBER DRILL v6             ║${NC}"
    echo -e "${PURPLE}║                   CONNECTION INFO                          ║${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║${NC}  VM IP Address : ${GREEN}$VM_IP${NC}"
    echo -e "${PURPLE}║${NC}  Banking App   : ${CYAN}http://$VM_IP/${NC}"
    echo -e "${PURPLE}║${NC}  REST API Base : ${CYAN}http://$VM_IP/api/v1/${NC}"
    echo -e "${PURPLE}║${NC}  Telnet        : ${CYAN}telnet $VM_IP 23${NC}"
    echo -e "${PURPLE}║${NC}  Backup Dir    : ${CYAN}http://$VM_IP/backup/${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║           TEST ACCOUNTS (WEB + API)                        ║${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║${NC}  admin         / Admin@UBI2024    (role: admin)${NC}"
    echo -e "${PURPLE}║${NC}  priya.mehta   / Priya@1234       (role: banker)${NC}"
    echo -e "${PURPLE}║${NC}  rajan.sinha   / Rajan@1234       (role: banker)${NC}"
    echo -e "${PURPLE}║${NC}  ankit.sharma  / Ankit@Pass1      (role: customer, acc: UBI400012345678)${NC}"
    echo -e "${PURPLE}║${NC}  sunita.verma  / Sunita@Pass1     (role: customer, acc: UBI400023456789)${NC}"
    echo -e "${PURPLE}║${NC}  rajesh.kumar  / Rajesh@Pass1     (role: customer, acc: UBI400034567890)${NC}"
    echo -e "${PURPLE}║${NC}  neha.singh    / Neha@Pass1       (role: customer, acc: UBI400045678901)${NC}"
    echo -e "${PURPLE}║${NC}  vikram.patel  / Vikram@Pass1     (role: customer, acc: UBI400056789012)${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║           OS USER (TELNET SCENARIO #9)                     ║${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║${NC}  bankops / BankOps@2024  (Linux OS user for Telnet drill)${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║           ATTACK SCENARIOS                                 ║${NC}"
    echo -e "${PURPLE}╠═════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${PURPLE}║${NC}  #1 Mass Assignment  → POST $VM_IP/api/v1/register.php${NC}"
    echo -e "${PURPLE}║${NC}  #2 SQL Injection    → GET  $VM_IP/api/v1/accounts.php?acc_no=...${NC}"
    echo -e "${PURPLE}║${NC}  #3 IDOR             → GET  $VM_IP/account.php?id=2${NC}"
    echo -e "${PURPLE}║${NC}  #4 Stored XSS+BeEF  → POST $VM_IP/support.php (then admin views)${NC}"
    echo -e "${PURPLE}║${NC}  #5 Ransomware       → bash exploits/05_ransomware.sh${NC}"
    echo -e "${PURPLE}║${NC}  #6 BOLA             → GET  $VM_IP/api/v1/statement.php?account_number=...${NC}"
    echo -e "${PURPLE}║${NC}  #7 Dir Listing      → GET  $VM_IP/backup/${NC}"
    echo -e "${PURPLE}║${NC}  #8 Hardcoded Creds  → SSH/Telnet → cat /var/www/html/config/database.php${NC}"
    echo -e "${PURPLE}║${NC}  #9 Telnet Intercept → tcpdump -i eth0 -A port 23 (from attacker)${NC}"
    echo -e "${PURPLE}╚═════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ─── Main ───
clear
print_banner
print_connection_info

echo -e "${CYAN}Starting continuous monitoring (every ${INTERVAL}s). Press Ctrl+C to stop.${NC}"
echo ""

run_full_check

while true; do
    sleep "$INTERVAL"
    run_full_check
done
