<?php
// ================================================================
//  Union Bank of India – Database Initialisation Script
//  Run via CLI: php /var/www/html/db/db_init.php
//  DO NOT expose this file via web
// ================================================================
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    die("Forbidden\n");
}

define('DB_PATH', '/var/lib/ubibank/banking.db');
define('DATA_DIR', '/var/lib/ubibank/data');

function log_msg($msg) { echo date('[H:i:s] ') . $msg . "\n"; }

// ── Create DB directory if needed ──────────────────
if (!is_dir(dirname(DB_PATH))) {
    mkdir(dirname(DB_PATH), 0755, true);
    log_msg("Created directory: " . dirname(DB_PATH));
}
if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
    log_msg("Created directory: " . DATA_DIR);
}

// ── Connect ────────────────────────────────────────
try {
    $db = new PDO('sqlite:' . DB_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('PRAGMA foreign_keys = ON');
    $db->exec('PRAGMA journal_mode = WAL');
    log_msg("Connected to SQLite: " . DB_PATH);
} catch (Exception $e) {
    die("DB Error: " . $e->getMessage() . "\n");
}

// ── Schema ─────────────────────────────────────────
$db->exec("
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL,
    full_name   TEXT NOT NULL,
    email       TEXT,
    phone       TEXT,
    pan         TEXT,
    aadhaar     TEXT,
    role        TEXT NOT NULL DEFAULT 'customer',
    is_active   INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT DEFAULT (datetime('now')),
    last_login  TEXT
);

CREATE TABLE IF NOT EXISTS accounts (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id),
    account_number TEXT UNIQUE NOT NULL,
    account_type   TEXT NOT NULL DEFAULT 'SAVINGS',
    branch_code    TEXT DEFAULT 'UBIMUM001',
    ifsc           TEXT DEFAULT 'UBIN0800001',
    balance        REAL NOT NULL DEFAULT 0.0,
    currency       TEXT DEFAULT 'INR',
    is_active      INTEGER DEFAULT 1,
    created_at     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id      INTEGER NOT NULL REFERENCES accounts(id),
    txn_id          TEXT UNIQUE NOT NULL,
    txn_type        TEXT NOT NULL,
    amount          REAL NOT NULL,
    direction       TEXT NOT NULL,
    description     TEXT,
    beneficiary     TEXT,
    beneficiary_acc TEXT,
    status          TEXT DEFAULT 'SUCCESS',
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id),
    session_token TEXT UNIQUE NOT NULL,
    expires_at    TEXT NOT NULL,
    ip_address    TEXT,
    created_at    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS support_tickets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(id),
    username   TEXT,
    subject    TEXT NOT NULL,
    message    TEXT NOT NULL,
    status     TEXT DEFAULT 'open',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS kyc (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER UNIQUE NOT NULL REFERENCES users(id),
    dob          TEXT,
    gender       TEXT,
    address      TEXT,
    city         TEXT,
    state        TEXT,
    pincode      TEXT,
    occupation   TEXT,
    income_range TEXT,
    nominee_name TEXT,
    kyc_status   TEXT DEFAULT 'VERIFIED',
    updated_at   TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transfers (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    from_account    TEXT NOT NULL,
    to_account      TEXT NOT NULL,
    beneficiary     TEXT,
    amount          REAL NOT NULL,
    txn_type        TEXT DEFAULT 'NEFT',
    remarks         TEXT,
    status          TEXT DEFAULT 'SUCCESS',
    initiated_by    INTEGER,
    created_at      TEXT DEFAULT (datetime('now'))
);
");

log_msg("Schema created.");

// ── Clear existing data for idempotent re-run ──────
$db->exec("DELETE FROM transfers; DELETE FROM support_tickets; DELETE FROM transactions; DELETE FROM sessions; DELETE FROM kyc; DELETE FROM accounts; DELETE FROM users;");
// Reset AUTOINCREMENT counters — ensures user_ids always start at 1 on every re-run
$db->exec("DELETE FROM sqlite_sequence WHERE name IN ('users','accounts','transactions','sessions','kyc','support_tickets','transfers');");
log_msg("Cleared existing data.");

// ── Users ──────────────────────────────────────────
$users = [
    ['admin',         password_hash('Admin@UBI2024',  PASSWORD_DEFAULT), 'System Administrator',    'admin@unibank.in',         '9000000001', 'AAAPA1234A', '1234-5678-9101', 'admin'],
    ['priya.mehta',   password_hash('Priya@1234',     PASSWORD_DEFAULT), 'Priya Mehta',             'priya.mehta@unibank.in',   '9100000001', 'BBBPM5678B', '2345-6789-0123', 'banker'],
    ['rajan.sinha',   password_hash('Rajan@1234',     PASSWORD_DEFAULT), 'Rajan Sinha',             'rajan.sinha@unibank.in',   '9100000002', 'CCCRS9012C', '3456-7890-1234', 'banker'],
    ['ankit.sharma',  password_hash('Ankit@Pass1',    PASSWORD_DEFAULT), 'Ankit Sharma',            'ankit.sharma@gmail.com',   '9811223344', 'DDGAS1234D', '4567-8901-2345', 'customer'],
    ['sunita.verma',  password_hash('Sunita@Pass1',   PASSWORD_DEFAULT), 'Sunita Verma',            'sunita.verma@gmail.com',   '9822334455', 'EEGSV5678E', '5678-9012-3456', 'customer'],
    ['rajesh.kumar',  password_hash('Rajesh@Pass1',   PASSWORD_DEFAULT), 'Rajesh Kumar',            'rajesh.kumar@yahoo.com',   '9833445566', 'FFGRK9012F', '6789-0123-4567', 'customer'],
    ['neha.singh',    password_hash('Neha@Pass1',     PASSWORD_DEFAULT), 'Neha Singh',              'neha.singh@yahoo.com',     '9844556677', 'GGGNS1234G', '7890-1234-5678', 'customer'],
    ['vikram.patel',  password_hash('Vikram@Pass1',   PASSWORD_DEFAULT), 'Vikram Patel',            'vikram.patel@gmail.com',   '9855667788', 'HHHVP5678H', '8901-2345-6789', 'customer'],
    ['deepa.nair',    password_hash('Deepa@Pass1',    PASSWORD_DEFAULT), 'Deepa Nair',              'deepa.nair@gmail.com',     '9866778899', 'IIIGN1234I', '9012-3456-7890', 'customer'],
    ['karthik.rao',   password_hash('Karthik@Pass1',  PASSWORD_DEFAULT), 'Karthik Rao',             'karthik.rao@gmail.com',    '9877889900', 'JJJKR5678J', '0123-4567-8901', 'customer'],
];

$stmt = $db->prepare("INSERT INTO users (username, password, full_name, email, phone, pan, aadhaar, role) VALUES (?,?,?,?,?,?,?,?)");
foreach ($users as $u) { $stmt->execute($u); }
log_msg("Inserted " . count($users) . " users.");

// ── Accounts ───────────────────────────────────────
// user_id starts at 1; admin/bankers don't have accounts
$accounts = [
    // [user_id, account_number, type, balance]
    [4,  'UBI400012345678', 'SAVINGS',  125430.75],
    [5,  'UBI400023456789', 'SAVINGS',   87650.00],
    [6,  'UBI400034567890', 'SAVINGS',  342100.50],
    [7,  'UBI400045678901', 'SAVINGS',   55200.00],
    [8,  'UBI400056789012', 'SAVINGS',  210800.25],
    [9,  'UBI400067890123', 'SAVINGS',   98400.00],
    [10, 'UBI400078901234', 'SAVINGS',  175600.80],
];

$stmt = $db->prepare("INSERT INTO accounts (user_id, account_number, account_type, balance) VALUES (?,?,?,?)");
foreach ($accounts as $a) { $stmt->execute($a); }
log_msg("Inserted " . count($accounts) . " accounts.");

// ── Transactions ───────────────────────────────────
function txn_id() { return 'UBI' . date('Ymd') . strtoupper(bin2hex(random_bytes(4))); }

$raw_txns = [
    // account_id, type, amount, direction, description, beneficiary, ben_acc, date_offset_days
    [1, 'NEFT', 15000.00, 'DEBIT',  'NEFT to HDFC - Rent Payment',          'Landlord Mumbai',    'HDFC0009876543', -45],
    [1, 'ATM',   5000.00, 'DEBIT',  'ATM Cash Withdrawal - Andheri Branch',  null, null, -40],
    [1, 'NEFT', 50000.00, 'CREDIT', 'Salary Credit - TCS Ltd',               null, null, -35],
    [1, 'UPI',   2500.00, 'DEBIT',  'UPI - Swiggy Order',                    'Swiggy', null, -30],
    [1, 'IMPS',  8000.00, 'DEBIT',  'IMPS - Insurance Premium LIC',          'LIC India', 'SBIN0000LIC001', -25],
    [1, 'NEFT', 50000.00, 'CREDIT', 'Salary Credit - TCS Ltd',               null, null, -5],
    [1, 'RTGS', 25000.00, 'DEBIT',  'RTGS - Home Loan EMI SBI',              'State Bank of India', 'SBIN0HOME001', -3],
    [1, 'UPI',   1200.00, 'DEBIT',  'UPI - BigBasket Grocery',               'BigBasket', null, -1],

    [2, 'NEFT', 35000.00, 'CREDIT', 'Salary Credit - Infosys BPO',          null, null, -35],
    [2, 'ATM',  10000.00, 'DEBIT',  'ATM Withdrawal - Pune Branch',         null, null, -30],
    [2, 'NEFT',  5000.00, 'DEBIT',  'NEFT - Mutual Fund SIP HDFC',          'HDFC MF', 'HDFC0000MF001', -25],
    [2, 'UPI',   3500.00, 'DEBIT',  'UPI - Amazon Shopping',                'Amazon', null, -20],
    [2, 'NEFT', 35000.00, 'CREDIT', 'Salary Credit - Infosys BPO',          null, null, -5],
    [2, 'UPI',    800.00, 'DEBIT',  'UPI - Zomato Food Order',              'Zomato', null, -2],

    [3, 'RTGS',250000.00, 'CREDIT', 'RTGS Receipt - Property Sale Proceeds',null, null, -60],
    [3, 'NEFT', 18000.00, 'DEBIT',  'NEFT - Car Loan EMI ICICI',            'ICICI Bank', 'ICIC0CARLOAN', -30],
    [3, 'ATM',  20000.00, 'DEBIT',  'ATM Withdrawal',                       null, null, -25],
    [3, 'NEFT', 75000.00, 'CREDIT', 'Salary - Director Renumeration',       null, null, -5],

    [4, 'NEFT', 20000.00, 'CREDIT', 'Salary - Wipro Technologies',          null, null, -35],
    [4, 'UPI',   1500.00, 'DEBIT',  'UPI - PhonePe Recharge',               'Jio', null, -28],
    [4, 'NEFT', 20000.00, 'CREDIT', 'Salary - Wipro Technologies',          null, null, -5],

    [5, 'NEFT', 45000.00, 'CREDIT', 'Salary - Reliance Industries',         null, null, -35],
    [5, 'NEFT', 15000.00, 'DEBIT',  'NEFT - Home Loan EMI',                 'HDFC Bank', 'HDFC0HOME002', -20],
    [5, 'IMPS', 12000.00, 'DEBIT',  'IMPS - Credit Card Bill Payment',      'Axis Bank', 'UTIB0CC001', -10],
    [5, 'NEFT', 45000.00, 'CREDIT', 'Salary - Reliance Industries',         null, null, -5],
];

$stmt = $db->prepare("INSERT INTO transactions (account_id, txn_id, txn_type, amount, direction, description, beneficiary, beneficiary_acc, created_at)
                      VALUES (?,?,?,?,?,?,?,?, datetime('now', ? || ' days'))");
foreach ($raw_txns as $t) {
    $stmt->execute([$t[0], txn_id(), $t[1], $t[2], $t[3], $t[4], $t[5] ?? null, $t[6] ?? null, (string)$t[7]]);
}
log_msg("Inserted " . count($raw_txns) . " transactions.");

// ── KYC Records ────────────────────────────────────
$kyc_data = [
    [4,  '1992-05-14', 'Male',   'A-204 Shyam Nagar, Andheri West',        'Mumbai',     'Maharashtra', '400058', 'Software Engineer', '5-10 LPA',  'Sunita Sharma'],
    [5,  '1990-11-22', 'Female', 'B-12 Koregaon Park, Sector 6',           'Pune',       'Maharashtra', '411001', 'Teacher',           '3-5 LPA',   'Ramesh Verma'],
    [6,  '1985-07-08', 'Male',   'Plot 45 Jubilee Hills, Road 10',         'Hyderabad',  'Telangana',   '500033', 'Business',          '20+ LPA',   'Meena Kumar'],
    [7,  '1995-03-30', 'Female', 'C-56 Salt Lake, Sector III',             'Kolkata',    'West Bengal', '700091', 'HR Executive',      '3-5 LPA',   'Suresh Singh'],
    [8,  '1988-09-17', 'Male',   '22 Navrangpura, Near Gujarat High Court','Ahmedabad',  'Gujarat',     '380009', 'Chartered Accountant','15-20 LPA','Mona Patel'],
    [9,  '1993-01-25', 'Female', 'T-7 Panchavati Colony, Boat Club Road',  'Pune',       'Maharashtra', '411001', 'Nurse',             '3-5 LPA',   'Ajay Nair'],
    [10, '1987-06-12', 'Male',   '88 Anna Salai, Near Spencer Plaza',      'Chennai',    'Tamil Nadu',  '600002', 'Systems Analyst',   '10-15 LPA', 'Kavitha Rao'],
];

$stmt = $db->prepare("INSERT INTO kyc (user_id, dob, gender, address, city, state, pincode, occupation, income_range, nominee_name) VALUES (?,?,?,?,?,?,?,?,?,?)");
foreach ($kyc_data as $k) { $stmt->execute($k); }
log_msg("Inserted " . count($kyc_data) . " KYC records.");

// ── Support Tickets (some contain XSS payload for demo) ──
$tickets = [
    [4, 'ankit.sharma', 'Net Banking Login Issue', 'I am unable to login to net banking since yesterday evening. Getting invalid credentials error even after resetting.', 'open'],
    [5, 'sunita.verma', 'Passbook Update Request', 'Please update my passbook entries for the last 3 months. I visited the branch but the machine was offline.', 'resolved'],
    [6, 'rajesh.kumar', 'NEFT Transaction Delayed', 'I initiated a NEFT transfer of Rs 50,000 on 2024-11-28 but it has not been credited to the beneficiary. Reference: UBI20241128XYZ. Please investigate urgently.', 'open'],
    [7, 'neha.singh',   'Debit Card Replacement', 'My debit card was lost. Please block the existing card ending 4521 and issue a new one to my registered address.', 'open'],
    [8, 'vikram.patel', 'FD Maturity Enquiry', 'Could you please share the maturity amount for FD No. UBI-FD-2021-7788 which is due in January 2025?', 'resolved'],
];

$stmt = $db->prepare("INSERT INTO support_tickets (user_id, username, subject, message, status) VALUES (?,?,?,?,?)");
foreach ($tickets as $tk) { $stmt->execute($tk); }
log_msg("Inserted " . count($tickets) . " support tickets.");

// ── Data Files for Ransomware Target ───────────────
$customers_csv = "CustomerID,FullName,AccountNumber,DOB,PAN,Aadhaar,Address,City,State,Balance\n";
$csv_users = [
    ['CIF001', 'Ankit Sharma',   'UBI400012345678', '1992-05-14', 'DDGAS1234D', '4567-8901-2345', 'A-204 Shyam Nagar Andheri West', 'Mumbai',    'Maharashtra', '125430.75'],
    ['CIF002', 'Sunita Verma',   'UBI400023456789', '1990-11-22', 'EEGSV5678E', '5678-9012-3456', 'B-12 Koregaon Park Sector 6',    'Pune',      'Maharashtra', '87650.00'],
    ['CIF003', 'Rajesh Kumar',   'UBI400034567890', '1985-07-08', 'FFGRK9012F', '6789-0123-4567', 'Plot 45 Jubilee Hills Road 10',  'Hyderabad', 'Telangana',   '342100.50'],
    ['CIF004', 'Neha Singh',     'UBI400045678901', '1995-03-30', 'GGGNS1234G', '7890-1234-5678', 'C-56 Salt Lake Sector III',      'Kolkata',   'West Bengal', '55200.00'],
    ['CIF005', 'Vikram Patel',   'UBI400056789012', '1988-09-17', 'HHHVP5678H', '8901-2345-6789', '22 Navrangpura Near High Court', 'Ahmedabad', 'Gujarat',     '210800.25'],
    ['CIF006', 'Deepa Nair',     'UBI400067890123', '1993-01-25', 'IIIGN1234I', '9012-3456-7890', 'T-7 Panchavati Colony',          'Pune',      'Maharashtra', '98400.00'],
    ['CIF007', 'Karthik Rao',    'UBI400078901234', '1987-06-12', 'JJJKR5678J', '0123-4567-8901', '88 Anna Salai Spencer Plaza',    'Chennai',   'Tamil Nadu',  '175600.80'],
];
foreach ($csv_users as $cu) { $customers_csv .= implode(',', $cu) . "\n"; }
file_put_contents(DATA_DIR . '/customers.csv', $customers_csv);

$txn_csv = "TxnID,AccountNumber,Date,Type,Amount,Direction,Description,Status\n";
$txn_lines = [
    ['UBITXN001','UBI400012345678','2024-10-15','NEFT','15000.00','DEBIT','NEFT to HDFC - Rent Payment','SUCCESS'],
    ['UBITXN002','UBI400012345678','2024-10-20','ATM','5000.00','DEBIT','ATM Cash Withdrawal','SUCCESS'],
    ['UBITXN003','UBI400012345678','2024-11-01','NEFT','50000.00','CREDIT','Salary Credit - TCS Ltd','SUCCESS'],
    ['UBITXN004','UBI400023456789','2024-10-18','NEFT','35000.00','CREDIT','Salary Credit - Infosys','SUCCESS'],
    ['UBITXN005','UBI400034567890','2024-09-01','RTGS','250000.00','CREDIT','Property Sale Proceeds','SUCCESS'],
    ['UBITXN006','UBI400056789012','2024-10-05','NEFT','45000.00','CREDIT','Salary - Reliance Industries','SUCCESS'],
    ['UBITXN007','UBI400056789012','2024-10-20','NEFT','15000.00','DEBIT','Home Loan EMI HDFC','SUCCESS'],
    ['UBITXN008','UBI400045678901','2024-10-30','NEFT','20000.00','CREDIT','Salary - Wipro Technologies','SUCCESS'],
];
foreach ($txn_lines as $tl) { $txn_csv .= implode(',', $tl) . "\n"; }
file_put_contents(DATA_DIR . '/transactions.csv', $txn_csv);

$cbs_conf = <<<EOC
# Union Bank of India - Core Banking System Configuration
# CBS Interface Config - RESTRICTED - DO NOT DISTRIBUTE
# Version: 6.2.1 | Environment: PRODUCTION

[CBS_CONNECTION]
host=cbs-internal.unibank.in
port=8443
protocol=HTTPS/TLS1.2
connection_timeout=30
max_retries=3

[AUTHENTICATION]
service_account=ubi_cbs_svc_account
service_password=CBSService@UBI2024#ProdInternal
api_key=ubiMasterApiKey2024\$ecure#DoNotShare
mfa_bypass_token=UBI_MFA_BYPASS_2024_XYZ

[DATABASE]
primary_host=10.10.10.50
replica_host=10.10.10.51
port=1521
sid=UBIPROD
username=ubi_reporting_svc
password=UBIReport@Prod2024!Conf

[ENCRYPTION]
master_key=UBIBankEncKey@2024#Prod!ConfidentialXYZ
key_rotation_days=365
algorithm=AES-256-CBC

[SMTP_ALERTS]
host=smtp.unibank.in
port=587
username=alerts@unibank.in
password=SmtpAlert@UBI2024!

[SWIFT]
bic_code=UBININBB
swift_password=SWIFT@UBI2024Prod#Secret
correspondent_bank=DEUTDEFF

[AUDIT]
log_level=INFO
log_path=/var/log/ubibank/cbs_audit.log
siem_endpoint=https://siem.unibank.in/api/v2/ingest
EOC;
file_put_contents(DATA_DIR . '/cbsconfig.conf', $cbs_conf);
file_put_contents(DATA_DIR . '/neft_batch_20241201.dat',
    "UBINEFT|BATCH|20241201|1200|RECORDS=2500\n" .
    str_repeat("UBINEFT|TXN|UBI4000XXXXX|BENEFICIARY_ACC|15000.00|PROCESSING\n", 10)
);
file_put_contents(DATA_DIR . '/rtgs_settlement_20241201.dat',
    "RTGS|SETTLEMENT|UBI|20241201|TOTAL=125000000.00\n" .
    "RTGS|RBI-REF|20241201-RTGS-00001|STATUS=SETTLED\n"
);
log_msg("Created data files in " . DATA_DIR);

// ── Backup files for dir listing vuln #7 ───────────
$backup_dir = '/var/www/html/backup';
if (!is_dir($backup_dir)) { mkdir($backup_dir, 0755, true); }

$sql_dump = <<<EOD
-- ============================================================
-- Union Bank of India - Database Backup
-- Generated: 2024-12-01 02:30:00 IST
-- Server: ubi-prod-db-01 | DB: banking.db (SQLite)
-- Classification: CONFIDENTIAL - RBI DATA PROTECTION APPLICABLE
-- ============================================================

-- Table: users
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, full_name TEXT, email TEXT, phone TEXT, pan TEXT, aadhaar TEXT, role TEXT, is_active INTEGER);

INSERT INTO users VALUES(1,'admin','Admin@UBI2024','System Administrator','admin@unibank.in','9000000001','AAAPA1234A','1234-5678-9101','admin',1);
INSERT INTO users VALUES(4,'ankit.sharma','Ankit@Pass1','Ankit Sharma','ankit.sharma@gmail.com','9811223344','DDGAS1234D','4567-8901-2345','customer',1);
INSERT INTO users VALUES(5,'sunita.verma','Sunita@Pass1','Sunita Verma','sunita.verma@gmail.com','9822334455','EEGSV5678E','5678-9012-3456','customer',1);
INSERT INTO users VALUES(6,'rajesh.kumar','Rajesh@Pass1','Rajesh Kumar','rajesh.kumar@yahoo.com','9833445566','FFGRK9012F','6789-0123-4567','customer',1);
INSERT INTO users VALUES(7,'neha.singh','Neha@Pass1','Neha Singh','neha.singh@yahoo.com','9844556677','GGGNS1234G','7890-1234-5678','customer',1);
INSERT INTO users VALUES(8,'vikram.patel','Vikram@Pass1','Vikram Patel','vikram.patel@gmail.com','9855667788','HHHVP5678H','8901-2345-6789','customer',1);

-- Table: accounts
CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, account_number TEXT, account_type TEXT, balance REAL);

INSERT INTO accounts VALUES(1,4,'UBI400012345678','SAVINGS',125430.75);
INSERT INTO accounts VALUES(2,5,'UBI400023456789','SAVINGS',87650.00);
INSERT INTO accounts VALUES(3,6,'UBI400034567890','SAVINGS',342100.50);
INSERT INTO accounts VALUES(4,7,'UBI400045678901','SAVINGS',55200.00);
INSERT INTO accounts VALUES(5,8,'UBI400056789012','SAVINGS',210800.25);

-- Table: kyc (PII Data - DPDP Act Protected)
CREATE TABLE IF NOT EXISTS kyc (user_id INTEGER, dob TEXT, gender TEXT, address TEXT, pan TEXT, aadhaar TEXT);

INSERT INTO kyc VALUES(4,'1992-05-14','Male','A-204 Shyam Nagar Andheri West Mumbai','DDGAS1234D','4567-8901-2345');
INSERT INTO kyc VALUES(5,'1990-11-22','Female','B-12 Koregaon Park Pune','EEGSV5678E','5678-9012-3456');
INSERT INTO kyc VALUES(6,'1985-07-08','Male','Plot 45 Jubilee Hills Hyderabad','FFGRK9012F','6789-0123-4567');

-- END OF BACKUP
EOD;
file_put_contents($backup_dir . '/db_backup_20241201.sql', $sql_dump);

$config_bak = <<<EOC
# ============================================================
# Union Bank of India - Configuration Backup
# Date: 2024-12-01 | Server: ubi-prod-web-01
# ============================================================

[database]
db_path=/var/lib/ubibank/banking.db
db_user=ubibank_admin
db_pass=UBI@BankDB#Secure2024!
db_admin_pin=4721

[app_secrets]
app_secret=UBI_JWT_SECRET_KEY_2024_PROD_XYZ123!@#
encryption_key=UBIBankEncKey@2024#Prod!ConfidentialXYZ
api_master_key=ubiMasterApiKey2024\$ecure#DoNotShare
session_secret=UBI_SESSION_SIGNING_KEY_PROD_2024

[legacy_cbs]
cbs_host=cbs-internal.unibank.in
cbs_user=ubi_cbs_svc_account
cbs_pass=CBSService@UBI2024#ProdInternal

[reporting_db]
mysql_host=10.10.10.50
mysql_user=ubi_reporting_svc
mysql_pass=UBIReport@Prod2024!Conf

[smtp]
smtp_host=smtp.unibank.in
smtp_user=alerts@unibank.in
smtp_pass=SmtpAlert@UBI2024!

[admin]
admin_user=admin
admin_pass=Admin@UBI2024
EOC;
file_put_contents($backup_dir . '/config_backup.txt', $config_bak);
// Intentionally no .htaccess or Options -Indexes (vuln #7 - directory listing enabled by Apache conf)
log_msg("Created backup files in " . $backup_dir);

// ── Done ───────────────────────────────────────────
log_msg("========================================");
log_msg("DB initialisation COMPLETE.");
log_msg("DB Path: " . DB_PATH);
log_msg("Users created: " . count($users));
log_msg("Accounts: " . count($accounts));
log_msg("Transactions: " . count($raw_txns));
log_msg("========================================");
echo "\n";
echo "  CREDENTIALS SUMMARY\n";
echo "  ─────────────────────────────────────────────────\n";
echo "  ADMIN  : admin             / Admin\@UBI2024\n";
echo "  BANKER : priya.mehta       / Priya\@1234\n";
echo "  BANKER : rajan.sinha       / Rajan\@1234\n";
echo "  CUST   : ankit.sharma      / Ankit\@Pass1   Acc: UBI400012345678\n";
echo "  CUST   : sunita.verma      / Sunita\@Pass1  Acc: UBI400023456789\n";
echo "  CUST   : rajesh.kumar      / Rajesh\@Pass1  Acc: UBI400034567890\n";
echo "  CUST   : neha.singh        / Neha\@Pass1    Acc: UBI400045678901\n";
echo "  CUST   : vikram.patel      / Vikram\@Pass1  Acc: UBI400056789012\n";
echo "  OS(Telnet): bankops        / BankOps\@2024\n";
echo "  ─────────────────────────────────────────────────\n\n";
