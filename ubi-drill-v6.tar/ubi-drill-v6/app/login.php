<?php
/**
 * login.php – Union Bank of India Internet Banking
 * Handles both login (POST) and registration tab (?register=1)
 * VULNERABLE: register API passes role field – mass assignment (#1)
 */
require_once '/var/www/html/includes/auth.php';
session_init();

// Already logged in – bounce to appropriate dashboard
if (is_logged_in()) {
    $r = in_array($_SESSION['role'], ['admin','banker']) ? '/admin/index.php' : '/dashboard.php';
    header('Location: ' . $r); exit;
}

$error        = '';
$success      = '';
$show_register = (isset($_GET['tab']) && $_GET['tab'] === 'register');

// ── Handle login form submission ───────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    if ($u === '' || $p === '') {
        $error = 'Please enter both username and password.';
    } else {
        $user = login_user($u, $p);
        if ($user) {
            $redirect = in_array($user['role'], ['admin','banker']) ? '/admin/index.php' : '/dashboard.php';
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid username or password. Please try again.';
        }
    }
}

// Pre-fill username safely in a PHP variable (never embed <?php ?> inside HTML attributes)
$prefill_username = htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In - Union Bank of India</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="login-page">

<!-- Top bar -->
<div class="top-bar">
    <div>&#9742; Toll Free: <strong>1800-22-2244</strong> &nbsp;|&nbsp; <strong>1800-208-2244</strong></div>
    <div>Internet Banking Portal v6 &nbsp;|&nbsp; <a href="#">User Guide</a> &nbsp;|&nbsp; <a href="#">Contact IT</a></div>
</div>

<!-- Header -->
<div class="header">
    <div class="logo-section">
        <div class="logo-icon">UB</div>
        <div class="bank-name">
            <h1>Union Bank of India</h1>
            <p>Good People to Bank With</p>
        </div>
    </div>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>

<!-- Notice ticker -->
<div class="notice-bar">
    <marquee behavior="scroll" direction="left" scrollamount="3">
        &#9888; Security Notice: UBI will NEVER ask for your PIN, OTP, or Password over call, SMS, or email.
        &nbsp;|&nbsp; NEFT/RTGS now available 24x7 including Sundays and holidays.
        &nbsp;|&nbsp; System maintenance: Sunday 00:00-04:00 IST.
    </marquee>
</div>

<main class="main-content">
<div class="login-wrap">

    <!-- Left info panel -->
    <div class="login-info">
        <h2>Welcome to<br>Internet Banking</h2>
        <p>Secure access to account management, fund transfers, and more — anytime, anywhere.</p>
        <ul>
            <li>Account Management &amp; Enquiry</li>
            <li>NEFT / RTGS / IMPS Fund Transfer</li>
            <li>Real-time Account Statements</li>
            <li>Bill Payments &amp; Recharges</li>
            <li>Transaction History &amp; Reports</li>
            <li>Loan Enquiry &amp; Servicing</li>
        </ul>
        <div class="security-note">
            &#128274; This system is for authorized customers only. All activities are monitored and logged.
        </div>
    </div>

    <!-- Right panel: login OR register tab -->
    <div class="login-form">

        <!-- TAB switcher -->
        <div style="display:flex;border-bottom:2px solid var(--border);margin-bottom:22px;">
            <a href="/login.php"
               style="flex:1;text-align:center;padding:10px;font-size:13px;font-weight:600;
                      color:<?php echo !$show_register ? 'var(--primary)' : 'var(--text-sec)'; ?>;
                      border-bottom:<?php echo !$show_register ? '2px solid var(--accent)' : 'none'; ?>;
                      text-decoration:none;margin-bottom:-2px;">
                Sign In
            </a>
            <a href="/login.php?tab=register"
               style="flex:1;text-align:center;padding:10px;font-size:13px;font-weight:600;
                      color:<?php echo $show_register ? 'var(--primary)' : 'var(--text-sec)'; ?>;
                      border-bottom:<?php echo $show_register ? '2px solid var(--accent)' : 'none'; ?>;
                      text-decoration:none;margin-bottom:-2px;">
                New Registration
            </a>
        </div>

        <?php if (!$show_register): ?>
        <!-- ── LOGIN FORM ── -->
        <h3>Sign In</h3>
        <p class="sub">Enter your credentials to access Internet Banking</p>

        <?php if ($error !== ''): ?>
        <div class="alert alert-danger">&#9888; <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <form method="POST" action="/login.php" autocomplete="off" novalidate>
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label for="username">Customer ID / Username</label>
                <input type="text" id="username" name="username"
                       class="form-control"
                       placeholder="Enter your username"
                       value="<?php echo $prefill_username; ?>"
                       autocomplete="off" required>
            </div>
            <div class="form-group">
                <label for="password">Internet Banking Password</label>
                <div class="input-wrap">
                    <input type="password" id="password" name="password"
                           class="form-control"
                           placeholder="Enter your password"
                           autocomplete="off" required>
                    <button type="button" class="show-pw-btn" onclick="
                        var f=document.getElementById('password');
                        f.type=f.type==='password'?'text':'password';
                    ">&#128065;</button>
                </div>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;font-size:12.5px;">
                <label class="form-check">
                    <input type="checkbox" name="remember" style="margin-right:5px;"> Remember username
                </label>
                <a href="#" style="color:var(--primary);">Forgot Password?</a>
            </div>
            <button type="submit" class="btn-login">Login Securely</button>
        </form>

        <div style="margin-top:14px;padding:10px 13px;background:#fff8e6;border-radius:8px;font-size:12px;color:#7a5500;border-left:3px solid #f0a000;">
            &#128737; <strong>Security Notice:</strong> UBI will never ask for your Password, PIN, or OTP via call, SMS, or email.
        </div>

        <?php else: ?>
        <!-- ── REGISTRATION FORM ── -->
        <h3>New Registration</h3>
        <p class="sub">Create your Internet Banking account</p>

        <div id="reg-msg"></div>

        <!-- VULNERABLE: JS passes all fields including role to register API – mass assignment attack (#1) -->
        <form id="regForm" autocomplete="off" novalidate>
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="full_name" class="form-control" placeholder="As per bank records" required>
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Choose a username" required>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Registered email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Minimum 8 characters" required>
            </div>
            <button type="submit" class="btn-login">Register Now</button>
        </form>

        <script>
        document.getElementById('regForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var data = {};
            new FormData(this).forEach(function(v, k) { data[k] = v; });
            var msg = document.getElementById('reg-msg');
            msg.innerHTML = '<div class="alert alert-info">Submitting...</div>';
            fetch('/api/v1/register.php', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify(data)
            })
            .then(function(r){ return r.json(); })
            .then(function(res) {
                if (res.status === 'success') {
                    msg.innerHTML = '<div class="alert alert-success">&#10003; Registration successful! Redirecting to login...</div>';
                    setTimeout(function(){ window.location = '/login.php'; }, 1800);
                } else {
                    msg.innerHTML = '<div class="alert alert-danger">&#9888; ' + (res.message || 'Registration failed.') + '</div>';
                }
            })
            .catch(function() {
                msg.innerHTML = '<div class="alert alert-danger">Network error. Please try again.</div>';
            });
        });
        </script>
        <?php endif; ?>

        <div class="login-footer" style="margin-top:18px;text-align:center;font-size:12px;color:var(--text-sec);">
            <a href="#" style="color:var(--primary);">Privacy Policy</a>
            &nbsp;|&nbsp;
            <a href="/support.php" style="color:var(--primary);">Help &amp; Support</a>
        </div>
    </div><!-- /.login-form -->
</div><!-- /.login-wrap -->
</main>

<footer class="footer">
    <div>&copy; 2024 Union Bank of India. All Rights Reserved. Regulated by Reserve Bank of India.</div>
    <div class="badges">
        <span class="fbadge">RBI Regulated</span>
        <span class="fbadge">256-bit SSL</span>
        <span class="fbadge">DICGC Insured</span>
    </div>
</footer>

</body>
</html>
