<?php
require_once '/var/www/html/includes/auth.php';
session_init();

if (is_logged_in()) {
    header('Location: ' . (in_array($_SESSION['role'], ['admin','banker']) ? '/admin/index.php' : '/dashboard.php'));
    exit;
}

$error  = '';
$tab    = (isset($_GET['tab']) && $_GET['tab'] === 'register') ? 'register' : 'login';
$pre_u  = '';  // username pre-fill (safe PHP var, never embedded inline)

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'login') {
        $u = trim($_POST['username'] ?? '');
        $p = $_POST['password'] ?? '';
        $pre_u = htmlspecialchars($u, ENT_QUOTES);
        if ($u === '' || $p === '') {
            $error = 'Please enter both username and password.';
        } else {
            $user = login_user($u, $p);
            if ($user) {
                header('Location: ' . (in_array($user['role'], ['admin','banker']) ? '/admin/index.php' : '/dashboard.php'));
                exit;
            } else {
                $error = 'Invalid username or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In - Union Bank of India</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="login-page">

<div class="top-bar">
    <div>&#9742; Toll Free: <strong>1800-22-2244</strong> &nbsp;|&nbsp; <strong>1800-208-2244</strong></div>
    <div>Internet Banking Portal v6</div>
</div>

<div class="header">
    <div class="logo-section">
        <div class="logo-icon">UB</div>
        <div class="bank-name">
            <h1>Union Bank of India</h1>
            <p>Good People to Bank With</p>
        </div>
    </div>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>

<div class="notice-bar">
    <marquee scrollamount="3">&#9888; UBI will NEVER ask for your PIN, OTP, or Password over call, SMS, or email. &nbsp;|&nbsp; NEFT/RTGS available 24x7. &nbsp;|&nbsp; Maintenance: Sunday 00:00-04:00 IST.</marquee>
</div>

<main class="main-content">
<div class="login-wrap">

    <div class="login-info">
        <h2>Welcome to<br>Internet Banking</h2>
        <p>Secure access to account management, fund transfers, and more - anytime, anywhere.</p>
        <ul>
            <li>Account Management &amp; Enquiry</li>
            <li>NEFT / RTGS / IMPS Fund Transfer</li>
            <li>Real-time Account Statements</li>
            <li>Bill Payments &amp; Recharges</li>
            <li>Transaction History &amp; Reports</li>
        </ul>
        <div class="security-note">&#128274; For authorized customers only. All activities are monitored and logged.</div>
    </div>

    <div class="login-form">
        <!-- Tab switcher using CSS classes, no PHP in style attrs -->
        <div class="login-tabs">
            <a href="/login.php" class="login-tab <?php echo $tab === 'login' ? 'login-tab-active' : ''; ?>">Sign In</a>
            <a href="/login.php?tab=register" class="login-tab <?php echo $tab === 'register' ? 'login-tab-active' : ''; ?>">New Registration</a>
        </div>

        <?php if ($tab === 'login'): ?>

        <h3>Sign In</h3>
        <p class="sub">Enter your Internet Banking credentials</p>

        <?php if ($error !== ''): ?>
        <div class="alert alert-danger">&#9888; <?php echo htmlspecialchars($error, ENT_QUOTES); ?></div>
        <?php endif; ?>

        <form method="POST" action="/login.php" autocomplete="off">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label for="fusername">Customer ID / Username</label>
                <input type="text" id="fusername" name="username" class="form-control"
                       placeholder="Enter your username"
                       value="<?php echo $pre_u; ?>"
                       autocomplete="username">
            </div>
            <div class="form-group">
                <label for="fpassword">Internet Banking Password</label>
                <div class="input-wrap">
                    <input type="password" id="fpassword" name="password" class="form-control"
                           placeholder="Enter your password"
                           autocomplete="current-password">
                    <button type="button" class="show-pw-btn" id="togglePw">&#128065;</button>
                </div>
            </div>
            <div class="form-row" style="margin-bottom:16px;">
                <label class="form-check"><input type="checkbox" name="remember"> Remember username</label>
                <a href="#" class="text-muted" style="font-size:12px;">Forgot Password?</a>
            </div>
            <button type="submit" class="btn-login">Login Securely</button>
        </form>
        <div style="margin-top:14px;padding:10px;background:#fff8e6;border-radius:8px;font-size:12px;color:#7a5500;border-left:3px solid #f0a000;">
            &#128737; UBI will never ask for your Password, PIN, or OTP via call, SMS, or email.
        </div>
        <div class="login-footer">
            <a href="/login.php?tab=register">New User? Register here</a>
        </div>

        <?php else: ?>

        <h3>New Registration</h3>
        <p class="sub">Create your Internet Banking account</p>
        <div id="reg-msg"></div>
        <!-- VULNERABLE: role field passed to register API - mass assignment (#1) -->
        <form id="regForm">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="full_name" class="form-control" placeholder="As per bank records" required>
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Choose a username" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Registered email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Min 8 characters" required>
            </div>
            <button type="submit" class="btn-login">Register Now</button>
        </form>
        <div class="login-footer">
            <a href="/login.php">Already registered? Sign In</a>
        </div>
        <script>
        document.getElementById('regForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var data = {};
            new FormData(this).forEach(function(v,k){ data[k] = v; });
            var el = document.getElementById('reg-msg');
            el.innerHTML = '<div class="alert alert-info">Processing...</div>';
            fetch('/api/v1/register.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(data)
            }).then(function(r){ return r.json(); }).then(function(res) {
                if (res.status === 'success') {
                    el.innerHTML = '<div class="alert alert-success">&#10003; Registered! Redirecting...</div>';
                    setTimeout(function(){ window.location='/login.php'; }, 1500);
                } else {
                    el.innerHTML = '<div class="alert alert-danger">&#9888; ' + (res.message || 'Registration failed') + '</div>';
                }
            }).catch(function() {
                el.innerHTML = '<div class="alert alert-danger">Network error. Please try again.</div>';
            });
        });
        </script>

        <?php endif; ?>
    </div>
</div>
</main>

<footer class="footer">
    <div>&copy; 2024 Union Bank of India. All Rights Reserved.</div>
    <div class="badges">
        <span class="fbadge">RBI Regulated</span>
        <span class="fbadge">DICGC Insured</span>
    </div>
</footer>
<script>
document.getElementById('togglePw') && document.getElementById('togglePw').addEventListener('click', function() {
    var f = document.getElementById('fpassword');
    if (f) f.type = f.type === 'password' ? 'text' : 'password';
});
</script>
</body>
</html>
