<?php
require_once '/var/www/html/includes/auth.php';
session_init();
if (is_logged_in()) { header('Location: /dashboard.php'); exit; }

$error = '';
$show_register = isset($_GET['register']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $user = login_user($username, $password);
        if ($user) {
            $acc = get_user_account($user['id']);
            if ($acc) $_SESSION['acc_no'] = $acc['acc_no'];
            $redirect = in_array($user['role'], ['admin','banker']) ? '/admin/index.php' : '/dashboard.php';
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid username or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In – Union Bank of India Internet Banking</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="login-page">

<!-- Top bar -->
<div class="top-bar">
    <div>☎ Toll Free: <strong>1800-22-2244</strong> &nbsp;|&nbsp; <strong>1800-208-2244</strong></div>
    <div>Internet Banking Portal v6 &nbsp;|&nbsp; <a href="#">User Guide</a> &nbsp;|&nbsp; <a href="#">Contact IT</a></div>
</div>

<!-- Header -->
<div class="header">
    <div class="logo-section">
        <div class="logo-icon">UB</div>
        <div class="bank-name">
            <h1>Union Bank of India</h1>
            <p>Good People to Bank With</p>
        </div>
    </div>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>

<!-- Notice -->
<div class="notice-bar">
    <marquee behavior="scroll" direction="left" scrollamount="3">
        ⚠ Security Notice: UBI will NEVER ask for your PIN, OTP, or Password over call, SMS, or email. &nbsp;|&nbsp;
        New NEFT/RTGS timings: Available 24×7 including Sundays and holidays. &nbsp;|&nbsp;
        System maintenance scheduled for Sunday 00:00–04:00 IST.
    </marquee>
</div>

<!-- Login content -->
<main class="main-content">
<div class="login-wrap">

    <!-- Left info panel -->
    <div class="login-info">
        <h2>Welcome to Internet Banking</h2>
        <p>Secure access to banking operations, account management, fund transfers, and more — anytime, anywhere.</p>
        <ul>
            <li>Account Management &amp; Enquiry</li>
            <li>NEFT / RTGS / IMPS Fund Transfer</li>
            <li>Real-time Account Statements</li>
            <li>Bill Payments &amp; Recharges</li>
            <li>Transaction History &amp; Reports</li>
            <li>Loan Enquiry &amp; Servicing</li>
        </ul>
        <div class="security-note">
            🔒 This system is for authorized customers only. All activities are monitored and logged by the IT Security team.
        </div>
    </div>

    <!-- Right form panel -->
    <div class="login-form">
        <?php if (!$show_register): ?>
            <h3>Sign In</h3>
            <p class="sub">Enter your credentials to access Internet Banking</p>

            <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error, ENT_QUOTES); ?></div>
            <?php endif; ?>

            <form method="POST" action="/login.php" autocomplete="off">
                <input type="hidden" name="action" value="login">
                <div class="form-group">
                    <label for="username">Customer ID / Username</label>
                    <input type="text" id="username" name="username" class="form-control"
                           placeholder="Enter your username" required autocomplete="off"
                           value="<?php echo htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES); ?>">
                </div>
                <div class="form-group">
                    <label for="password">Internet Banking Password</label>
                    <div class="input-wrap">
                        <input type="password" id="password" name="password" class="form-control"
                               placeholder="Enter your password" required autocomplete="off">
                        <button type="button" class="show-pw-btn" onclick="togglePw()">👁</button>
                    </div>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
                    <label class="form-check">
                        <input type="checkbox" name="remember"> Remember username
                    </label>
                    <a href="#" style="font-size:12px;color:var(--primary);">Forgot Password?</a>
                </div>
                <button type="submit" class="btn-login">Login Securely</button>
                <div class="divider-or">or</div>
                <button type="button" class="btn-outline-login" onclick="window.location='/login.php?register=1'">
                    New User Registration
                </button>
            </form>

            <div style="margin-top:16px;padding:10px 13px;background:#fff8e6;border-radius:8px;font-size:11.5px;color:#7a5500;border-left:3px solid #f0a000;">
                🛡 <strong>Security Notice:</strong> UBI will never ask for your Password, PIN, or OTP via call, SMS, or email.
                Always ensure the URL starts with <strong>http://</strong>.
            </div>

        <?php else: ?>
            <h3>New Registration</h3>
            <p class="sub">Create your Internet Banking account</p>

            <div id="reg-alert"></div>

            <!-- VULNERABLE: JS passes role field to register API – mass assignment attack surface -->
            <form id="regForm" autocomplete="off">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" class="form-control" placeholder="As per bank records" required>
                </div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Choose a username" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="Registered email" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Minimum 8 characters" required>
                </div>
                <button type="submit" class="btn-login">Register Now</button>
                <div class="divider-or">or</div>
                <button type="button" class="btn-outline-login" onclick="window.location='/login.php'">
                    Back to Login
                </button>
            </form>

            <script>
            document.getElementById('regForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const fd = new FormData(this);
                const data = Object.fromEntries(fd.entries());
                const alertDiv = document.getElementById('reg-alert');
                try {
                    const r = await fetch('/api/v1/register.php', {
                        method: 'POST',
                        headers: {'Content-Type':'application/json'},
                        body: JSON.stringify(data)
                    });
                    const res = await r.json();
                    if (res.status === 'success') {
                        alertDiv.innerHTML = '<div class="alert alert-success">✅ Registration successful! Redirecting to login...</div>';
                        setTimeout(() => window.location='/login.php', 1500);
                    } else {
                        alertDiv.innerHTML = '<div class="alert alert-danger">' + (res.message || 'Registration failed') + '</div>';
                    }
                } catch(err) {
                    alertDiv.innerHTML = '<div class="alert alert-danger">Network error. Please try again.</div>';
                }
            });
            </script>
        <?php endif; ?>

        <div class="login-footer">
            <a href="/">← Home</a> &nbsp;|&nbsp;
            <a href="/support.php">Help &amp; Support</a> &nbsp;|&nbsp;
            <a href="#">Privacy Policy</a>
        </div>
    </div>
</div>
</main>

<footer class="footer">
    <div>&copy; 2024 Union Bank of India. All Rights Reserved. Regulated by Reserve Bank of India.</div>
    <div class="badges">
        <span class="fbadge">RBI Regulated</span>
        <span class="fbadge">256-bit SSL</span>
        <span class="fbadge">DICGC Insured</span>
    </div>
</footer>

<script>
function togglePw() {
    const pw = document.getElementById('password');
    pw.type = pw.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
