<?php
require_once '/var/www/html/includes/auth.php';
session_init();
if (is_logged_in()) { header('Location: /dashboard.php'); exit; }

$error = '';
$show_register = isset($_GET['register']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $user = login_user($username, $password);
        if ($user) {
            $acc = get_user_account($user['id']);
            if ($acc) $_SESSION['acc_no'] = $acc['acc_no'];
            $redirect = in_array($user['role'], ['admin','banker']) ? '/admin/index.php' : '/dashboard.php';
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid username or password. Please try again.';
        }
    }
}
$page_title = 'Login – Union Bank of India Internet Banking';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title, ENT_QUOTES) ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
</head>
<body class="login-page">
<div class="login-wrapper">
    <!-- Left panel -->
    <div class="login-left">
        <div class="login-left-content">
            <div class="login-logo">
                <svg width="64" height="64" viewBox="0 0 52 52" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="26" cy="26" r="26" fill="#FFB300"/>
                    <text x="26" y="35" text-anchor="middle" font-family="Arial Black,Arial,sans-serif"
                          font-size="26" font-weight="900" fill="#4A148C">U</text>
                </svg>
                <div>
                    <div class="login-bank-name">Union Bank of India</div>
                    <div class="login-bank-sub">Good People to Bank With</div>
                </div>
            </div>
            <h2>Welcome to<br>Internet Banking</h2>
            <p>Secure, fast, and convenient banking — anytime, anywhere.</p>
            <ul class="login-features">
                <li>&#127775; NEFT &amp; RTGS 24×7</li>
                <li>&#127775; Real-time account statements</li>
                <li>&#127775; Instant fund transfers</li>
                <li>&#127775; Bill payments &amp; recharges</li>
            </ul>
        </div>
    </div>

    <!-- Right panel – login form -->
    <div class="login-right">
        <div class="login-card">
            <?php if (!$show_register): ?>
                <h2 class="login-card-title">&#128274; Secure Login</h2>
                <p class="login-card-sub">Internet Banking — Customer Portal</p>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES) ?></div>
                <?php endif; ?>

                <form method="POST" action="/login.php" class="login-form" autocomplete="off">
                    <input type="hidden" name="action" value="login">
                    <div class="form-group">
                        <label for="username">Username / Customer ID</label>
                        <input type="text" id="username" name="username" class="form-control"
                               placeholder="Enter your username" required autocomplete="off"
                               value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES) ?>">
                    </div>
                    <div class="form-group">
                        <label for="password">Internet Banking Password</label>
                        <div class="input-group">
                            <input type="password" id="password" name="password" class="form-control"
                                   placeholder="Enter your password" required autocomplete="off">
                            <button type="button" class="toggle-pw" onclick="togglePw()">&#128065;</button>
                        </div>
                    </div>
                    <div class="form-row">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember"> Remember username
                        </label>
                        <a href="#" class="forgot-link">Forgot Password?</a>
                    </div>
                    <button type="submit" class="btn btn-gold btn-full btn-lg">Login Securely</button>
                    <div class="login-divider">or</div>
                    <a href="/login.php?register=1" class="btn btn-outline btn-full">New User Registration</a>
                </form>

                <div class="login-security-notice">
                    <strong>&#128737; Security Notice:</strong>
                    UBI will never ask for your Password, PIN, or OTP via call, SMS, or email.
                    Always ensure the URL starts with <strong>http://</strong>.
                </div>

            <?php else: ?>
                <h2 class="login-card-title">&#127775; New Registration</h2>
                <p class="login-card-sub">Create your Internet Banking account</p>
                <div id="reg-alert"></div>
                <form id="regForm" class="login-form" autocomplete="off">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" class="form-control" placeholder="As per bank records" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Choose a username" required>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="Registered email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Min 8 chars" required>
                    </div>
                    <button type="submit" class="btn btn-gold btn-full btn-lg">Register Now</button>
                    <div class="login-divider">or</div>
                    <a href="/login.php" class="btn btn-outline btn-full">Back to Login</a>
                </form>
                <script>
                document.getElementById('regForm').addEventListener('submit', async function(e) {
                    e.preventDefault();
                    const fd = new FormData(this);
                    const data = Object.fromEntries(fd.entries());
                    const alertDiv = document.getElementById('reg-alert');
                    try {
                        const r = await fetch('/api/v1/register.php', {
                            method: 'POST',
                            headers: {'Content-Type':'application/json'},
                            body: JSON.stringify(data)
                        });
                        const res = await r.json();
                        if (res.status === 'success') {
                            alertDiv.innerHTML = '<div class="alert alert-success">Registration successful! Please login.</div>';
                            setTimeout(() => window.location='/login.php', 1500);
                        } else {
                            alertDiv.innerHTML = '<div class="alert alert-danger">' + (res.message || 'Registration failed') + '</div>';
                        }
                    } catch(err) {
                        alertDiv.innerHTML = '<div class="alert alert-danger">Network error. Please try again.</div>';
                    }
                });
                </script>
            <?php endif; ?>

            <div class="login-footer-links">
                <a href="/">&#8592; Back to Home</a>
                <span>|</span>
                <a href="/support.php">Help &amp; Support</a>
            </div>
        </div>
    </div>
</div>

<script>
function togglePw() {
    const pw = document.getElementById('password');
    pw.type = pw.type === 'password' ? 'text' : 'password';
}
</script>
<script src="/assets/js/app.js"></script>
</body>
</html>
