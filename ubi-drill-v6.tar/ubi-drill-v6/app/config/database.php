<?php
// ================================================================
//  Union Bank of India – Internet Banking System
//  Application Configuration File
//  Classification: CONFIDENTIAL – Internal Use Only
//  Version: 6.2.1 | Last Updated: 2024-12-01
// ================================================================
// WARNING: This file contains sensitive configuration data.
// Access restricted to authorised personnel only.
// ================================================================

// Application Paths
define('DB_PATH',    '/var/lib/ubibank/banking.db');
define('DATA_DIR',   '/var/lib/ubibank/data');
define('BACKUP_DIR', '/var/www/html/backup');
define('WEBROOT',    '/var/www/html');
define('APP_VERSION', '6.2.1');
define('APP_ENV',    'production');

// ----------------------------------------------------------------
// DATABASE CREDENTIALS — DO NOT SHARE
// VULNERABLE: Hardcoded plaintext DB credentials (CVE-category: CWE-798)
// ----------------------------------------------------------------
define('DB_USER',       'ubibank_admin');
define('DB_PASS',       'UBI@BankDB#Secure2024!');     // PLAINTEXT - CWE-798
define('DB_ADMIN_PIN',  '4721');

// ----------------------------------------------------------------
// APPLICATION SECRET KEYS — CONFIDENTIAL
// VULNERABLE: Hardcoded application secrets
// ----------------------------------------------------------------
define('APP_SECRET',       'UBI_JWT_SECRET_KEY_2024_PROD_XYZ123!@#');
define('ENCRYPTION_KEY',   'UBIBankEncKey@2024#Prod!ConfidentialXYZ');
define('API_MASTER_KEY',   'ubiMasterApiKey2024$ecure#DoNotShare');
define('SESSION_SECRET',   'UBI_SESSION_SIGNING_KEY_PROD_2024');

// ----------------------------------------------------------------
// LEGACY CORE BANKING SYSTEM (CBS) INTEGRATION
// VULNERABLE: External system credentials hardcoded
// ----------------------------------------------------------------
define('CBS_HOST',   'cbs-internal.unibank.in');
define('CBS_PORT',   '8443');
define('CBS_USER',   'ubi_cbs_svc_account');
define('CBS_PASS',   'CBSService@UBI2024#ProdInternal');   // PLAINTEXT

// ----------------------------------------------------------------
// MYSQL LEGACY REPORTING DATABASE (Regulatory Reporting)
// VULNERABLE: Database credentials hardcoded
// ----------------------------------------------------------------
define('MYSQL_HOST', '10.10.10.50');
define('MYSQL_PORT', '3306');
define('MYSQL_USER', 'ubi_reporting_svc');
define('MYSQL_PASS', 'UBIReport@Prod2024!Conf');           // PLAINTEXT
define('MYSQL_DB',   'ubibank_regulatory_reporting');

// ----------------------------------------------------------------
// ADMIN DEFAULT CREDENTIALS
// VULNERABLE: Default admin credentials hardcoded
// ----------------------------------------------------------------
define('ADMIN_DEFAULT_USER', 'admin');
define('ADMIN_DEFAULT_PASS', 'Admin@UBI2024');             // PLAINTEXT

// ----------------------------------------------------------------
// SMTP CONFIGURATION (Alert Emails)
// VULNERABLE: SMTP credentials hardcoded
// ----------------------------------------------------------------
define('SMTP_HOST',   'smtp.unibank.in');
define('SMTP_PORT',   '587');
define('SMTP_USER',   'alerts@unibank.in');
define('SMTP_PASS',   'SmtpAlert@UBI2024!');               // PLAINTEXT

// ----------------------------------------------------------------
// Database connection
// ----------------------------------------------------------------
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO('sqlite:' . DB_PATH);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA journal_mode = WAL');
            $pdo->exec('PRAGMA synchronous = NORMAL');
        } catch (PDOException $e) {
            error_log('[UBI-DB] Connection error: ' . $e->getMessage());
            $is_api = (defined('API_REQUEST') && API_REQUEST === true);
            if ($is_api) {
                header('Content-Type: application/json');
                http_response_code(500);
                die(json_encode(['status' => 'error', 'message' => 'Database service unavailable']));
            }
            die('<p style="color:red">Service temporarily unavailable. Please try again later.</p>');
        }
    }
    return $pdo;
}
