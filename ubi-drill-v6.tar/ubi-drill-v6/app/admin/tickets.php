<?php
// VULNERABLE XSS TRIGGER: message echoed raw (Scenario #4)
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(['admin','banker']);
$page_title = 'Support Tickets - Admin';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ticket_id'])) {
    $db->prepare("UPDATE support_tickets SET status='resolved' WHERE id=?")->execute([(int)$_POST['ticket_id']]);
    header('Location: /admin/tickets.php?resolved=1'); exit;
}
$filter = $_GET['status']??'all';
$sql = 'SELECT t.id,t.subject,t.message,t.status,t.created_at,u.full_name,u.email FROM support_tickets t LEFT JOIN users u ON t.user_id=u.id';
if ($filter==='open') $sql.=" WHERE t.status='open'";
elseif ($filter==='resolved') $sql.=" WHERE t.status='resolved'";
$sql.=' ORDER BY t.created_at DESC';
$tickets        = $db->query($sql)->fetchAll();
$open_count     = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
$resolved_count = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='resolved'")->fetchColumn();
include '/var/www/html/includes/header.php';
?>
<div class="page-header"><h2>&#127905; Support Tickets</h2><p class="breadcrumb"><a href="/admin/index.php">Admin</a> &#8250; Tickets</p></div>
<div class="admin-tabs"><a href="/admin/index.php">&#128202; Dashboard</a><a href="/admin/users.php">&#128101; Users</a><a href="/admin/tickets.php" class="active">&#127905; Tickets</a><a href="/dashboard.php">&#8592; Main</a></div>
<?php if (isset($_GET['resolved'])): ?><div class="alert alert-success">&#10003; Ticket resolved.</div><?php endif; ?>
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:18px;">
    <div class="stat-card"><div class="stat-icon red">&#127905;</div><div><span class="stat-value"><?php echo $open_count; ?></span><span class="stat-label">Open</span></div></div>
    <div class="stat-card"><div class="stat-icon green">&#10003;</div><div><span class="stat-value"><?php echo $resolved_count; ?></span><span class="stat-label">Resolved</span></div></div>
    <div class="stat-card"><div class="stat-icon blue">&#128203;</div><div><span class="stat-value"><?php echo $open_count+$resolved_count; ?></span><span class="stat-label">Total</span></div></div>
</div>
<div style="display:flex;gap:8px;margin-bottom:16px;">
    <a href="/admin/tickets.php" class="btn btn-sm <?php echo $filter==='all'?'btn-primary':'btn-outline'; ?>">All</a>
    <a href="/admin/tickets.php?status=open" class="btn btn-sm <?php echo $filter==='open'?'btn-primary':'btn-outline'; ?>">Open</a>
    <a href="/admin/tickets.php?status=resolved" class="btn btn-sm <?php echo $filter==='resolved'?'btn-primary':'btn-outline'; ?>">Resolved</a>
</div>
<?php if (empty($tickets)): ?><div class="card"><div class="empty-state card-body"><div class="icon">&#128203;</div><p>No tickets found.</p></div></div><?php endif; ?>
<?php foreach ($tickets as $tk): ?>
<div class="card" style="margin-bottom:12px;">
    <div class="ticket-head">
        <div><strong style="color:var(--primary);">SR<?php echo (int)$tk['id']; ?></strong> &#8212; <strong><?php echo htmlspecialchars($tk['subject'],ENT_QUOTES); ?></strong> <span class="badge <?php echo $tk['status']==='open'?'badge-warning':'badge-success'; ?>"><?php echo strtoupper($tk['status']); ?></span></div>
        <div class="ticket-meta"><?php echo htmlspecialchars($tk['full_name']??'Unknown',ENT_QUOTES); ?><?php if ($tk['email']): ?> | <?php echo htmlspecialchars($tk['email'],ENT_QUOTES); ?><?php endif; ?> | <?php echo date('d M Y, h:i A',strtotime($tk['created_at'])); ?></div>
    </div>
    <div class="ticket-body">
        <!-- VULNERABLE XSS SINK: raw echo, no sanitisation -->
        <?php echo $tk['message']; ?>
        <?php if ($tk['status']==='open'): ?>
        <hr style="border:none;border-top:1px solid var(--border);margin:12px 0;">
        <form method="POST" action="/admin/tickets.php" style="margin:0;"><input type="hidden" name="ticket_id" value="<?php echo (int)$tk['id']; ?>"><button type="submit" class="btn btn-success btn-sm">&#10003; Mark Resolved</button></form>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>
<?php include '/var/www/html/includes/footer.php'; ?>
