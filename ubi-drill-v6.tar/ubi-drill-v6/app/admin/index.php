<?php
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session    = check_auth(['admin','banker']);
$page_title = 'Admin Panel - Union Bank of India';
$db = getDB();

$total_users   = $db->query('SELECT COUNT(*) FROM users WHERE is_active=1')->fetchColumn();
$total_accs    = $db->query('SELECT COUNT(*) FROM accounts WHERE is_active=1')->fetchColumn();
$total_balance = (float)$db->query('SELECT COALESCE(SUM(balance),0) FROM accounts WHERE is_active=1')->fetchColumn();
$open_tickets  = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();

$accounts    = $db->query('SELECT a.id, a.account_number, a.account_type, a.balance, u.full_name, u.username FROM accounts a JOIN users u ON a.user_id=u.id ORDER BY a.id')->fetchAll(PDO::FETCH_ASSOC);
$recent_txns = $db->query('SELECT t.txn_id, t.txn_type, t.amount, t.direction, t.created_at, a.account_number FROM transactions t JOIN accounts a ON t.account_id=a.id ORDER BY t.created_at DESC LIMIT 10')->fetchAll(PDO::FETCH_ASSOC);

include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>&#128187; Admin Control Panel</h2>
    <p class="breadcrumb">Union Bank of India &#8250; Administration
        &nbsp;<span class="badge badge-admin"><?php echo strtoupper(htmlspecialchars($session['role'], ENT_QUOTES)); ?></span>
    </p>
</div>

<div class="admin-tabs">
    <a href="/admin/index.php" class="active">&#128202; Dashboard</a>
    <a href="/admin/users.php">&#128101; Users</a>
    <a href="/admin/tickets.php">&#127905; Support Tickets
        <?php if ($open_tickets > 0): ?>
        <span class="badge badge-warning" style="margin-left:4px;"><?php echo $open_tickets; ?></span>
        <?php endif; ?>
    </a>
    <a href="/dashboard.php">&#8592; Main Dashboard</a>
</div>

<div class="stats-grid">
    <div class="stat-card"><div class="stat-icon blue">&#128100;</div><div><span class="stat-value"><?php echo $total_users; ?></span><span class="stat-label">Active Users</span></div></div>
    <div class="stat-card"><div class="stat-icon red">&#127970;</div><div><span class="stat-value"><?php echo $total_accs; ?></span><span class="stat-label">Accounts</span></div></div>
    <div class="stat-card"><div class="stat-icon green">&#8377;</div><div><span class="stat-value" style="font-size:15px;">&#8377;<?php echo number_format($total_balance, 0); ?></span><span class="stat-label">Total Deposits</span></div></div>
    <div class="stat-card"><div class="stat-icon darkred">&#127905;</div><div><span class="stat-value"><?php echo $open_tickets; ?></span><span class="stat-label">Open Tickets</span></div></div>
</div>

<div class="content-grid">
    <div class="card">
        <div class="card-header">
            <h3>&#127970; All Customer Accounts</h3>
            <a href="/admin/users.php" class="btn-link">Manage Users &#8594;</a>
        </div>
        <div class="card-body no-pad">
            <div class="table-wrapper">
            <table class="data-table">
                <thead><tr><th>#</th><th>Account No.</th><th>Holder</th><th>Type</th><th>Balance</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($accounts as $i => $a): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td class="mono"><?php echo htmlspecialchars($a['account_number'], ENT_QUOTES); ?></td>
                    <td><?php echo htmlspecialchars($a['full_name'], ENT_QUOTES); ?><br><small class="text-muted"><?php echo htmlspecialchars($a['username'], ENT_QUOTES); ?></small></td>
                    <td><?php echo htmlspecialchars($a['account_type'], ENT_QUOTES); ?></td>
                    <td class="amount">&#8377;<?php echo number_format($a['balance'], 2); ?></td>
                    <td>
                        <a href="/account.php?id=<?php echo (int)$a['id']; ?>" class="btn btn-sm btn-outline">View</a>
                        <a href="/api/v1/statement.php?account_number=<?php echo urlencode($a['account_number']); ?>" class="btn btn-sm btn-outline" style="margin-left:4px;" target="_blank">API</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h3>&#128200; Recent Transactions</h3></div>
        <div class="card-body no-pad">
            <div class="table-wrapper">
            <table class="data-table">
                <thead><tr><th>TXN ID</th><th>Account</th><th>Mode</th><th>Amount</th><th>Dir</th></tr></thead>
                <tbody>
                <?php foreach ($recent_txns as $t): ?>
                <tr>
                    <td><code style="font-size:10px;"><?php echo htmlspecialchars(substr($t['txn_id'], 0, 18), ENT_QUOTES); ?></code></td>
                    <td class="mono" style="font-size:11px;">...<?php echo htmlspecialchars(substr($t['account_number'], -6), ENT_QUOTES); ?></td>
                    <td><span class="badge badge-success"><?php echo htmlspecialchars($t['txn_type'], ENT_QUOTES); ?></span></td>
                    <td class="amount">&#8377;<?php echo number_format($t['amount'], 2); ?></td>
                    <td><span class="badge <?php echo $t['direction'] === 'CREDIT' ? 'badge-success' : 'badge-warning'; ?>"><?php echo htmlspecialchars($t['direction'], ENT_QUOTES); ?></span></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recent_txns)): ?>
                <tr><td colspan="5" style="text-align:center;color:var(--text-sec);padding:20px;">No transactions yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
