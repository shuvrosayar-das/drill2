<?php
// ================================================================
//  Union Bank of India – Admin Dashboard
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(['admin', 'banker']);

$db = getDB();

$total_users   = $db->query("SELECT COUNT(*) FROM users WHERE is_active=1")->fetchColumn();
$total_accs    = $db->query("SELECT COUNT(*) FROM accounts WHERE is_active=1")->fetchColumn();
$total_balance = $db->query("SELECT SUM(balance) FROM accounts WHERE is_active=1")->fetchColumn();
$open_tickets  = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
$total_txns    = $db->query("SELECT COUNT(*) FROM transactions")->fetchColumn();

// Recent transactions
$recent_txns = $db->query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON t.account_id=a.id ORDER BY t.created_at DESC LIMIT 10")->fetchAll();

// All accounts overview
$accounts = $db->query("SELECT a.*, u.full_name, u.username, u.role FROM accounts a JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC")->fetchAll();

include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#128187; Admin Control Panel</h1>
      <div class="breadcrumb">Union Bank of India &rsaquo; Administration</div>
    </div>
    <span class="badge role-admin">&#128272; <?= strtoupper(htmlspecialchars($session['role'])) ?></span>
  </div>
</div>

<div class="main-content">
<div class="container">

  <div class="admin-nav">
    <a href="/admin/index.php" class="active">Dashboard</a>
    <a href="/admin/users.php">Users</a>
    <a href="/admin/tickets.php">Support Tickets <span class="badge badge-warning" style="margin-left:4px;"><?= $open_tickets ?></span></a>
    <a href="/dashboard.php">&#8592; Main Dashboard</a>
  </div>

  <!-- Stats -->
  <div class="stat-grid">
    <div class="stat-card">
      <div class="stat-icon purple">&#128100;</div>
      <div><div class="stat-value"><?= $total_users ?></div><div class="stat-label">Active Users</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon gold">&#127970;</div>
      <div><div class="stat-value"><?= $total_accs ?></div><div class="stat-label">Accounts</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green">&#8377;</div>
      <div><div class="stat-value" style="font-size:16px;">&#8377;<?= number_format($total_balance, 0) ?></div><div class="stat-label">Total Deposits</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon red">&#128172;</div>
      <div><div class="stat-value"><?= $open_tickets ?></div><div class="stat-label">Open Tickets</div></div>
    </div>
  </div>

  <div class="dashboard-grid">
    <!-- Accounts Table -->
    <div>
      <div class="card mb-4">
        <div class="card-header">&#127970; All Customer Accounts</div>
        <div class="card-body" style="padding:0;">
          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr><th>#</th><th>Account Number</th><th>Holder</th><th>Type</th><th>Balance</th><th>Actions</th></tr>
              </thead>
              <tbody>
              <?php foreach ($accounts as $i => $a): ?>
              <tr>
                <td><?= $i+1 ?></td>
                <td style="font-family:monospace;"><?= htmlspecialchars($a['account_number']) ?></td>
                <td><?= htmlspecialchars($a['full_name']) ?><br><small class="text-muted"><?= htmlspecialchars($a['username']) ?></small></td>
                <td><?= htmlspecialchars($a['account_type']) ?></td>
                <td class="<?= $a['balance'] > 100000 ? 'txn-credit' : '' ?>">&#8377;<?= number_format($a['balance'], 2) ?></td>
                <td>
                  <a href="/account.php?id=<?= $a['id'] ?>" class="btn btn-outline btn-sm">&#128065; View</a>
                  <a href="/api/v1/statement.php?account_number=<?= urlencode($a['account_number']) ?>&token=REPLACE_TOKEN" class="btn btn-sm" style="background:#f5f5f5;color:#333;">&#128196; API</a>
                </td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Recent Transactions -->
    <div>
      <div class="card">
        <div class="card-header">&#128200; Recent Transactions</div>
        <div class="card-body" style="padding:0;">
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>Date</th><th>Account</th><th>Amount</th><th>Dir.</th></tr></thead>
              <tbody>
              <?php foreach ($recent_txns as $t): ?>
              <tr>
                <td style="font-size:11px;"><?= date('d M', strtotime($t['created_at'])) ?></td>
                <td style="font-family:monospace;font-size:11px;"><?= substr($t['account_number'], -8) ?>...</td>
                <td class="txn-<?= strtolower($t['direction']) ?>" style="font-size:12px;">&#8377;<?= number_format($t['amount'], 0) ?></td>
                <td><span class="badge badge-<?= $t['direction']==='CREDIT'?'success':'danger' ?>"><?= $t['direction'] ?></span></td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
