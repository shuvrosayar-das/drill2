<?php
// ================================================================
//  Union Bank of India – Admin Dashboard
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session    = check_auth(['admin', 'banker']);
$page_title = 'Admin Panel – Union Bank of India';

$db = getDB();
$total_users   = $db->query("SELECT COUNT(*) FROM users WHERE is_active=1")->fetchColumn();
$total_accs    = $db->query("SELECT COUNT(*) FROM accounts WHERE is_active=1")->fetchColumn();
$total_balance = $db->query("SELECT SUM(balance) FROM accounts WHERE is_active=1")->fetchColumn();
$open_tickets  = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
$total_txns    = $db->query("SELECT COUNT(*) FROM transactions")->fetchColumn();
$recent_txns   = $db->query("SELECT t.*, a.account_number FROM transactions t JOIN accounts a ON t.account_id=a.id ORDER BY t.created_at DESC LIMIT 10")->fetchAll();
$accounts      = $db->query("SELECT a.*, u.full_name, u.username FROM accounts a JOIN users u ON a.user_id=u.id ORDER BY a.id")->fetchAll();

include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>🖥 Admin Control Panel</h2>
    <p class="breadcrumb">Union Bank of India › Administration
        &nbsp;<span class="badge badge-admin"><?php echo strtoupper(htmlspecialchars($session['role'], ENT_QUOTES)); ?></span>
    </p>
</div>

<!-- Admin tab nav -->
<div class="admin-tabs">
    <a href="/admin/index.php" class="active">📊 Dashboard</a>
    <a href="/admin/users.php">👥 Users</a>
    <a href="/admin/tickets.php">🎫 Support Tickets <span class="badge badge-warning" style="margin-left:4px;"><?php echo $open_tickets; ?></span></a>
    <a href="/dashboard.php">← Main Dashboard</a>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">👤</div>
        <div><span class="stat-value"><?php echo $total_users; ?></span><span class="stat-label">Active Users</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">🏦</div>
        <div><span class="stat-value"><?php echo $total_accs; ?></span><span class="stat-label">Accounts</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">₹</div>
        <div><span class="stat-value" style="font-size:16px;">&#8377;<?php echo number_format($total_balance, 0); ?></span><span class="stat-label">Total Deposits</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon darkred">🎫</div>
        <div><span class="stat-value"><?php echo $open_tickets; ?></span><span class="stat-label">Open Tickets</span></div>
    </div>
</div>

<div class="content-grid">
    <!-- Accounts table -->
    <div class="card">
        <div class="card-header">
            <h3>🏦 All Customer Accounts</h3>
            <a href="/admin/users.php" class="btn-link">Manage Users →</a>
        </div>
        <div class="card-body no-pad">
            <div class="table-wrapper">
            <table class="data-table">
                <thead><tr><th>#</th><th>Account No.</th><th>Holder</th><th>Type</th><th>Balance</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($accounts as $i => $a): ?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td class="mono"><?php echo htmlspecialchars($a['account_number'] ?? '', ENT_QUOTES); ?></td>
                    <td><?php echo htmlspecialchars($a['full_name'], ENT_QUOTES); ?><br><small class="text-muted"><?php echo htmlspecialchars($a['username'], ENT_QUOTES); ?></small></td>
                    <td><?php echo htmlspecialchars($a['account_type'], ENT_QUOTES); ?></td>
                    <td class="amount">&#8377;<?php echo number_format($a['balance'], 2); ?></td>
                    <td>
                        <a href="/account.php?id=<?php echo $a['id']; ?>" class="btn btn-sm btn-outline">👁 View</a>
                        <a href="/api/v1/statement.php?account_number=<?php echo urlencode($a['account_number'] ?? ''); ?>" class="btn btn-sm btn-outline" style="margin-left:4px;">📄 API</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>

    <!-- Recent transactions -->
    <div class="card">
        <div class="card-header"><h3>📈 Recent Transactions</h3></div>
        <div class="card-body no-pad">
            <div class="table-wrapper">
            <table class="data-table">
                <thead><tr><th>TXN ID</th><th>Account</th><th>Type</th><th>Amount</th><th>Dir</th></tr></thead>
                <tbody>
                <?php foreach ($recent_txns as $t): ?>
                <tr>
                    <td><code><?php echo htmlspecialchars(substr($t['txn_id'] ?? '', 0, 16), ENT_QUOTES); ?></code></td>
                    <td class="mono" style="font-size:11px;"><?php echo htmlspecialchars(substr($t['account_number'] ?? '', -8), ENT_QUOTES); ?></td>
                    <td><span class="badge badge-success"><?php echo htmlspecialchars($t['txn_type'] ?? '', ENT_QUOTES); ?></span></td>
                    <td class="amount">&#8377;<?php echo number_format($t['amount'], 2); ?></td>
                    <td><span class="badge <?php echo ($t['direction'] ?? '') === 'CREDIT' ? 'badge-success' : 'badge-warning'; ?>"><?php echo htmlspecialchars($t['direction'] ?? '', ENT_QUOTES); ?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
