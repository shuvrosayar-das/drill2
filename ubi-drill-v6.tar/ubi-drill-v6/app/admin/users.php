<?php
// ================================================================
//  Union Bank of India – Admin: User Management
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session    = check_auth(['admin', 'banker']);
$page_title = 'User Management – Admin';

$db  = getDB();
$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $session['role'] === 'admin') {
    $uid    = (int)($_POST['user_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($uid > 0 && $uid !== (int)$session['user_id']) {
        if ($action === 'deactivate') {
            $db->prepare("UPDATE users SET is_active = 0 WHERE id = ?")->execute([$uid]);
            $msg = "User ID {$uid} deactivated.";
        } elseif ($action === 'activate') {
            $db->prepare("UPDATE users SET is_active = 1 WHERE id = ?")->execute([$uid]);
            $msg = "User ID {$uid} activated.";
        }
    }
}

$users = $db->query("SELECT u.*, a.account_number, a.balance FROM users u LEFT JOIN accounts a ON a.user_id = u.id ORDER BY u.id ASC")->fetchAll();
include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>👥 User Management</h2>
    <p class="breadcrumb"><a href="/admin/index.php">Admin Panel</a> › Users
        &nbsp;<span class="badge badge-admin">ADMIN</span>
    </p>
</div>

<div class="admin-tabs">
    <a href="/admin/index.php">📊 Dashboard</a>
    <a href="/admin/users.php" class="active">👥 Users</a>
    <a href="/admin/tickets.php">🎫 Support Tickets</a>
    <a href="/dashboard.php">← Main Dashboard</a>
</div>

<?php if ($msg): ?><div class="alert alert-success">✅ <?php echo htmlspecialchars($msg, ENT_QUOTES); ?></div><?php endif; ?>

<div class="card">
    <div class="card-header"><h3>👥 All Registered Users (<?php echo count($users); ?>)</h3></div>
    <div class="card-body no-pad">
        <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th><th>Username</th><th>Full Name</th><th>Email</th>
                    <th>Phone</th><th>Role</th><th>Account No.</th><th>Balance</th>
                    <th>Status</th><th>Last Login</th>
                    <?php if ($session['role'] === 'admin'): ?><th>Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?php echo $u['id']; ?></td>
                <td style="font-weight:600;"><?php echo htmlspecialchars($u['username'], ENT_QUOTES); ?></td>
                <td><?php echo htmlspecialchars($u['full_name'], ENT_QUOTES); ?></td>
                <td style="font-size:12px;"><?php echo htmlspecialchars($u['email'] ?? '—', ENT_QUOTES); ?></td>
                <td style="font-family:monospace;"><?php echo htmlspecialchars($u['phone'] ?? '—', ENT_QUOTES); ?></td>
                <td><span class="badge badge-<?php echo $u['role']; ?>"><?php echo ucfirst($u['role']); ?></span></td>
                <td class="mono" style="font-size:11px;"><?php echo htmlspecialchars($u['account_number'] ?? '—', ENT_QUOTES); ?></td>
                <td><?php echo $u['balance'] !== null ? '₹' . number_format($u['balance'], 0) : '—'; ?></td>
                <td>
                    <span class="badge <?php echo $u['is_active'] ? 'badge-success' : 'badge-danger'; ?>">
                        <?php echo $u['is_active'] ? 'Active' : 'Inactive'; ?>
                    </span>
                </td>
                <td style="font-size:12px;"><?php echo $u['last_login'] ? date('d M Y', strtotime($u['last_login'])) : 'Never'; ?></td>
                <?php if ($session['role'] === 'admin'): ?>
                <td>
                    <?php if ($u['id'] != $session['user_id']): ?>
                    <form method="POST" style="margin:0;display:inline;">
                        <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                        <?php if ($u['is_active']): ?>
                        <input type="hidden" name="action" value="deactivate">
                        <button type="submit" class="btn btn-sm" style="background:#fff0e0;color:#9a4d00;border:1px solid #f0c070;" onclick="return confirm('Deactivate this user?')">Deactivate</button>
                        <?php else: ?>
                        <input type="hidden" name="action" value="activate">
                        <button type="submit" class="btn btn-sm btn-success">Activate</button>
                        <?php endif; ?>
                    </form>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
