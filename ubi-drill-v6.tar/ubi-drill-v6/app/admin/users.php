<?php
// ================================================================
//  Union Bank of India – Admin: User Management
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(['admin', 'banker']);

$db = getDB();
$msg = $err = '';

// Toggle user active status (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $session['role'] === 'admin') {
    $uid = (int)($_POST['user_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($uid > 0 && $uid !== (int)$session['user_id']) {
        if ($action === 'deactivate') {
            $db->prepare("UPDATE users SET is_active = 0 WHERE id = ?")->execute([$uid]);
            $msg = "User ID $uid deactivated.";
        } elseif ($action === 'activate') {
            $db->prepare("UPDATE users SET is_active = 1 WHERE id = ?")->execute([$uid]);
            $msg = "User ID $uid activated.";
        }
    }
}

$users = $db->query("SELECT u.*, a.account_number, a.balance FROM users u LEFT JOIN accounts a ON a.user_id = u.id ORDER BY u.id ASC")->fetchAll();

include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#128100; User Management</h1>
      <div class="breadcrumb"><a href="/admin/index.php">Admin Panel</a> &rsaquo; Users</div>
    </div>
    <span class="badge role-admin">&#128272; ADMIN</span>
  </div>
</div>

<div class="main-content">
<div class="container">
  <div class="admin-nav">
    <a href="/admin/index.php">Dashboard</a>
    <a href="/admin/users.php" class="active">Users</a>
    <a href="/admin/tickets.php">Support Tickets</a>
    <a href="/dashboard.php">&#8592; Main Dashboard</a>
  </div>

  <?php if ($msg): ?><div class="alert alert-success">&#9989; <?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div class="card">
    <div class="card-header">&#128100; All Registered Users (<?= count($users) ?>)</div>
    <div class="card-body" style="padding:0;">
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Full Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Role</th>
              <th>Account No.</th>
              <th>Balance</th>
              <th>Status</th>
              <th>Last Login</th>
              <?php if ($session['role'] === 'admin'): ?><th>Actions</th><?php endif; ?>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td style="font-weight:600;"><?= htmlspecialchars($u['username']) ?></td>
            <td><?= htmlspecialchars($u['full_name']) ?></td>
            <td><?= htmlspecialchars($u['email'] ?? '—') ?></td>
            <td><?= htmlspecialchars($u['phone'] ?? '—') ?></td>
            <td>
              <span class="badge <?= $u['role']==='admin'?'badge-purple':($u['role']==='banker'?'badge-info':'badge-success') ?>">
                <?= strtoupper($u['role']) ?>
              </span>
            </td>
            <td style="font-family:monospace;font-size:11.5px;"><?= $u['account_number'] ? htmlspecialchars($u['account_number']) : '—' ?></td>
            <td><?= $u['balance'] !== null ? '&#8377;' . number_format($u['balance'], 2) : '—' ?></td>
            <td>
              <span class="badge <?= $u['is_active'] ? 'badge-success' : 'badge-danger' ?>">
                <?= $u['is_active'] ? 'ACTIVE' : 'INACTIVE' ?>
              </span>
            </td>
            <td style="font-size:11.5px;"><?= $u['last_login'] ? date('d M y', strtotime($u['last_login'])) : 'Never' ?></td>
            <?php if ($session['role'] === 'admin'): ?>
            <td>
              <?php if ($u['id'] != $session['user_id']): ?>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <input type="hidden" name="action" value="<?= $u['is_active'] ? 'deactivate' : 'activate' ?>">
                <button type="submit" class="btn btn-sm <?= $u['is_active'] ? 'btn-danger' : 'btn-success' ?>">
                  <?= $u['is_active'] ? 'Deactivate' : 'Activate' ?>
                </button>
              </form>
              <?php if ($u['account_number']): ?>
              <a href="/account.php?id=<?= $u['id']-3 ?>" class="btn btn-sm btn-outline">View Acc</a>
              <?php endif; ?>
              <?php else: ?>
              <span class="text-muted" style="font-size:12px;">Current user</span>
              <?php endif; ?>
            </td>
            <?php endif; ?>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
