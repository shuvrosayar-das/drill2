<?php $__logged = !empty($_SESSION['user_id']); ?>
    </<?php echo $__logged ? 'main' : 'main'; ?>>
<?php if ($__logged): ?>
</div><!-- /.app-container -->
<?php endif; ?>

<footer class="footer">
    <div>
        &copy; 2024 Union Bank of India. All Rights Reserved. &nbsp;|&nbsp;
        Regulated by <strong style="color:#b8cce8;">Reserve Bank of India</strong> &nbsp;|&nbsp;
        DICGC insured up to &#8377;5,00,000 &nbsp;|&nbsp;
        Server: <?php echo gethostname(); ?>
    </div>
    <div class="badges">
        <span class="fbadge">RBI Regulated</span>
        <span class="fbadge">ISO 27001</span>
        <span class="fbadge">PCI-DSS</span>
    </div>
</footer>

<script src="/assets/js/app.js"></script>
</body>
</html>
