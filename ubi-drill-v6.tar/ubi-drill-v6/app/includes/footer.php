<?php $__li = !empty($_SESSION['user_id']); ?>
    </main>
<?php if ($__li): ?>
</div>
<?php endif; ?>
<footer class="footer">
    <div>&copy; 2024 Union Bank of India. All Rights Reserved. | Regulated by Reserve Bank of India</div>
    <div class="badges">
        <span class="fbadge">RBI Regulated</span>
        <span class="fbadge">ISO 27001</span>
        <span class="fbadge">PCI-DSS</span>
    </div>
</footer>
<script src="/assets/js/app.js"></script>
</body>
</html>
