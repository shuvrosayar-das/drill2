</main>
<footer class="main-footer">
    <div class="footer-inner">
        <div class="footer-top">
            <div class="footer-brand">
                <div class="footer-logo">
                    <svg width="36" height="36" viewBox="0 0 52 52" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="26" cy="26" r="26" fill="#FFB300"/>
                        <text x="26" y="35" text-anchor="middle" font-family="Arial Black,Arial,sans-serif"
                              font-size="26" font-weight="900" fill="#4A148C">U</text>
                    </svg>
                    <span>Union Bank of India</span>
                </div>
                <p>Established 1919 &bull; Government of India Undertaking</p>
            </div>
            <div class="footer-links">
                <div class="footer-col">
                    <h4>Services</h4>
                    <a href="#">Personal Banking</a>
                    <a href="#">Corporate Banking</a>
                    <a href="#">NRI Services</a>
                    <a href="#">Loans &amp; Advances</a>
                </div>
                <div class="footer-col">
                    <h4>Digital Banking</h4>
                    <a href="#">Internet Banking</a>
                    <a href="#">Mobile Banking</a>
                    <a href="#">NEFT / RTGS</a>
                    <a href="#">UPI Payments</a>
                </div>
                <div class="footer-col">
                    <h4>Help</h4>
                    <a href="/support.php">Customer Support</a>
                    <a href="#">FAQs</a>
                    <a href="#">Branch Locator</a>
                    <a href="#">Contact Us</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="footer-legal">
                <p>&copy; 2024 Union Bank of India. All Rights Reserved. | Regulated by Reserve Bank of India (RBI).</p>
                <p>
                    IFSC: UBIN0800000 &bull;
                    MICR: 400026001 &bull;
                    CIN: L65191MH1919GOI000433
                </p>
                <p class="disclaimer">
                    This site is best viewed in Chrome 90+, Firefox 88+, Edge 90+ at 1280&times;720 resolution.
                    Internet Banking is protected by 256-bit SSL encryption.
                    Member of DICGC. Deposits insured up to &#8377;5,00,000.
                </p>
            </div>
            <div class="footer-badges">
                <div class="badge">RBI Regulated</div>
                <div class="badge">ISO 27001</div>
                <div class="badge">PCI-DSS</div>
            </div>
        </div>
    </div>
</footer>
<script src="/assets/js/app.js"></script>
</body>
</html>
