<?php
require_once '/var/www/html/includes/auth.php';
session_init();

$_h_loggedin = !empty($_SESSION['user_id']);
$_h_role     = $_SESSION['role'] ?? 'guest';
$_h_name     = htmlspecialchars($_SESSION['full_name'] ?? 'Guest', ENT_QUOTES, 'UTF-8');
$_h_cur      = basename($_SERVER['PHP_SELF'] ?? '');
$_h_dir      = basename(dirname($_SERVER['PHP_SELF'] ?? ''));

// Fetch account id for sidebar link (only when logged in as customer)
$_h_acc_id = 0;
if ($_h_loggedin && $_h_role === 'customer') {
    $db = getDB();
    $s  = $db->prepare('SELECT id FROM accounts WHERE user_id = ? AND is_active = 1 LIMIT 1');
    $s->execute([$_SESSION['user_id']]);
    $r = $s->fetch(PDO::FETCH_ASSOC);
    $_h_acc_id = $r ? (int)$r['id'] : 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($page_title ?? 'Union Bank of India - Internet Banking', ENT_QUOTES); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<!-- Top bar -->
<div class="top-bar">
    <div>&#9742; IT Helpdesk: <strong>Ext. 4400</strong> &nbsp;|&nbsp; ithelpdesk@unionbank.internal &nbsp;|&nbsp; CBS v4.2.1</div>
    <div class="tb-right">
        <?php if ($_h_loggedin): ?>
        Logged in: <strong><?php echo $_h_name; ?></strong> &nbsp;(<?php echo ucfirst($_h_role); ?>)
        &nbsp;|&nbsp; <a href="/logout.php">Logout</a>
        <?php else: ?>
        <a href="/login.php">Sign In</a>
        <?php endif; ?>
    </div>
</div>

<!-- Main header -->
<div class="header">
    <div class="logo-section">
        <div class="logo-icon">UB</div>
        <div class="bank-name">
            <h1>Union Bank of India</h1>
            <p><?php echo $_h_loggedin ? 'Internet Banking Portal' : 'Good People to Bank With'; ?></p>
        </div>
    </div>
    <?php if ($_h_loggedin): ?>
    <div class="header-right"><?php echo date('d M Y, h:i A'); ?> IST</div>
    <?php endif; ?>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>

<?php if ($_h_loggedin): ?>
<!-- Notice ticker -->
<div class="notice-bar">
    <marquee behavior="scroll" direction="left" scrollamount="3">
        &#9888; Security Notice: UBI will NEVER ask for your PIN, OTP, or Password over call, SMS, or email.
        &nbsp;|&nbsp; NEFT/RTGS now available 24x7 including Sundays and holidays.
        &nbsp;|&nbsp; Always verify the URL before entering credentials.
        &nbsp;&nbsp;
    </marquee>
</div>

<div class="app-container">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-user">
            <div class="avatar"><?php echo strtoupper(substr($_h_name, 0, 1)); ?></div>
            <div class="name"><?php echo $_h_name; ?></div>
            <div class="role"><?php echo ucfirst($_h_role); ?></div>
        </div>
        <nav class="sidebar-nav">
            <a href="/dashboard.php" class="nav-item <?php echo $_h_cur === 'dashboard.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#128202;</span> Dashboard
            </a>
            <?php if ($_h_acc_id): ?>
            <a href="/account.php?id=<?php echo $_h_acc_id; ?>" class="nav-item <?php echo $_h_cur === 'account.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#127970;</span> My Account
            </a>
            <?php endif; ?>
            <a href="/transfer.php" class="nav-item <?php echo $_h_cur === 'transfer.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#128184;</span> Fund Transfer
            </a>
            <a href="/support.php" class="nav-item <?php echo $_h_cur === 'support.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#9993;</span> Support
            </a>
            <a href="/profile.php" class="nav-item <?php echo $_h_cur === 'profile.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#128100;</span> Profile
            </a>
            <?php if (in_array($_h_role, ['admin','banker'])): ?>
            <div class="nav-divider"></div>
            <span class="nav-section">Administration</span>
            <a href="/admin/index.php" class="nav-item <?php echo ($_h_cur === 'index.php' && $_h_dir === 'admin') ? 'active' : ''; ?>">
                <span class="nav-icon">&#128187;</span> Admin Panel
            </a>
            <a href="/admin/tickets.php" class="nav-item <?php echo $_h_cur === 'tickets.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#127905;</span> Support Tickets
            </a>
            <a href="/admin/users.php" class="nav-item <?php echo $_h_cur === 'users.php' ? 'active' : ''; ?>">
                <span class="nav-icon">&#128101;</span> User Management
            </a>
            <?php endif; ?>
            <div class="nav-divider"></div>
            <a href="/logout.php" class="nav-item nav-item-danger">
                <span class="nav-icon">&#128682;</span> Logout
            </a>
        </nav>
    </aside>

    <!-- Main panel opened here; closed by footer.php -->
    <main class="main-panel">

<?php else: ?>
<main>
<?php endif; ?>
