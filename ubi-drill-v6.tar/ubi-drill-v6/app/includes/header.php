<?php
require_once '/var/www/html/includes/auth.php';
session_init();
$_h_user  = $_SESSION ?? [];
$_h_loggedin = !empty($_h_user['user_id']);
$_h_role  = $_h_user['role'] ?? 'guest';
$_h_name  = htmlspecialchars($_h_user['full_name'] ?? 'Guest', ENT_QUOTES);
$_h_uname = htmlspecialchars($_h_user['username'] ?? '', ENT_QUOTES);
$_h_cur   = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($page_title ?? 'Union Bank of India – Internet Banking', ENT_QUOTES); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<!-- Top bar -->
<div class="top-bar">
    <div>
        ☎ IT Helpdesk: <strong>Ext. 4400</strong> &nbsp;|&nbsp; Email: <strong>ithelpdesk@unionbank.internal</strong>
        &nbsp;|&nbsp; System: <strong>UBI-CBS v4.2.1</strong>
    </div>
    <div class="tb-right">
        <?php if ($_h_loggedin): ?>
        Logged in: <strong><?php echo $_h_name; ?></strong> &nbsp;(<?php echo ucfirst($_h_role); ?>)
        &nbsp;|&nbsp; <a href="/logout.php">Logout</a>
        <?php else: ?>
        <a href="/login.php">Sign In</a>
        <?php endif; ?>
    </div>
</div>

<!-- Main header -->
<div class="header">
    <div class="logo-section">
        <div class="logo-icon">UB</div>
        <div class="bank-name">
            <h1>Union Bank of India</h1>
            <p><?php echo $_h_loggedin ? 'Internet Banking Portal' : 'Good People to Bank With'; ?></p>
        </div>
    </div>
    <?php if ($_h_loggedin): ?>
    <div class="header-right">
        Branch: <strong>Mumbai Main</strong> &nbsp;|&nbsp;
        <?php echo date('d M Y, h:i A'); ?> IST
    </div>
    <?php endif; ?>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>

<?php if ($_h_loggedin): ?>
<!-- Notice bar -->
<div class="notice-bar">
    <marquee behavior="scroll" direction="left" scrollamount="3">
        &nbsp;&nbsp;&nbsp;
        ⚠ Security Notice: UBI will NEVER ask for your PIN, OTP, or Password over call, SMS, or email. &nbsp;&nbsp;|&nbsp;&nbsp;
        🔔 NEFT/RTGS timings: Available 24×7 including Sundays and holidays. &nbsp;&nbsp;|&nbsp;&nbsp;
        🛡 RBI Cyber Advisory: Always verify the URL before entering credentials. &nbsp;&nbsp;|&nbsp;&nbsp;
        ✋ Beware of phishing websites. Official domain: unionbankofindia.co.in
        &nbsp;&nbsp;&nbsp;
    </marquee>
</div>

<!-- App container: sidebar + main panel -->
<div class="app-container">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-user">
            <div class="avatar"><?php echo strtoupper(substr($_h_name, 0, 1)); ?></div>
            <div class="name"><?php echo $_h_name; ?></div>
            <div class="role"><?php echo ucfirst($_h_role); ?></div>
        </div>
        <nav class="sidebar-nav">
            <a href="/dashboard.php" class="nav-item <?php echo $_h_cur === 'dashboard.php' ? 'active' : ''; ?>">
                <span class="nav-icon">📊</span> Dashboard
            </a>
            <a href="/transfer.php" class="nav-item <?php echo $_h_cur === 'transfer.php' ? 'active' : ''; ?>">
                <span class="nav-icon">💸</span> Fund Transfer
            </a>
            <a href="/account.php" class="nav-item <?php echo $_h_cur === 'account.php' ? 'active' : ''; ?>">
                <span class="nav-icon">🏦</span> My Account
            </a>
            <a href="/support.php" class="nav-item <?php echo $_h_cur === 'support.php' ? 'active' : ''; ?>">
                <span class="nav-icon">✉️</span> Support
            </a>
            <a href="/profile.php" class="nav-item <?php echo $_h_cur === 'profile.php' ? 'active' : ''; ?>">
                <span class="nav-icon">👤</span> Profile
            </a>
            <?php if (in_array($_h_role, ['admin','banker'])): ?>
            <div class="nav-divider"></div>
            <span class="nav-section">Administration</span>
            <a href="/admin/index.php" class="nav-item <?php echo $_h_cur === 'index.php' && strpos($_SERVER['PHP_SELF'], 'admin') !== false ? 'active' : ''; ?>">
                <span class="nav-icon">🖥</span> Admin Panel
            </a>
            <a href="/admin/tickets.php" class="nav-item <?php echo $_h_cur === 'tickets.php' ? 'active' : ''; ?>">
                <span class="nav-icon">🎫</span> Support Tickets
            </a>
            <a href="/admin/users.php" class="nav-item <?php echo $_h_cur === 'users.php' ? 'active' : ''; ?>">
                <span class="nav-icon">👥</span> User Management
            </a>
            <?php endif; ?>
            <div class="nav-divider"></div>
            <a href="/logout.php" class="nav-item nav-item-danger">
                <span class="nav-icon">🚪</span> Logout
            </a>
        </nav>
    </aside>

    <!-- Main panel -->
    <main class="main-panel">
<?php else: ?>
<main class="main-content">
<?php endif; ?>
