<?php
require_once '/var/www/html/includes/auth.php';
session_init();
$current_user = $_SESSION ?? [];
$is_logged = !empty($current_user['user_id']);
$role = $current_user['role'] ?? 'guest';
$full_name = htmlspecialchars($current_user['full_name'] ?? 'Guest', ENT_QUOTES);
$username  = htmlspecialchars($current_user['username'] ?? '', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Union Bank of India – Internet Banking">
    <title><?= htmlspecialchars($page_title ?? 'Union Bank of India – Internet Banking', ENT_QUOTES) ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="icon" type="image/svg+xml" href="/assets/img/favicon.svg">
</head>
<body>
<!-- Top announcement bar -->
<div class="top-bar">
    <marquee behavior="scroll" direction="left" scrollamount="3">
        &nbsp;&nbsp;&nbsp;
        &#9888; Security Notice: UBI will NEVER ask for your PIN, OTP, or Password over call, SMS, or email.
        &nbsp;&nbsp;|&nbsp;&nbsp;
        &#128276; New NEFT/RTGS timings: Available 24x7 including Sundays and holidays.
        &nbsp;&nbsp;|&nbsp;&nbsp;
        &#128737; RBI Cyber Security Advisory: Always verify the URL before entering credentials.
        &nbsp;&nbsp;|&nbsp;&nbsp;
        &#9995; Beware of phishing websites. Official domain: unibank.in
        &nbsp;&nbsp;&nbsp;
    </marquee>
</div>

<!-- Main header -->
<header class="main-header">
    <div class="header-inner">
        <div class="logo-area">
            <a href="/index.php">
                <div class="ubi-logo">
                    <div class="logo-icon">
                        <svg width="52" height="52" viewBox="0 0 52 52" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="26" cy="26" r="26" fill="#4A148C"/>
                            <text x="26" y="35" text-anchor="middle" font-family="Arial Black,Arial,sans-serif"
                                  font-size="26" font-weight="900" fill="#FFB300">U</text>
                        </svg>
                    </div>
                    <div class="logo-text">
                        <span class="logo-main">Union Bank of India</span>
                        <span class="logo-sub">Good People to Bank With</span>
                    </div>
                </div>
            </a>
        </div>
        <nav class="main-nav">
            <?php if ($is_logged): ?>
                <a href="/dashboard.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
                <a href="/transfer.php"  class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'transfer.php'  ? 'active' : '' ?>">Transfers</a>
                <a href="/support.php"   class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'support.php'   ? 'active' : '' ?>">Support</a>
                <a href="/profile.php"   class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'profile.php'   ? 'active' : '' ?>">Profile</a>
                <?php if (in_array($role, ['admin','banker'])): ?>
                    <a href="/admin/index.php" class="nav-link nav-admin">Admin Panel</a>
                <?php endif; ?>
                <div class="user-menu">
                    <button class="user-btn">
                        <span class="user-avatar"><?= strtoupper(substr($full_name, 0, 1)) ?></span>
                        <span><?= $full_name ?></span>
                        <span class="role-badge role-<?= $role ?>"><?= ucfirst($role) ?></span>
                    </button>
                    <div class="user-dropdown">
                        <a href="/profile.php">My Profile</a>
                        <a href="/logout.php">Logout</a>
                    </div>
                </div>
            <?php else: ?>
                <a href="/login.php" class="btn btn-gold">Login to Internet Banking</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main class="main-content">
