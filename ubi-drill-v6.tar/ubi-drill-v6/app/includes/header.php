<?php
// header.php – called after auth check is complete in each page
// session is already active when this runs
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime'=>7200,'path'=>'/','httponly'=>false,'secure'=>false,'samesite'=>'Lax']);
    session_start();
}
$_hi  = !empty($_SESSION['user_id']);
$_rol = $_SESSION['role'] ?? 'guest';
$_nm  = htmlspecialchars($_SESSION['full_name'] ?? 'Guest', ENT_QUOTES);
$_cur = basename($_SERVER['PHP_SELF'] ?? '');
$_dir = basename(dirname($_SERVER['PHP_SELF'] ?? ''));

$_acc_id = 0;
if ($_hi && $_rol === 'customer') {
    $__s = getDB()->prepare('SELECT id FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1');
    $__s->execute([$_SESSION['user_id']]);
    $__r = $__s->fetch();
    $_acc_id = $__r ? (int)$__r['id'] : 0;
}

function _na($f, $d=null) {
    global $_cur, $_dir;
    return ($_cur===$f && ($d===null || $_dir===$d)) ? ' active' : '';
}
$_pt = htmlspecialchars($page_title ?? 'Union Bank of India - Internet Banking', ENT_QUOTES);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $_pt; ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="top-bar">
    <div>&#9742; Helpdesk: <strong>Ext. 4400</strong> &nbsp;|&nbsp; CBS v4.2.1</div>
    <div class="tb-right">
        <?php if ($_hi): ?>
        Logged in: <strong><?php echo $_nm; ?></strong> (<?php echo ucfirst($_rol); ?>) &nbsp;|&nbsp;<a href="/logout.php">Logout</a>
        <?php else: ?><a href="/login.php">Sign In</a><?php endif; ?>
    </div>
</div>
<div class="header">
    <div class="logo-section">
        <div class="logo-icon">UB</div>
        <div class="bank-name"><h1>Union Bank of India</h1><p><?php echo $_hi?'Internet Banking Portal':'Good People to Bank With'; ?></p></div>
    </div>
    <?php if ($_hi): ?><div class="header-right"><?php echo date('d M Y, h:i A'); ?> IST</div><?php endif; ?>
    <div class="tricolor"><span></span><span></span><span></span></div>
</div>
<?php if ($_hi): ?>
<div class="notice-bar"><marquee scrollamount="3">&#9888; UBI will NEVER ask for your PIN or OTP via call/SMS/email. &nbsp;|&nbsp; NEFT/RTGS available 24x7. &nbsp;|&nbsp; Always verify the URL before logging in.</marquee></div>
<div class="app-container">
    <aside class="sidebar">
        <div class="sidebar-user">
            <div class="avatar"><?php echo strtoupper(substr($_nm,0,1)); ?></div>
            <div class="name"><?php echo $_nm; ?></div>
            <div class="role"><?php echo ucfirst($_rol); ?></div>
        </div>
        <nav class="sidebar-nav">
            <a href="/dashboard.php" class="nav-item<?php echo _na('dashboard.php'); ?>"><span class="nav-icon">&#128202;</span> Dashboard</a>
            <?php if ($_acc_id): ?><a href="/account.php?id=<?php echo $_acc_id; ?>" class="nav-item<?php echo _na('account.php'); ?>"><span class="nav-icon">&#127970;</span> My Account</a><?php endif; ?>
            <a href="/transfer.php" class="nav-item<?php echo _na('transfer.php'); ?>"><span class="nav-icon">&#128184;</span> Fund Transfer</a>
            <a href="/support.php" class="nav-item<?php echo _na('support.php'); ?>"><span class="nav-icon">&#9993;</span> Support</a>
            <a href="/profile.php" class="nav-item<?php echo _na('profile.php'); ?>"><span class="nav-icon">&#128100;</span> Profile</a>
            <?php if (in_array($_rol,['admin','banker'])): ?>
            <div class="nav-divider"></div>
            <span class="nav-section">Administration</span>
            <a href="/admin/index.php" class="nav-item<?php echo _na('index.php','admin'); ?>"><span class="nav-icon">&#128187;</span> Admin Panel</a>
            <a href="/admin/tickets.php" class="nav-item<?php echo _na('tickets.php','admin'); ?>"><span class="nav-icon">&#127905;</span> Tickets</a>
            <a href="/admin/users.php" class="nav-item<?php echo _na('users.php','admin'); ?>"><span class="nav-icon">&#128101;</span> Users</a>
            <?php endif; ?>
            <div class="nav-divider"></div>
            <a href="/logout.php" class="nav-item nav-item-danger"><span class="nav-icon">&#128682;</span> Logout</a>
        </nav>
    </aside>
    <main class="main-panel">
<?php else: ?><main>
<?php endif; ?>
