<?php
require_once '/var/www/html/config/database.php';

// ── Web session auth ────────────────────────────────
function session_init() {
    if (session_status() === PHP_SESSION_NONE) {
        // VULNERABLE: No HttpOnly, no Secure flag (allows JS cookie theft for XSS scenario #4)
        session_set_cookie_params([
            'lifetime' => 7200,
            'path'     => '/',
            'httponly' => false,   // VULNERABLE – intentional for drill
            'secure'   => false,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
}

function check_auth($required_role = null) {
    session_init();
    if (empty($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
    if ($required_role !== null) {
        $roles = is_array($required_role) ? $required_role : [$required_role];
        if (!in_array($_SESSION['role'], $roles)) {
            http_response_code(403);
            include '/var/www/html/includes/header.php';
            echo '<div class="container"><div class="alert alert-danger"><h3>403 – Access Denied</h3><p>You do not have permission to access this page.</p></div></div>';
            include '/var/www/html/includes/footer.php';
            exit;
        }
    }
    return $_SESSION;
}

function is_logged_in() {
    session_init();
    return !empty($_SESSION['user_id']);
}

function login_user($username, $password) {
    $db = getDB();
    $stmt = $db->prepare('SELECT id, username, password, full_name, role, email, phone FROM users WHERE username = ? AND is_active = 1');
    $stmt->execute([trim($username)]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        session_init();
        session_regenerate_id(true);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['role']      = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['email']     = $user['email'];
        // Update last login
        $db->prepare('UPDATE users SET last_login = datetime("now") WHERE id = ?')->execute([$user['id']]);
        return $user;
    }
    return false;
}

function logout_user() {
    session_init();
    $_SESSION = [];
    session_destroy();
}

function get_user_account($user_id) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM accounts WHERE user_id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

// ── REST API token auth ─────────────────────────────
function get_api_token() {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';
    if (preg_match('/Bearer\s+(.+)/i', $h, $m)) return trim($m[1]);
    return $_GET['token'] ?? $_POST['token'] ?? null;
}

function check_api_auth() {
    define('API_REQUEST', true);
    header('Content-Type: application/json');
    $token = get_api_token();
    if (!$token) {
        http_response_code(401);
        die(json_encode(['status' => 'error', 'message' => 'Unauthorized – No token provided']));
    }
    $db = getDB();
    $stmt = $db->prepare('SELECT s.*, u.id AS user_id, u.username, u.role, u.full_name, u.email
                          FROM sessions s JOIN users u ON s.user_id = u.id
                          WHERE s.session_token = ? AND s.expires_at > datetime("now") AND u.is_active = 1');
    $stmt->execute([$token]);
    $session = $stmt->fetch();
    if (!$session) {
        http_response_code(401);
        die(json_encode(['status' => 'error', 'message' => 'Unauthorized – Invalid or expired token']));
    }
    return $session;
}

function api_require_role($auth, $required_role) {
    $roles = is_array($required_role) ? $required_role : [$required_role];
    if (!in_array($auth['role'], $roles)) {
        http_response_code(403);
        die(json_encode(['status' => 'error', 'message' => 'Forbidden – Insufficient privileges']));
    }
}

function generate_token() {
    return bin2hex(random_bytes(32));
}

function create_api_session($user_id) {
    $db = getDB();
    $token = generate_token();
    $expires = date('Y-m-d H:i:s', strtotime('+2 hours'));
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    // Remove old sessions for this user
    $db->prepare('DELETE FROM sessions WHERE user_id = ? AND expires_at < datetime("now")')->execute([$user_id]);
    $stmt = $db->prepare('INSERT INTO sessions (user_id, session_token, expires_at, ip_address) VALUES (?, ?, ?, ?)');
    $stmt->execute([$user_id, $token, $expires, $ip]);
    return $token;
}
