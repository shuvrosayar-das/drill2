<?php
require_once '/var/www/html/config/database.php';

function session_init() {
    if (session_status() === PHP_SESSION_NONE) {
        // VULNERABLE: httponly=false allows JS cookie theft (XSS Scenario #4)
        session_set_cookie_params([
            'lifetime' => 7200,
            'path'     => '/',
            'httponly' => false,
            'secure'   => false,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
}

function is_logged_in() {
    session_init();
    return !empty($_SESSION['user_id']);
}

function check_auth($roles = null) {
    session_init();
    if (empty($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
    if ($roles !== null) {
        $allowed = is_array($roles) ? $roles : [$roles];
        if (!in_array($_SESSION['role'], $allowed)) {
            http_response_code(403);
            $page_title = 'Access Denied';
            include '/var/www/html/includes/header.php';
            echo '<div class="alert alert-danger" style="margin:20px"><h3>403 - Access Denied</h3><p>You do not have permission to view this page.</p><a href="/dashboard.php" class="btn btn-outline">Back to Dashboard</a></div>';
            include '/var/www/html/includes/footer.php';
            exit;
        }
    }
    return $_SESSION;
}

function login_user($username, $password) {
    $db   = getDB();
    $stmt = $db->prepare('SELECT id, username, password, full_name, role, email FROM users WHERE username = ? AND is_active = 1');
    $stmt->execute([trim($username)]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        session_init();
        if (!headers_sent()) { session_regenerate_id(true); }
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['role']      = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $db->prepare('UPDATE users SET last_login = datetime("now") WHERE id = ?')->execute([$user['id']]);
        return $user;
    }
    return false;
}

function logout_user() {
    session_init();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

// API auth
function get_api_token() {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/Bearer\s+(.+)/i', $h, $m)) return trim($m[1]);
    return $_GET['token'] ?? $_POST['token'] ?? null;
}

function check_api_auth() {
    header('Content-Type: application/json');
    $token = get_api_token();
    if (!$token) {
        http_response_code(401);
        die(json_encode(['status' => 'error', 'message' => 'Unauthorized - no token']));
    }
    $db   = getDB();
    $stmt = $db->prepare('SELECT s.user_id, u.username, u.role, u.full_name FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.session_token = ? AND s.expires_at > datetime("now") AND u.is_active = 1');
    $stmt->execute([$token]);
    $sess = $stmt->fetch();
    if (!$sess) {
        http_response_code(401);
        die(json_encode(['status' => 'error', 'message' => 'Unauthorized - invalid or expired token']));
    }
    return $sess;
}

function create_api_session($user_id) {
    $db      = getDB();
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+2 hours'));
    $ip      = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $db->prepare('DELETE FROM sessions WHERE user_id = ? AND expires_at < datetime("now")')->execute([$user_id]);
    $db->prepare('INSERT INTO sessions (user_id, session_token, expires_at, ip_address) VALUES (?,?,?,?)')->execute([$user_id, $token, $expires, $ip]);
    return $token;
}
