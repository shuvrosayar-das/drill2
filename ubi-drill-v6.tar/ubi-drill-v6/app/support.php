<?php
// ================================================================
//  Union Bank of India – Customer Support
//  VULNERABLE: Stored XSS – message stored raw, executes when admin views tickets
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session  = check_auth();
$page_title = 'Customer Support – Union Bank of India';

$db  = getDB();
$msg = $err = '';

$ticket_stmt = $db->prepare("SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC");
$ticket_stmt->execute([$session['user_id']]);
$my_tickets = $ticket_stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = $_POST['message'] ?? '';  // VULNERABLE: NOT sanitised before storage

    if (empty($subject) || strlen($subject) > 200) {
        $err = 'Please enter a valid subject (max 200 characters).';
    } elseif (empty($message)) {
        $err = 'Message cannot be empty.';
    } else {
        // VULNERABLE: Raw unsanitised message stored directly into DB
        $stmt = $db->prepare("INSERT INTO support_tickets (user_id, username, subject, message, status) VALUES (?,?,?,?,?)");
        $stmt->execute([$session['user_id'], $session['username'], $subject, $message, 'open']);
        $msg = 'Request submitted. Reference: SR' . $db->lastInsertId() . '. Our team will respond within 2 business days.';
        $ticket_stmt->execute([$session['user_id']]);
        $my_tickets = $ticket_stmt->fetchAll();
    }
}
include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>✉️ Customer Support</h2>
    <p class="breadcrumb"><a href="/dashboard.php">Dashboard</a> › Support</p>
</div>

<div class="content-grid">
    <div>
        <!-- Submit ticket -->
        <div class="card">
            <div class="card-header"><h3>📝 Raise a New Request</h3></div>
            <div class="card-body">
                <?php if ($msg): ?><div class="alert alert-success">✅ <?php echo htmlspecialchars($msg, ENT_QUOTES); ?></div><?php endif; ?>
                <?php if ($err): ?><div class="alert alert-danger">⚠ <?php echo htmlspecialchars($err, ENT_QUOTES); ?></div><?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label>Category / Subject</label>
                        <select name="subject" class="form-control">
                            <option value="">— Select issue type —</option>
                            <option>Net Banking Login Issue</option>
                            <option>Transaction Dispute / Failed Transfer</option>
                            <option>Debit / Credit Card Issue</option>
                            <option>Account Statement Request</option>
                            <option>KYC Update Request</option>
                            <option>Loan Enquiry</option>
                            <option>Fixed Deposit Enquiry</option>
                            <option>Feedback / Suggestion</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Describe your issue</label>
                        <!-- VULNERABLE: input stored raw — no htmlspecialchars or strip_tags -->
                        <textarea name="message" class="form-control" rows="6" placeholder="Please describe your issue in detail. Include transaction IDs, dates, and amounts where applicable." required></textarea>
                        <div class="form-hint">🔒 Your message is encrypted in transit. Do not share OTP or passwords.</div>
                    </div>
                    <button type="submit" class="btn btn-primary">📨 Submit Request</button>
                </form>
            </div>
        </div>

        <!-- My tickets -->
        <div class="card">
            <div class="card-header"><h3>📋 My Support Requests</h3></div>
            <div class="card-body no-pad">
                <?php if (empty($my_tickets)): ?>
                <div class="empty-state"><div class="icon">📋</div><p>No support requests raised yet.</p></div>
                <?php else: ?>
                <?php foreach ($my_tickets as $tk): ?>
                <div class="ticket-card" style="margin:12px;">
                    <div class="ticket-head">
                        <div>
                            <strong>SR<?php echo $tk['id']; ?> — <?php echo htmlspecialchars($tk['subject'], ENT_QUOTES); ?></strong>
                        </div>
                        <span class="badge <?php echo $tk['status'] === 'open' ? 'badge-warning' : 'badge-success'; ?>">
                            <?php echo strtoupper($tk['status']); ?>
                        </span>
                    </div>
                    <div class="ticket-body">
                        <div class="ticket-meta">Submitted: <?php echo date('d M Y, h:i A', strtotime($tk['created_at'])); ?></div>
                        <!-- Safe to display here — user only sees own tickets -->
                        <div style="margin-top:8px;"><?php echo htmlspecialchars($tk['message'], ENT_QUOTES); ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Contact info -->
    <div>
        <div class="card">
            <div class="card-header"><h3>📞 Contact Us</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">Toll-Free</span><span class="info-value"><strong>1800-22-2244</strong></span></div>
                <div class="info-row"><span class="info-label">Helpdesk</span><span class="info-value">1800-208-2244</span></div>
                <div class="info-row"><span class="info-label">Email</span><span class="info-value">care@unionbank.in</span></div>
                <div class="info-row"><span class="info-label">Hours</span><span class="info-value">8AM–8PM (Mon–Sat)</span></div>
                <div class="info-row"><span class="info-label">Fraud Hotline</span><span class="info-value text-danger"><strong>1800-111-109</strong></span></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3>ℹ Response Time</h3></div>
            <div class="card-body" style="font-size:13px;line-height:2;">
                • <strong>Critical:</strong> 4 hours<br>
                • <strong>High:</strong> 1 business day<br>
                • <strong>Normal:</strong> 2–3 business days<br>
                • <strong>Feedback:</strong> 5 business days
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3>📄 Grievance Escalation</h3></div>
            <div class="card-body" style="font-size:12.5px;line-height:1.8;">
                If not resolved within 30 days, escalate to RBI's <strong>Banking Ombudsman Scheme</strong>:<br>
                <a href="https://cms.rbi.org.in" target="_blank" style="color:var(--primary);">cms.rbi.org.in</a><br><br>
                <span class="text-muted">Nodal Officer: Grievance Redressal Cell, Union Bank of India, Central Office, Mumbai – 400 021</span>
            </div>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
