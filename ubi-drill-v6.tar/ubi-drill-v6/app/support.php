<?php
// VULNERABLE: Stored XSS - message stored raw (Scenario #4)
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth();
$page_title = 'Support - Union Bank of India';
$db = getDB();
$msg = $err = '';

$tk_st = $db->prepare('SELECT id, subject, message, status, created_at FROM support_tickets WHERE user_id=? ORDER BY created_at DESC');
$tk_st->execute([$session['user_id']]);
$tickets = $tk_st->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject']??'');
    $message = $_POST['message']??'';  // VULNERABLE: raw, unsanitised
    if ($subject === '') {
        $err = 'Please select a category.';
    } elseif (trim($message) === '') {
        $err = 'Message cannot be empty.';
    } else {
        // VULNERABLE: raw message directly inserted
        $db->prepare('INSERT INTO support_tickets (user_id,username,subject,message,status) VALUES (?,?,?,?,?)')->execute([$session['user_id'],$session['username'],$subject,$message,'open']);
        $msg = 'Request submitted. Reference: SR'.$db->lastInsertId().'. Response within 2 business days.';
        $tk_st->execute([$session['user_id']]);
        $tickets = $tk_st->fetchAll();
    }
}
include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>&#9993; Customer Support</h2>
    <p class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &#8250; Support</p>
</div>
<div class="content-grid">
    <div>
        <div class="card">
            <div class="card-header"><h3>Raise a New Request</h3></div>
            <div class="card-body">
                <?php if ($msg!==''): ?><div class="alert alert-success">&#10003; <?php echo htmlspecialchars($msg,ENT_QUOTES); ?></div><?php endif; ?>
                <?php if ($err!==''): ?><div class="alert alert-danger">&#9888; <?php echo htmlspecialchars($err,ENT_QUOTES); ?></div><?php endif; ?>
                <form method="POST" action="/support.php">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="subject" class="form-control" required>
                            <option value="">-- Select issue type --</option>
                            <option>Net Banking Login Issue</option>
                            <option>Transaction Dispute / Failed Transfer</option>
                            <option>Debit / Credit Card Issue</option>
                            <option>Account Statement Request</option>
                            <option>KYC Update Request</option>
                            <option>Loan Enquiry</option>
                            <option>Feedback / Suggestion</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Describe your issue</label>
                        <textarea name="message" class="form-control" rows="5" placeholder="Describe in detail. Include TXN IDs, dates, amounts." required></textarea>
                        <div class="form-hint">Do not share OTP or passwords in your message.</div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Request</button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3>My Support Requests</h3></div>
            <div class="card-body no-pad">
                <?php if (empty($tickets)): ?><div class="empty-state"><div class="icon">&#128203;</div><p>No requests raised yet.</p></div>
                <?php else: ?>
                <?php foreach ($tickets as $tk): ?>
                <div class="ticket-card" style="margin:12px;">
                    <div class="ticket-head">
                        <div><strong>SR<?php echo (int)$tk['id']; ?></strong> &#8212; <?php echo htmlspecialchars($tk['subject'],ENT_QUOTES); ?></div>
                        <span class="badge <?php echo $tk['status']==='open'?'badge-warning':'badge-success'; ?>"><?php echo strtoupper(htmlspecialchars($tk['status'],ENT_QUOTES)); ?></span>
                    </div>
                    <div class="ticket-body">
                        <div class="ticket-meta"><?php echo date('d M Y, h:i A',strtotime($tk['created_at'])); ?></div>
                        <div style="margin-top:6px;"><?php echo htmlspecialchars($tk['message'],ENT_QUOTES); ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div>
        <div class="card"><div class="card-header"><h3>Contact Us</h3></div><div class="card-body">
            <div class="info-row"><span class="info-label">Toll-Free</span><span class="info-value"><strong>1800-22-2244</strong></span></div>
            <div class="info-row"><span class="info-label">Helpdesk</span><span class="info-value">1800-208-2244</span></div>
            <div class="info-row"><span class="info-label">Email</span><span class="info-value">care@unionbank.in</span></div>
            <div class="info-row"><span class="info-label">Hours</span><span class="info-value">8AM-8PM Mon-Sat</span></div>
            <div class="info-row"><span class="info-label">Fraud</span><span class="info-value text-danger"><strong>1800-111-109</strong></span></div>
        </div></div>
    </div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
