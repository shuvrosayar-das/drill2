<?php
// ================================================================
//  Union Bank of India – Customer Support
//  VULNERABLE: Stored XSS – message stored raw in DB without sanitisation
//  When admin views tickets.php, the script executes (cookie theft)
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth();

$db = getDB();
$msg = $err = '';

// Get user's own tickets
$ticket_stmt = $db->prepare("SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC");
$ticket_stmt->execute([$session['user_id']]);
$my_tickets = $ticket_stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = $_POST['message'] ?? '';   // VULNERABLE: NOT sanitised before storage

    if (empty($subject) || strlen($subject) > 200) {
        $err = 'Please enter a valid subject (max 200 characters).';
    } elseif (empty($message)) {
        $err = 'Message cannot be empty.';
    } else {
        // VULNERABLE: Raw unsanitised message stored directly into DB
        $stmt = $db->prepare("INSERT INTO support_tickets (user_id, username, subject, message, status) VALUES (?,?,?,?,?)");
        $stmt->execute([$session['user_id'], $session['username'], $subject, $message, 'open']);
        $msg = 'Your support request has been submitted. Reference ID: SR' . $db->lastInsertId() . '. Our team will respond within 2 business days.';
        // Refresh
        $ticket_stmt->execute([$session['user_id']]);
        $my_tickets = $ticket_stmt->fetchAll();
    }
}
include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#128172; Customer Support</h1>
      <div class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &rsaquo; Support</div>
    </div>
  </div>
</div>

<div class="main-content">
<div class="container">
<div class="dashboard-grid">
  <div>
    <div class="card mb-4">
      <div class="card-header">&#128394; Raise a New Request</div>
      <div class="card-body">
        <?php if ($msg): ?><div class="alert alert-success">&#9989; <?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-danger">&#9888; <?= htmlspecialchars($err) ?></div><?php endif; ?>
        <form method="POST">
          <div class="form-group">
            <label>Category / Subject</label>
            <select name="subject" class="form-control">
              <option value="">-- Select issue type --</option>
              <option>Net Banking Login Issue</option>
              <option>Transaction Dispute / Failed Transfer</option>
              <option>Debit / Credit Card Issue</option>
              <option>Account Statement Request</option>
              <option>KYC Update Request</option>
              <option>Loan Enquiry</option>
              <option>Fixed Deposit Enquiry</option>
              <option>Feedback / Suggestion</option>
              <option>Other</option>
            </select>
          </div>
          <div class="form-group">
            <label>Describe your issue</label>
            <!-- VULNERABLE: input stored raw (no htmlspecialchars or strip_tags) -->
            <textarea name="message" class="form-control" rows="6" placeholder="Please describe your issue in detail. Include transaction IDs, dates, and amounts where applicable." required></textarea>
            <div class="form-hint">&#128274; Your message is encrypted in transit. Do not share OTP or passwords.</div>
          </div>
          <button type="submit" class="btn btn-primary">&#128228; Submit Request</button>
        </form>
      </div>
    </div>

    <!-- My Tickets -->
    <div class="card">
      <div class="card-header">&#128203; My Support Requests</div>
      <div class="card-body" style="padding:0;">
        <?php if (empty($my_tickets)): ?>
        <div class="empty-state"><div class="icon">&#128203;</div><p>No support requests raised yet.</p></div>
        <?php else: ?>
        <?php foreach ($my_tickets as $tk): ?>
        <div class="ticket-card" style="margin:12px;">
          <div class="ticket-header">
            <span>SR<?= $tk['id'] ?> &mdash; <?= htmlspecialchars($tk['subject']) ?></span>
            <span class="ticket-status-<?= $tk['status'] === 'open' ? 'open' : 'resolved' ?>">
              <?= strtoupper($tk['status']) ?>
            </span>
          </div>
          <div class="ticket-body">
            <div style="color:var(--ubi-grey);font-size:11.5px;margin-bottom:6px;">
              Submitted: <?= date('d M Y, h:i A', strtotime($tk['created_at'])) ?>
            </div>
            <!-- Display is safe here as only the user sees own tickets -->
            <?= htmlspecialchars($tk['message']) ?>
          </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div>
    <div class="card mb-4">
      <div class="card-header">&#128222; Contact Us</div>
      <div class="card-body">
        <div class="kyc-row"><div class="kyc-label">Toll-Free</div><div class="kyc-value"><strong>1800-22-2244</strong></div></div>
        <div class="kyc-row"><div class="kyc-label">Helpdesk</div><div class="kyc-value">1800-208-2244</div></div>
        <div class="kyc-row"><div class="kyc-label">Email</div><div class="kyc-value">care@unibank.in</div></div>
        <div class="kyc-row"><div class="kyc-label">Hours</div><div class="kyc-value">8AM–8PM (Mon–Sat)</div></div>
        <div class="kyc-row"><div class="kyc-label">Fraud Hotline</div><div class="kyc-value" style="color:var(--ubi-danger);font-weight:700;">1800-111-109</div></div>
      </div>
    </div>
    <div class="card mb-4">
      <div class="card-header">&#8505; Response Time</div>
      <div class="card-body" style="font-size:13px;line-height:1.8;">
        &#8226; <strong>Critical:</strong> 4 hours<br>
        &#8226; <strong>High:</strong> 1 business day<br>
        &#8226; <strong>Normal:</strong> 2–3 business days<br>
        &#8226; <strong>Feedback:</strong> 5 business days
      </div>
    </div>
    <div class="card">
      <div class="card-header">&#128196; Grievance Escalation</div>
      <div class="card-body" style="font-size:12.5px;line-height:1.7;">
        <p>If not resolved within 30 days, escalate to RBI's <strong>Banking Ombudsman Scheme</strong>:</p>
        <p><a href="https://rbi.org.in" target="_blank">cms.rbi.org.in</a></p>
        <p class="text-muted" style="margin-top:8px;">Nodal Officer: Grievance Redressal Cell, Union Bank of India, Central Office, Mumbai – 400 021</p>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
