<?php
require_once '/var/www/html/includes/auth.php';
session_init();
logout_user();
header('Location: /login.php');
exit;
