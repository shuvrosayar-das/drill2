<?php
// ================================================================
//  Union Bank of India – API: Account Query
//  VULNERABLE: SQL Injection – raw string concat on acc_no parameter
//  Attack Scenario #2: UNION-based injection dumps users table
//  e.g. acc_no=' UNION SELECT 1,username,password,email,phone,pan,aadhaar,role,is_active,datetime('now'),null FROM users--
//  Banking Impact: Exposes account numbers, balances, PAN, Aadhaar, credentials
// ================================================================
define('API_REQUEST', true);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$auth = check_api_auth();    // Token auth required — but SQLi bypasses the data layer entirely
$db   = getDB();

// ── SQL INJECTION VULNERABILITY ────────────────────────────────
// acc_no taken from GET parameter and concatenated raw into query
// No prepared statement, no escaping, no validation
$acc_no = $_GET['acc_no'] ?? '';

if (empty($acc_no)) {
    // Return all accounts the user can see (for admin/banker – role-aware, secure)
    if (in_array($auth['role'], ['admin', 'banker'])) {
        $rows = $db->query("SELECT a.id, a.account_number, a.account_type, a.balance, a.ifsc, a.is_active, u.full_name, u.username
                            FROM accounts a JOIN users u ON a.user_id = u.id ORDER BY a.id")->fetchAll();
        echo json_encode(['status' => 'success', 'count' => count($rows), 'data' => $rows]);
    } else {
        // Customers see only their own account (secure path)
        $acc = get_user_account($auth['user_id']);
        echo json_encode(['status' => 'success', 'data' => $acc ?: []]);
    }
    exit;
}

// VULNERABLE: Raw string concatenation — attacker controls $acc_no
// Secure code would use: $stmt = $db->prepare("... WHERE a.account_number = ?"); $stmt->execute([$acc_no]);
$query = "SELECT a.id, a.account_number, a.account_type, a.balance, a.currency, a.ifsc, a.branch_code, "
       . "a.is_active, a.created_at, u.full_name, u.username, u.email, u.phone, u.pan, u.aadhaar, u.role "
       . "FROM accounts a JOIN users u ON a.user_id = u.id "
       . "WHERE a.account_number = '" . $acc_no . "'";   // ← INJECTION POINT

try {
    // query() used intentionally (not prepare) to allow multi-statement injection
    $result = $db->query($query);
    $rows   = $result ? $result->fetchAll() : [];

    if (empty($rows)) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Account not found', 'query_debug' => $query]);
    } else {
        echo json_encode(['status' => 'success', 'count' => count($rows), 'data' => $rows]);
    }
} catch (Exception $e) {
    // VULNERABLE: Error message reveals DB structure (aids SQLi enumeration)
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage(), 'query' => $query]);
}
