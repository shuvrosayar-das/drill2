<?php
// ================================================================
//  Union Bank of India – API: Logout
// ================================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$auth = check_api_auth();
$db   = getDB();
$db->prepare("DELETE FROM sessions WHERE user_id = ?")->execute([$auth['user_id']]);

echo json_encode(['status' => 'success', 'message' => 'Logged out successfully']);
