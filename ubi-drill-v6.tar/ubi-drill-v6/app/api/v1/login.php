<?php
// ================================================================
//  Union Bank of India – API: Login / Token Issuance
// ================================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['status' => 'error', 'message' => 'Method Not Allowed']));
}

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$input = json_decode(file_get_contents('php://input'), true);
// Also support form-encoded
if (!$input) {
    $input = ['username' => $_POST['username'] ?? '', 'password' => $_POST['password'] ?? ''];
}

$username = trim($input['username'] ?? '');
$password = $input['password'] ?? '';

if (empty($username) || empty($password)) {
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'username and password are required']));
}

$user = login_user($username, $password);
if (!$user) {
    http_response_code(401);
    die(json_encode(['status' => 'error', 'message' => 'Invalid credentials']));
}

$token = create_api_session($user['id']);

// Get account info if customer
$db = getDB();
$acc = get_user_account($user['id']);

http_response_code(200);
echo json_encode([
    'status' => 'success',
    'data'   => [
        'token'          => $token,
        'token_type'     => 'Bearer',
        'expires_in'     => 7200,
        'user_id'        => $user['id'],
        'username'       => $user['username'],
        'full_name'      => $user['full_name'],
        'role'           => $user['role'],
        'account_number' => $acc ? $acc['account_number'] : null,
    ]
]);
