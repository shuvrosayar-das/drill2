<?php
// ================================================================
//  Union Bank of India – API: Single Account Detail
//  VULNERABLE: IDOR – account id from URL, no user_id ownership check
// ================================================================
define('API_REQUEST', true);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$auth = check_api_auth();
$db   = getDB();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'Valid id parameter required']));
}

// VULNERABLE: No WHERE user_id = $auth['user_id'] check
$stmt = $db->prepare("SELECT a.*, u.full_name, u.email, u.phone, u.pan, u.aadhaar, u.username
                      FROM accounts a JOIN users u ON a.user_id = u.id WHERE a.id = ?");
$stmt->execute([$id]);
$account = $stmt->fetch();

if (!$account) {
    http_response_code(404);
    die(json_encode(['status' => 'error', 'message' => 'Account not found']));
}

$kyc_stmt = $db->prepare("SELECT * FROM kyc WHERE user_id = ?");
$kyc_stmt->execute([$account['user_id']]);
$kyc = $kyc_stmt->fetch();

echo json_encode(['status' => 'success', 'data' => array_merge($account, ['kyc' => $kyc])]);
