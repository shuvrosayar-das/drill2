<?php
// ================================================================
//  Union Bank of India – API: Fund Transfer
// ================================================================
define('API_REQUEST', true);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['status' => 'error', 'message' => 'Method Not Allowed']));
}

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$auth  = check_api_auth();
$db    = getDB();
$input = json_decode(file_get_contents('php://input'), true) ?: [];

$to_acc   = trim($input['to_account'] ?? '');
$amount   = (float)($input['amount'] ?? 0);
$txn_type = strtoupper(trim($input['txn_type'] ?? 'NEFT'));
$remarks  = trim($input['remarks'] ?? '');
$ben_name = trim($input['beneficiary_name'] ?? '');

if (empty($to_acc) || $amount <= 0) {
    http_response_code(422);
    die(json_encode(['status' => 'error', 'message' => 'to_account and amount are required']));
}
if (!in_array($txn_type, ['NEFT', 'RTGS', 'IMPS'])) {
    http_response_code(422);
    die(json_encode(['status' => 'error', 'message' => 'txn_type must be NEFT, RTGS, or IMPS']));
}

$from_acc = get_user_account($auth['user_id']);
if (!$from_acc) {
    http_response_code(404);
    die(json_encode(['status' => 'error', 'message' => 'Sender account not found']));
}
if ($amount > $from_acc['balance']) {
    http_response_code(422);
    die(json_encode(['status' => 'error', 'message' => 'Insufficient balance']));
}

// Debit
$db->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?")->execute([$amount, $from_acc['id']]);
// Credit if internal
$ben_stmt = $db->prepare("SELECT id FROM accounts WHERE account_number = ?");
$ben_stmt->execute([$to_acc]);
$ben = $ben_stmt->fetch();
if ($ben) {
    $db->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?")->execute([$amount, $ben['id']]);
}

$txn_id = 'UBI' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
$desc   = $txn_type . ' to ' . $to_acc . ($ben_name ? ' (' . $ben_name . ')' : '') . ($remarks ? ' - ' . $remarks : '');
$db->prepare("INSERT INTO transactions (account_id, txn_id, txn_type, amount, direction, description, beneficiary, beneficiary_acc) VALUES (?,?,?,?,?,?,?,?)")
   ->execute([$from_acc['id'], $txn_id, $txn_type, $amount, 'DEBIT', $desc, $ben_name, $to_acc]);
$db->prepare("INSERT INTO transfers (from_account, to_account, beneficiary, amount, txn_type, remarks, initiated_by) VALUES (?,?,?,?,?,?,?)")
   ->execute([$from_acc['account_number'], $to_acc, $ben_name, $amount, $txn_type, $remarks, $auth['user_id']]);

echo json_encode([
    'status'  => 'success',
    'message' => 'Transfer initiated successfully',
    'data'    => ['txn_id' => $txn_id, 'amount' => $amount, 'to_account' => $to_acc, 'txn_type' => $txn_type]
]);
