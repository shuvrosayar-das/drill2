<?php
// ================================================================
//  Union Bank of India – API: Profile (Secure)
// ================================================================
define('API_REQUEST', true);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$auth = check_api_auth();
$db   = getDB();

$stmt = $db->prepare("SELECT u.id, u.username, u.full_name, u.email, u.phone, u.pan, u.role, u.created_at, u.last_login,
                             a.account_number, a.account_type, a.balance, a.ifsc
                      FROM users u LEFT JOIN accounts a ON a.user_id = u.id
                      WHERE u.id = ?");
$stmt->execute([$auth['user_id']]);
$profile = $stmt->fetch();

echo json_encode(['status' => 'success', 'data' => $profile]);
