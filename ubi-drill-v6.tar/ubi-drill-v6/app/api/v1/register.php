<?php
// ================================================================
//  Union Bank of India – API: User Registration
//  VULNERABLE: Mass Assignment – role field accepted from user input
//  Attack Scenario #1: POST {"username":"hacker","role":"admin",...}
//  Results in: anonymous user self-registers as admin, bypasses maker-checker
// ================================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['status' => 'error', 'message' => 'Method Not Allowed']));
}

require_once '/var/www/html/config/database.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'Invalid JSON body']));
}

$username  = trim($input['username'] ?? '');
$password  = $input['password'] ?? '';
$full_name = trim($input['full_name'] ?? '');
$email     = trim($input['email'] ?? '');
$phone     = trim($input['phone'] ?? '');
$pan       = strtoupper(trim($input['pan'] ?? ''));

// ── MASS ASSIGNMENT VULNERABILITY ──────────────────────────────
// VULNERABLE: 'role' field taken directly from user-supplied JSON
// No whitelist check — attacker can pass "role":"admin" or "role":"banker"
// A secure implementation would hardcode: $role = 'customer';
$role = $input['role'] ?? 'customer';   // VULNERABLE – attacker controls this
// ───────────────────────────────────────────────────────────────

// Basic validation
if (strlen($username) < 3 || strlen($username) > 50) {
    http_response_code(422);
    die(json_encode(['status' => 'error', 'message' => 'Username must be 3–50 characters']));
}
if (strlen($password) < 6) {
    http_response_code(422);
    die(json_encode(['status' => 'error', 'message' => 'Password must be at least 6 characters']));
}
if (empty($full_name)) {
    http_response_code(422);
    die(json_encode(['status' => 'error', 'message' => 'full_name is required']));
}

$db = getDB();

// Check username uniqueness
$check = $db->prepare("SELECT id FROM users WHERE username = ?");
$check->execute([$username]);
if ($check->fetch()) {
    http_response_code(409);
    die(json_encode(['status' => 'error', 'message' => 'Username already exists']));
}

// Insert user — role comes directly from input (VULNERABLE)
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (username, password, full_name, email, phone, pan, role, is_active) VALUES (?,?,?,?,?,?,?,1)");
$stmt->execute([$username, $hash, $full_name, $email, $phone, $pan, $role]);
$new_id = $db->lastInsertId();

// Create savings account for the new user (account_number generated)
$acc_number = 'UBI' . str_pad($new_id + 400, 9, '0', STR_PAD_LEFT) . rand(10000, 99999);
$db->prepare("INSERT INTO accounts (user_id, account_number, account_type, balance) VALUES (?,?,?,?)")
   ->execute([$new_id, $acc_number, 'SAVINGS', 0.0]);

http_response_code(201);
echo json_encode([
    'status'  => 'success',
    'message' => 'Registration successful',
    'data'    => [
        'user_id'        => $new_id,
        'username'       => $username,
        'role'           => $role,          // Role echoed back — confirms mass assignment
        'account_number' => $acc_number,
    ]
]);
