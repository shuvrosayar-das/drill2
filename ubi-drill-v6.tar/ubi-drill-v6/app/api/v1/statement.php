<?php
// ================================================================
//  Union Bank of India – API: Account Statement
//  VULNERABLE: BOLA (Broken Object Level Authorisation)
//  Attack Scenario #6: Authenticated user can retrieve any account's
//  full transaction history by supplying any account_number
//  Banking Impact: Full transaction history of all customers accessible
// ================================================================
define('API_REQUEST', true);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';

$auth = check_api_auth();   // Authentication check: token required — user MUST be logged in
$db   = getDB();

$account_number = trim($_GET['account_number'] ?? '');
$limit  = max(1, min(100, (int)($_GET['limit']  ?? 50)));
$offset = max(0, (int)($_GET['offset'] ?? 0));
$from   = $_GET['from'] ?? '';
$to     = $_GET['to']   ?? '';

if (empty($account_number)) {
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'account_number parameter is required']));
}

// ── BOLA VULNERABILITY ─────────────────────────────────────────
// Authentication is present (token required) but authorisation is missing
// There is NO check: WHERE user_id = $auth['user_id']
// Any authenticated user can query any account_number and get its statement
//
// SECURE code would add: AND a.user_id = ? with $auth['user_id'] bound
// ──────────────────────────────────────────────────────────────

// Lookup account — VULNERABLE: no user_id ownership check
$acc_stmt = $db->prepare("SELECT a.*, u.full_name, u.username FROM accounts a JOIN users u ON a.user_id = u.id WHERE a.account_number = ?");
$acc_stmt->execute([$account_number]);
$account = $acc_stmt->fetch();

if (!$account) {
    http_response_code(404);
    die(json_encode(['status' => 'error', 'message' => 'Account not found']));
}

// Build transaction query with optional date filter
$where = "WHERE t.account_id = ?";
$params = [$account['id']];

if ($from) { $where .= " AND DATE(t.created_at) >= ?"; $params[] = $from; }
if ($to)   { $where .= " AND DATE(t.created_at) <= ?"; $params[] = $to; }

$txn_query = "SELECT t.txn_id, t.txn_type, t.amount, t.direction, t.description,
                     t.beneficiary, t.beneficiary_acc, t.status, t.created_at
              FROM transactions t
              $where
              ORDER BY t.created_at DESC
              LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$txn_stmt = $db->prepare($txn_query);
$txn_stmt->execute($params);
$transactions = $txn_stmt->fetchAll();

// Count total
$count_stmt = $db->prepare("SELECT COUNT(*) FROM transactions t $where");
$count_params = array_slice($params, 0, -2);
$count_stmt->execute($count_params);
$total = $count_stmt->fetchColumn();

// Summary
$summary_stmt = $db->prepare(
    "SELECT SUM(CASE WHEN direction='CREDIT' THEN amount ELSE 0 END) AS total_credit,
            SUM(CASE WHEN direction='DEBIT'  THEN amount ELSE 0 END) AS total_debit,
            COUNT(*) AS txn_count
     FROM transactions WHERE account_id = ?"
);
$summary_stmt->execute([$account['id']]);
$summary = $summary_stmt->fetch();

http_response_code(200);
echo json_encode([
    'status' => 'success',
    'data'   => [
        'account' => [
            'account_number' => $account['account_number'],
            'account_type'   => $account['account_type'],
            'account_holder' => $account['full_name'],    // PII exposed via BOLA
            'ifsc'           => $account['ifsc'],
            'balance'        => $account['balance'],
            'currency'       => $account['currency'],
        ],
        'statement_period' => [
            'from'  => $from ?: 'all time',
            'to'    => $to   ?: 'present',
            'limit' => $limit,
            'offset'=> $offset,
            'total' => (int)$total,
        ],
        'summary'      => $summary,
        'transactions' => $transactions,
    ]
]);
