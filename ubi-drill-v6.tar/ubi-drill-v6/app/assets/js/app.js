/* ================================================================
   Union Bank of India – Internet Banking Portal
   Application JS
   ================================================================ */

// ── Toast Notification ──────────────────────────────
function showToast(message, type) {
  var container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  var t = document.createElement('div');
  t.className = 'toast ' + (type || '');
  t.textContent = message;
  container.appendChild(t);
  setTimeout(function() { t.classList.add('show'); }, 10);
  setTimeout(function() {
    t.classList.remove('show');
    setTimeout(function() { t.remove(); }, 300);
  }, 3500);
}

// ── Login Tabs ──────────────────────────────────────
function initLoginTabs() {
  var tabs = document.querySelectorAll('.login-tab');
  var panels = document.querySelectorAll('.login-panel');
  tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
      var target = this.getAttribute('data-tab');
      tabs.forEach(function(t) { t.classList.remove('active'); });
      panels.forEach(function(p) { p.style.display = 'none'; });
      this.classList.add('active');
      var panel = document.getElementById('panel-' + target);
      if (panel) panel.style.display = 'block';
    });
  });
  // Show first tab by default
  if (panels.length) { panels[0].style.display = 'block'; }
  if (tabs.length)   { tabs[0].classList.add('active'); }
  for (var i = 1; i < panels.length; i++) { panels[i].style.display = 'none'; }
}

// ── Register Form (Mass Assignment vuln #1) ─────────
function initRegisterForm() {
  var form = document.getElementById('register-form');
  if (!form) return;
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    var msg = document.getElementById('reg-msg');
    var payload = {
      username:  document.getElementById('reg-username').value.trim(),
      password:  document.getElementById('reg-password').value,
      full_name: document.getElementById('reg-fullname').value.trim(),
      email:     document.getElementById('reg-email').value.trim(),
      phone:     document.getElementById('reg-phone').value.trim(),
      pan:       document.getElementById('reg-pan').value.trim()
    };
    // NOTE: role field intentionally submitted if present in form (mass assignment vuln)
    var roleField = document.getElementById('reg-role');
    if (roleField && roleField.value) { payload.role = roleField.value; }

    fetch('/api/v1/register.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.status === 'success') {
        msg.className = 'alert alert-success';
        msg.textContent = 'Registration successful! You may now log in.';
        form.reset();
      } else {
        msg.className = 'alert alert-danger';
        msg.textContent = data.message || 'Registration failed.';
      }
      msg.style.display = 'block';
    })
    .catch(function() {
      msg.className = 'alert alert-danger';
      msg.textContent = 'Network error. Please try again.';
      msg.style.display = 'block';
    });
  });
}

// ── Transfer Amount Formatting ─────────────────────
function initTransferForm() {
  var amtInput = document.getElementById('transfer-amount');
  var wordsSpan = document.getElementById('amount-words');
  if (!amtInput) return;
  amtInput.addEventListener('input', function() {
    var val = parseFloat(this.value);
    if (!isNaN(val) && val > 0 && wordsSpan) {
      wordsSpan.textContent = numberToWords(val) + ' Rupees Only';
    } else if (wordsSpan) {
      wordsSpan.textContent = '';
    }
  });
}

// ── Confirm Transfer ────────────────────────────────
function confirmTransfer() {
  var modal = document.getElementById('confirm-modal');
  if (modal) modal.style.display = 'flex';
  return false;
}
function closeModal(id) {
  var modal = document.getElementById(id);
  if (modal) modal.style.display = 'none';
}

// ── Number to Words (simplified for INR) ───────────
function numberToWords(num) {
  var units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
               'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
               'Seventeen', 'Eighteen', 'Nineteen'];
  var tens  = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  if (num === 0) return 'Zero';
  if (num < 0) return 'Negative ' + numberToWords(-num);
  var result = '';
  var crore = Math.floor(num / 10000000); num %= 10000000;
  var lakh  = Math.floor(num / 100000);  num %= 100000;
  var thousand = Math.floor(num / 1000); num %= 1000;
  var hundred  = Math.floor(num / 100);  num %= 100;
  if (crore)   result += numberToWords(crore) + ' Crore ';
  if (lakh)    result += numberToWords(lakh) + ' Lakh ';
  if (thousand) result += numberToWords(thousand) + ' Thousand ';
  if (hundred)  result += units[hundred] + ' Hundred ';
  if (num > 0) {
    if (num < 20) result += units[num];
    else result += tens[Math.floor(num / 10)] + (num % 10 ? ' ' + units[num % 10] : '');
  }
  return result.trim();
}

// ── Format currency ─────────────────────────────────
function formatINR(amount) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(amount);
}

// ── Confirm before dangerous action ────────────────
function confirmAction(msg) {
  return confirm(msg || 'Are you sure?');
}

// ── Auto-dismiss alerts ─────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  initLoginTabs();
  initRegisterForm();
  initTransferForm();

  // Auto-dismiss alerts after 5s
  document.querySelectorAll('.alert-success').forEach(function(el) {
    setTimeout(function() { el.style.opacity = '0'; setTimeout(function() { el.style.display = 'none'; }, 400); }, 5000);
  });
});

// ── Modal style (inline) ────────────────────────────
var modalStyle = document.createElement('style');
modalStyle.textContent = '.modal-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);display:none;align-items:center;justify-content:center;z-index:9000}.modal-box{background:#fff;border-radius:12px;padding:30px;max-width:420px;width:90%;box-shadow:0 8px 24px rgba(0,0,0,0.25)}.modal-box h3{margin-bottom:12px;color:#4A148C}.modal-actions{display:flex;gap:12px;margin-top:20px;justify-content:flex-end}';
document.head.appendChild(modalStyle);
