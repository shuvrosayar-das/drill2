-- ============================================================
-- Union Bank of India - Database Backup
-- Generated: 2024-12-01 02:30:00 IST
-- Server: ubi-prod-db-01 | DB: banking.db (SQLite)
-- Classification: CONFIDENTIAL - RBI DATA PROTECTION APPLICABLE
-- ============================================================

-- Table: users
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, full_name TEXT, email TEXT, phone TEXT, pan TEXT, aadhaar TEXT, role TEXT, is_active INTEGER);

INSERT INTO users VALUES(1,'admin','Admin@UBI2024','System Administrator','admin@unibank.in','9000000001','AAAPA1234A','1234-5678-9101','admin',1);
INSERT INTO users VALUES(4,'ankit.sharma','Ankit@Pass1','Ankit Sharma','ankit.sharma@gmail.com','9811223344','DDGAS1234D','4567-8901-2345','customer',1);
INSERT INTO users VALUES(5,'sunita.verma','Sunita@Pass1','Sunita Verma','sunita.verma@gmail.com','9822334455','EEGSV5678E','5678-9012-3456','customer',1);
INSERT INTO users VALUES(6,'rajesh.kumar','Rajesh@Pass1','Rajesh Kumar','rajesh.kumar@yahoo.com','9833445566','FFGRK9012F','6789-0123-4567','customer',1);
INSERT INTO users VALUES(7,'neha.singh','Neha@Pass1','Neha Singh','neha.singh@yahoo.com','9844556677','GGGNS1234G','7890-1234-5678','customer',1);
INSERT INTO users VALUES(8,'vikram.patel','Vikram@Pass1','Vikram Patel','vikram.patel@gmail.com','9855667788','HHHVP5678H','8901-2345-6789','customer',1);

-- Table: accounts
CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, account_number TEXT, account_type TEXT, balance REAL);

INSERT INTO accounts VALUES(1,4,'UBI400012345678','SAVINGS',125430.75);
INSERT INTO accounts VALUES(2,5,'UBI400023456789','SAVINGS',87650.00);
INSERT INTO accounts VALUES(3,6,'UBI400034567890','SAVINGS',342100.50);
INSERT INTO accounts VALUES(4,7,'UBI400045678901','SAVINGS',55200.00);
INSERT INTO accounts VALUES(5,8,'UBI400056789012','SAVINGS',210800.25);

-- Table: kyc (PII Data - DPDP Act Protected)
CREATE TABLE IF NOT EXISTS kyc (user_id INTEGER, dob TEXT, gender TEXT, address TEXT, pan TEXT, aadhaar TEXT);

INSERT INTO kyc VALUES(4,'1992-05-14','Male','A-204 Shyam Nagar Andheri West Mumbai','DDGAS1234D','4567-8901-2345');
INSERT INTO kyc VALUES(5,'1990-11-22','Female','B-12 Koregaon Park Pune','EEGSV5678E','5678-9012-3456');
INSERT INTO kyc VALUES(6,'1985-07-08','Male','Plot 45 Jubilee Hills Hyderabad','FFGRK9012F','6789-0123-4567');

-- END OF BACKUP