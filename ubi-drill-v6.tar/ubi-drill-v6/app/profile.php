<?php
// ================================================================
//  Union Bank of India – User Profile (Secure)
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth();

$db = getDB();
$msg = $err = '';

// Fetch current user
$stmt = $db->prepare("SELECT u.*, a.account_number, a.account_type, a.balance, a.ifsc
                      FROM users u LEFT JOIN accounts a ON a.user_id = u.id
                      WHERE u.id = ?");
$stmt->execute([$session['user_id']]);
$user = $stmt->fetch();

$kyc_stmt = $db->prepare("SELECT * FROM kyc WHERE user_id = ?");
$kyc_stmt->execute([$session['user_id']]);
$kyc = $kyc_stmt->fetch();

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $current  = $_POST['current_password'] ?? '';
    $new_pass = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $user['password'])) {
        $err = 'Current password is incorrect.';
    } elseif (strlen($new_pass) < 8) {
        $err = 'New password must be at least 8 characters.';
    } elseif ($new_pass !== $confirm) {
        $err = 'New passwords do not match.';
    } else {
        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $session['user_id']]);
        $msg = 'Password updated successfully.';
    }
}

include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#128100; My Profile</h1>
      <div class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &rsaquo; Profile</div>
    </div>
  </div>
</div>

<div class="main-content">
<div class="container">
<div class="dashboard-grid">
  <div>
    <?php if ($msg): ?><div class="alert alert-success">&#9989; <?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-danger">&#9888; <?= htmlspecialchars($err) ?></div><?php endif; ?>

    <!-- Profile Card -->
    <div class="card mb-4">
      <div class="card-header">&#127970; Account Information</div>
      <div class="card-body">
        <div class="kyc-row"><div class="kyc-label">Full Name</div><div class="kyc-value"><?= htmlspecialchars($user['full_name']) ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Username / CIF</div><div class="kyc-value"><?= htmlspecialchars($user['username']) ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Email</div><div class="kyc-value"><?= htmlspecialchars($user['email'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Mobile</div><div class="kyc-value"><?= htmlspecialchars($user['phone'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">PAN</div><div class="kyc-value" style="font-weight:700;letter-spacing:1px;"><?= htmlspecialchars($user['pan'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Role</div><div class="kyc-value"><span class="badge badge-purple"><?= strtoupper(htmlspecialchars($user['role'])) ?></span></div></div>
        <?php if ($user['account_number']): ?>
        <div class="kyc-row"><div class="kyc-label">Account No.</div><div class="kyc-value" style="font-family:monospace;"><?= htmlspecialchars($user['account_number']) ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Balance</div><div class="kyc-value" style="font-weight:700;color:var(--ubi-success);">&#8377; <?= number_format($user['balance'], 2) ?></div></div>
        <?php endif; ?>
        <div class="kyc-row"><div class="kyc-label">Member Since</div><div class="kyc-value"><?= date('d M Y', strtotime($user['created_at'])) ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Last Login</div><div class="kyc-value"><?= $user['last_login'] ? date('d M Y, h:i A', strtotime($user['last_login'])) : 'First login' ?></div></div>
      </div>
    </div>

    <!-- KYC Info -->
    <?php if ($kyc): ?>
    <div class="card mb-4">
      <div class="card-header">&#128209; KYC Details</div>
      <div class="card-body">
        <div class="kyc-row"><div class="kyc-label">Date of Birth</div><div class="kyc-value"><?= htmlspecialchars($kyc['dob'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Gender</div><div class="kyc-value"><?= htmlspecialchars($kyc['gender'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Address</div><div class="kyc-value"><?= htmlspecialchars($kyc['address'] . ', ' . $kyc['city'] . ', ' . $kyc['state'] . ' - ' . $kyc['pincode']) ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Occupation</div><div class="kyc-value"><?= htmlspecialchars($kyc['occupation'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Income Range</div><div class="kyc-value"><?= htmlspecialchars($kyc['income_range'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">Nominee</div><div class="kyc-value"><?= htmlspecialchars($kyc['nominee_name'] ?? '—') ?></div></div>
        <div class="kyc-row"><div class="kyc-label">KYC Status</div><div class="kyc-value"><span class="badge badge-success"><?= htmlspecialchars($kyc['kyc_status'] ?? 'PENDING') ?></span></div></div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Change Password -->
    <div class="card">
      <div class="card-header">&#128274; Change Password</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="action" value="change_password">
          <div class="form-group">
            <label>Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>New Password</label>
              <input type="password" name="new_password" class="form-control" required minlength="8">
            </div>
            <div class="form-group">
              <label>Confirm New Password</label>
              <input type="password" name="confirm_password" class="form-control" required minlength="8">
            </div>
          </div>
          <div class="form-hint mb-2">Password must be at least 8 characters with a mix of letters, numbers, and symbols.</div>
          <button type="submit" class="btn btn-primary">Update Password</button>
        </form>
      </div>
    </div>
  </div>

  <div>
    <div class="card mb-4">
      <div class="card-header">&#128272; Security Settings</div>
      <div class="card-body" style="font-size:13px;">
        <div class="d-flex align-center" style="justify-content:space-between;margin-bottom:12px;">
          <span>Two-Factor Authentication</span><span class="badge badge-warning">Disabled</span>
        </div>
        <div class="d-flex align-center" style="justify-content:space-between;margin-bottom:12px;">
          <span>Transaction Alerts</span><span class="badge badge-success">Enabled</span>
        </div>
        <div class="d-flex align-center" style="justify-content:space-between;margin-bottom:12px;">
          <span>Login Notifications</span><span class="badge badge-success">Enabled</span>
        </div>
        <hr class="divider">
        <p class="text-muted" style="font-size:12px;">To enable 2FA, visit your nearest branch or call 1800-22-2244.</p>
      </div>
    </div>
    <div class="card">
      <div class="card-header">&#9888; Security Tips</div>
      <div class="card-body" style="font-size:12.5px;line-height:1.8;">
        &#8226; Never share your password or OTP.<br>
        &#8226; Use a unique password for banking.<br>
        &#8226; Log out after every session.<br>
        &#8226; Use registered device only.<br>
        &#8226; Report suspicious activity: <strong>1800-111-109</strong>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
