<?php
// ================================================================
//  Union Bank of India – User Profile (Secure)
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session    = check_auth();
$page_title = 'My Profile – Union Bank of India';

$db = getDB();
$msg = $err = '';

$stmt = $db->prepare("SELECT u.*, a.account_number, a.account_type, a.balance, a.ifsc
                      FROM users u LEFT JOIN accounts a ON a.user_id = u.id
                      WHERE u.id = ?");
$stmt->execute([$session['user_id']]);
$user = $stmt->fetch();

$kyc_stmt = $db->prepare("SELECT * FROM kyc WHERE user_id = ?");
$kyc_stmt->execute([$session['user_id']]);
$kyc = $kyc_stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $current  = $_POST['current_password'] ?? '';
    $new_pass = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $user['password'])) {
        $err = 'Current password is incorrect.';
    } elseif (strlen($new_pass) < 8) {
        $err = 'New password must be at least 8 characters.';
    } elseif ($new_pass !== $confirm) {
        $err = 'New passwords do not match.';
    } else {
        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $session['user_id']]);
        $msg = 'Password updated successfully.';
    }
}

include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>👤 My Profile</h2>
    <p class="breadcrumb"><a href="/dashboard.php">Dashboard</a> › Profile</p>
</div>

<div class="content-grid">
    <div>
        <?php if ($msg): ?><div class="alert alert-success">✅ <?php echo htmlspecialchars($msg, ENT_QUOTES); ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-danger">⚠ <?php echo htmlspecialchars($err, ENT_QUOTES); ?></div><?php endif; ?>

        <!-- Profile header -->
        <div class="profile-header" style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;">
            <div class="profile-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
            <div>
                <div class="profile-name"><?php echo htmlspecialchars($user['full_name'], ENT_QUOTES); ?></div>
                <div class="profile-sub"><?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?> &nbsp;|&nbsp;
                    <span class="badge badge-<?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span>
                </div>
                <div class="profile-sub" style="margin-top:6px;"><?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES); ?></div>
            </div>
        </div>

        <!-- Personal details -->
        <div class="card">
            <div class="card-header"><h3>👤 Personal Information</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">Full Name</span><span class="info-value"><?php echo htmlspecialchars($user['full_name'], ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Username</span><span class="info-value mono"><?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Email</span><span class="info-value"><?php echo htmlspecialchars($user['email'] ?? '—', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Phone</span><span class="info-value"><?php echo htmlspecialchars($user['phone'] ?? '—', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">PAN</span><span class="info-value mono"><?php echo htmlspecialchars($user['pan'] ?? '—', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Aadhaar</span><span class="info-value mono"><?php echo htmlspecialchars($user['aadhaar'] ?? '—', ENT_QUOTES); ?></span></div>
            </div>
        </div>

        <!-- Change password -->
        <div class="card">
            <div class="card-header"><h3>🔑 Change Password</h3></div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" class="form-control" minlength="8" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">🔒 Update Password</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Account & KYC info -->
    <div>
        <?php if ($user['account_number']): ?>
        <div class="card">
            <div class="card-header"><h3>🏦 Linked Account</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">Account No.</span><span class="info-value mono"><?php echo htmlspecialchars($user['account_number'], ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Account Type</span><span class="info-value"><?php echo htmlspecialchars($user['account_type'] ?? '—', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Balance</span><span class="info-value text-success">&#8377;<?php echo number_format($user['balance'] ?? 0, 2); ?></span></div>
                <div class="info-row"><span class="info-label">IFSC</span><span class="info-value mono"><?php echo htmlspecialchars($user['ifsc'] ?? '—', ENT_QUOTES); ?></span></div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($kyc): ?>
        <div class="card">
            <div class="card-header"><h3>📋 KYC Status</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">KYC Status</span><span class="info-value"><span class="badge badge-success"><?php echo htmlspecialchars($kyc['kyc_status'] ?? 'VERIFIED', ENT_QUOTES); ?></span></span></div>
                <div class="info-row"><span class="info-label">Address</span><span class="info-value" style="text-align:right;max-width:180px;font-size:12px;"><?php echo htmlspecialchars(($kyc['address'] ?? '') . ', ' . ($kyc['city'] ?? '') . ' ' . ($kyc['pincode'] ?? ''), ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Occupation</span><span class="info-value"><?php echo htmlspecialchars($kyc['occupation'] ?? '—', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Last Updated</span><span class="info-value"><?php echo htmlspecialchars($kyc['updated_at'] ?? '—', ENT_QUOTES); ?></span></div>
            </div>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header"><h3>🔒 Security</h3></div>
            <div class="card-body" style="font-size:13px;line-height:1.9;">
                • Never share your password or OTP with anyone.<br>
                • UBI will never ask for your PIN via call or SMS.<br>
                • Log out after every session.<br>
                • Report suspicious activity: <strong>1800-111-109</strong>
            </div>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
