<?php
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth();
$page_title = 'My Profile - Union Bank of India';
$db = getDB();
$msg = $err = '';

$stmt = $db->prepare('SELECT u.id, u.username, u.full_name, u.email, u.phone, u.pan, u.aadhaar, u.role, u.password, u.last_login, a.account_number, a.account_type, a.balance, a.ifsc FROM users u LEFT JOIN accounts a ON a.user_id=u.id AND a.is_active=1 WHERE u.id=? LIMIT 1');
$stmt->execute([$session['user_id']]);
$user = $stmt->fetch();
$kyc_st = $db->prepare('SELECT * FROM kyc WHERE user_id=?');
$kyc_st->execute([$session['user_id']]);
$kyc = $kyc_st->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action']??'') === 'change_password') {
    $cur = $_POST['current_password']??'';
    $new = $_POST['new_password']??'';
    $cfm = $_POST['confirm_password']??'';
    if (!password_verify($cur, $user['password']))  { $err = 'Current password is incorrect.'; }
    elseif (strlen($new) < 8)                        { $err = 'New password must be at least 8 characters.'; }
    elseif ($new !== $cfm)                           { $err = 'Passwords do not match.'; }
    else {
        $db->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT), $session['user_id']]);
        $msg = 'Password updated successfully.';
    }
}
include '/var/www/html/includes/header.php';
?>
<div class="page-header"><h2>&#128100; My Profile</h2><p class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &#8250; Profile</p></div>
<?php if ($msg!==''): ?><div class="alert alert-success">&#10003; <?php echo htmlspecialchars($msg,ENT_QUOTES); ?></div><?php endif; ?>
<?php if ($err!==''): ?><div class="alert alert-danger">&#9888; <?php echo htmlspecialchars($err,ENT_QUOTES); ?></div><?php endif; ?>
<div class="content-grid">
    <div>
        <div class="profile-header" style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;">
            <div class="profile-avatar"><?php echo strtoupper(substr($user['full_name'],0,1)); ?></div>
            <div>
                <div class="profile-name"><?php echo htmlspecialchars($user['full_name'],ENT_QUOTES); ?></div>
                <div class="profile-sub"><?php echo htmlspecialchars($user['username'],ENT_QUOTES); ?> &nbsp;|&nbsp; <span class="badge badge-<?php echo htmlspecialchars($user['role'],ENT_QUOTES); ?>"><?php echo ucfirst($user['role']); ?></span></div>
                <div class="profile-sub"><?php echo htmlspecialchars($user['email']??'',ENT_QUOTES); ?></div>
            </div>
        </div>
        <div class="card"><div class="card-header"><h3>Personal Information</h3></div><div class="card-body">
            <div class="info-row"><span class="info-label">Full Name</span><span class="info-value"><?php echo htmlspecialchars($user['full_name'],ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Email</span><span class="info-value"><?php echo htmlspecialchars($user['email']??'-',ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Phone</span><span class="info-value"><?php echo htmlspecialchars($user['phone']??'-',ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">PAN</span><span class="info-value mono"><?php echo htmlspecialchars($user['pan']??'-',ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Aadhaar</span><span class="info-value mono"><?php echo htmlspecialchars($user['aadhaar']??'-',ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Last Login</span><span class="info-value"><?php echo $user['last_login']?htmlspecialchars($user['last_login'],ENT_QUOTES):'First login'; ?></span></div>
        </div></div>
        <div class="card"><div class="card-header"><h3>&#128273; Change Password</h3></div><div class="card-body">
            <form method="POST" action="/profile.php"><input type="hidden" name="action" value="change_password">
                <div class="form-group"><label>Current Password</label><input type="password" name="current_password" class="form-control" required autocomplete="off"></div>
                <div class="form-group"><label>New Password</label><input type="password" name="new_password" class="form-control" minlength="8" required autocomplete="new-password"></div>
                <div class="form-group"><label>Confirm New Password</label><input type="password" name="confirm_password" class="form-control" required autocomplete="new-password"></div>
                <button type="submit" class="btn btn-primary">Update Password</button>
            </form>
        </div></div>
    </div>
    <div>
        <?php if ($user['account_number']): ?>
        <div class="card"><div class="card-header"><h3>&#127970; Linked Account</h3></div><div class="card-body">
            <div class="info-row"><span class="info-label">Account No.</span><span class="info-value mono"><?php echo htmlspecialchars($user['account_number'],ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Type</span><span class="info-value"><?php echo htmlspecialchars($user['account_type']??'-',ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Balance</span><span class="info-value text-success">&#8377;<?php echo number_format($user['balance']??0,2); ?></span></div>
            <div class="info-row"><span class="info-label">IFSC</span><span class="info-value mono"><?php echo htmlspecialchars($user['ifsc']??'-',ENT_QUOTES); ?></span></div>
        </div></div>
        <?php endif; ?>
        <?php if ($kyc): ?><div class="card"><div class="card-header"><h3>KYC Status</h3></div><div class="card-body">
            <div class="info-row"><span class="info-label">Status</span><span class="info-value"><span class="badge badge-success"><?php echo htmlspecialchars($kyc['kyc_status']??'VERIFIED',ENT_QUOTES); ?></span></span></div>
            <div class="info-row"><span class="info-label">City/State</span><span class="info-value"><?php echo htmlspecialchars(($kyc['city']??'-').', '.($kyc['state']??'-'),ENT_QUOTES); ?></span></div>
            <div class="info-row"><span class="info-label">Occupation</span><span class="info-value"><?php echo htmlspecialchars($kyc['occupation']??'-',ENT_QUOTES); ?></span></div>
        </div></div><?php endif; ?>
    </div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
