<?php
require_once '/var/www/html/includes/auth.php';
session_init();
header('Location: ' . (is_logged_in() ? '/dashboard.php' : '/login.php'));
exit;
