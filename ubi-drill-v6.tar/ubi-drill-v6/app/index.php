<?php
$page_title = 'Union Bank of India – Internet Banking';
require_once '/var/www/html/includes/header.php';
if (is_logged_in()) { header('Location: /dashboard.php'); exit; }
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <div class="hero-text">
            <div class="hero-badge">&#127881; Now available 24x7</div>
            <h1>Banking at Your Fingertips</h1>
            <p class="hero-sub">Experience seamless, secure internet banking with Union Bank of India.
               Manage accounts, transfer funds, and access all services anytime, anywhere.</p>
            <div class="hero-actions">
                <a href="/login.php" class="btn btn-gold btn-lg">Login to Internet Banking</a>
                <a href="/login.php?register=1" class="btn btn-outline btn-lg">New Registration</a>
            </div>
            <div class="hero-stats">
                <div class="stat"><strong>10 Crore+</strong><span>Customers</span></div>
                <div class="stat"><strong>9,000+</strong><span>Branches</span></div>
                <div class="stat"><strong>12,000+</strong><span>ATMs</span></div>
                <div class="stat"><strong>99.9%</strong><span>Uptime</span></div>
            </div>
        </div>
        <div class="hero-visual">
            <div class="banking-card-preview">
                <div class="bcard">
                    <div class="bcard-header">
                        <span>Union Bank of India</span>
                        <svg width="32" height="32" viewBox="0 0 52 52"><circle cx="26" cy="26" r="26" fill="#FFB300"/><text x="26" y="35" text-anchor="middle" font-family="Arial Black" font-size="26" font-weight="900" fill="#4A148C">U</text></svg>
                    </div>
                    <div class="bcard-chip"></div>
                    <div class="bcard-number">**** **** **** 4578</div>
                    <div class="bcard-info">
                        <span>ANKIT SHARMA</span>
                        <span>VALID THRU 12/27</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features -->
<section class="features-section">
    <div class="container">
        <h2 class="section-title">Everything You Need, Online</h2>
        <p class="section-sub">Complete digital banking solutions designed for your convenience</p>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">&#128176;</div>
                <h3>NEFT / RTGS Transfers</h3>
                <p>Transfer funds instantly 24x7 to any bank account across India with real-time confirmation.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">&#128203;</div>
                <h3>Account Management</h3>
                <p>View balance, download statements, manage beneficiaries, and track spending in real time.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">&#128274;</div>
                <h3>Secure Banking</h3>
                <p>256-bit SSL encryption, two-factor authentication, and real-time fraud monitoring.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">&#128222;</div>
                <h3>24x7 Support</h3>
                <p>Dedicated customer support via phone, chat, and branch for all your banking needs.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">&#128179;</div>
                <h3>Fixed Deposits &amp; RD</h3>
                <p>Open and manage Fixed Deposits and Recurring Deposits online with competitive rates.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">&#128200;</div>
                <h3>Investment Services</h3>
                <p>Access mutual funds, insurance, and other investment products through internet banking.</p>
            </div>
        </div>
    </div>
</section>

<!-- Announcements -->
<section class="announcements">
    <div class="container">
        <div class="announcement-grid">
            <div class="announcement-main">
                <h3>&#128276; Important Announcements</h3>
                <ul class="announcement-list">
                    <li><span class="anc-date">Dec 01, 2024</span> <a href="#">RBI mandates enhanced cybersecurity measures for digital banking platforms – compliance effective immediately.</a></li>
                    <li><span class="anc-date">Nov 28, 2024</span> <a href="#">NEFT/RTGS transaction charges revised to NIL for all retail customers effective December 2024.</a></li>
                    <li><span class="anc-date">Nov 20, 2024</span> <a href="#">Union Bank launches UPI AutoPay for seamless recurring payments. Enroll now through Internet Banking.</a></li>
                    <li><span class="anc-date">Nov 15, 2024</span> <a href="#">KYC updation mandatory for all accounts. Update your KYC online to continue uninterrupted banking.</a></li>
                </ul>
            </div>
            <div class="security-tips">
                <h3>&#128737; Security Tips</h3>
                <ul>
                    <li>&#9989; Always check for HTTPS in the URL bar</li>
                    <li>&#9989; Never share OTP or PIN with anyone</li>
                    <li>&#9989; Register for SMS alerts for all transactions</li>
                    <li>&#9989; Log out after every internet banking session</li>
                    <li>&#10060; Do not use public Wi-Fi for banking</li>
                    <li>&#10060; Do not click links in unsolicited emails/SMS</li>
                </ul>
                <a href="#" class="btn btn-outline btn-sm" style="margin-top:1rem">Learn More</a>
            </div>
        </div>
    </div>
</section>

<!-- Regulatory -->
<section class="regulatory-bar">
    <div class="container">
        <div class="reg-items">
            <div class="reg-item">
                <strong>RBI Regulated</strong>
                <span>Reserve Bank of India Licensed Scheduled Commercial Bank</span>
            </div>
            <div class="reg-item">
                <strong>DICGC Insured</strong>
                <span>Deposits insured up to &#8377;5,00,000 per depositor</span>
            </div>
            <div class="reg-item">
                <strong>ISO 27001:2022</strong>
                <span>Information Security Management Certified</span>
            </div>
            <div class="reg-item">
                <strong>PCI DSS Compliant</strong>
                <span>Payment Card Industry Data Security Standard</span>
            </div>
        </div>
    </div>
</section>

<?php require_once '/var/www/html/includes/footer.php'; ?>
