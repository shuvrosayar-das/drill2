<?php
/* index.php – redirect straight to login or dashboard */
require_once '/var/www/html/includes/auth.php';
session_init();
if (is_logged_in()) {
    header('Location: /dashboard.php');
} else {
    header('Location: /login.php');
}
exit;
