<?php
/**
 * transfer.php - Fund Transfer (NEFT/RTGS/IMPS)
 * VULNERABLE: No CSRF token (Scenario #4)
 */
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session    = check_auth(['customer','banker','admin']);
$page_title = 'Fund Transfer - Union Bank of India';
$db         = getDB();
$msg = $err = '';

// Get sender account
$acc_st = $db->prepare('SELECT id, account_number, account_type, balance FROM accounts WHERE user_id = ? AND is_active = 1 LIMIT 1');
$acc_st->execute([$session['user_id']]);
$my_account = $acc_st->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // VULNERABLE: No CSRF token check (intentional for drill)
    $to_acc   = trim($_POST['to_account'] ?? '');
    $amount   = (float)($_POST['amount'] ?? 0);
    $txn_type = trim($_POST['txn_type'] ?? 'NEFT');
    $remarks  = trim($_POST['remarks'] ?? '');
    $ben_name = trim($_POST['beneficiary_name'] ?? '');

    $errors = [];
    if ($to_acc === '')  $errors[] = 'Beneficiary account number is required.';
    if ($amount <= 0)    $errors[] = 'Enter a valid transfer amount greater than zero.';
    if ($txn_type === 'NEFT' && $amount > 200000) $errors[] = 'NEFT limit is Rs 2,00,000 per transaction.';
    if ($txn_type === 'RTGS' && $amount < 200000) $errors[] = 'RTGS minimum amount is Rs 2,00,000.';
    if ($my_account && $amount > $my_account['balance']) $errors[] = 'Insufficient balance.';
    if ($my_account && $to_acc === $my_account['account_number']) $errors[] = 'Cannot transfer to the same account.';

    if (empty($errors) && $my_account) {
        // Debit sender
        $db->prepare('UPDATE accounts SET balance = balance - ? WHERE id = ?')->execute([$amount, $my_account['id']]);

        // Credit beneficiary if internal account
        $ben_st = $db->prepare('SELECT id FROM accounts WHERE account_number = ? AND is_active = 1');
        $ben_st->execute([$to_acc]);
        $ben = $ben_st->fetch(PDO::FETCH_ASSOC);
        if ($ben) {
            $db->prepare('UPDATE accounts SET balance = balance + ? WHERE id = ?')->execute([$amount, $ben['id']]);
        }

        // Log transaction
        $txn_id = 'UBI' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
        $desc   = $txn_type . ' to ' . $to_acc . ($ben_name ? ' (' . $ben_name . ')' : '') . ($remarks ? ' - ' . $remarks : '');
        $db->prepare('INSERT INTO transactions (account_id, txn_id, txn_type, amount, direction, description, beneficiary, beneficiary_acc) VALUES (?,?,?,?,?,?,?,?)')
           ->execute([$my_account['id'], $txn_id, $txn_type, $amount, 'DEBIT', $desc, $ben_name, $to_acc]);

        // Log in transfers table
        $db->prepare('INSERT INTO transfers (from_account, to_account, beneficiary, amount, txn_type, remarks, initiated_by) VALUES (?,?,?,?,?,?,?)')
           ->execute([$my_account['account_number'], $to_acc, $ben_name, $amount, $txn_type, $remarks, $session['user_id']]);

        // Refresh balance
        $acc_st->execute([$session['user_id']]);
        $my_account = $acc_st->fetch(PDO::FETCH_ASSOC);
        $msg = 'Transfer Successful! TXN ID: <strong>' . htmlspecialchars($txn_id, ENT_QUOTES) . '</strong> &nbsp;|&nbsp; &#8377;' . number_format($amount, 2) . ' sent via ' . htmlspecialchars($txn_type, ENT_QUOTES);
    } elseif (!$my_account && empty($errors)) {
        $err = 'No linked account found. Cannot initiate transfer.';
    } else {
        $err = implode(' ', $errors);
    }
}
include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>&#128184; Fund Transfer</h2>
    <p class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &#8250; Fund Transfer</p>
</div>

<div class="content-grid">
    <div>
        <?php if ($msg !== ''): ?>
        <div class="alert alert-success">&#10003; <?php echo $msg; ?></div>
        <?php endif; ?>
        <?php if ($err !== ''): ?>
        <div class="alert alert-danger">&#9888; <?php echo htmlspecialchars($err, ENT_QUOTES); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header"><h3>Initiate Transfer — NEFT / RTGS / IMPS</h3></div>
            <div class="card-body">
                <?php if ($my_account): ?>
                <div class="transfer-meta">
                    <div class="row"><span class="info-label">From Account</span><span class="mono info-value"><?php echo htmlspecialchars($my_account['account_number'], ENT_QUOTES); ?></span></div>
                    <div class="row"><span class="info-label">Account Holder</span><span class="info-value"><?php echo htmlspecialchars($session['full_name'], ENT_QUOTES); ?></span></div>
                    <div class="row"><span class="info-label">Available Balance</span><span class="info-value text-success">&#8377;<?php echo number_format($my_account['balance'], 2); ?></span></div>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">No linked account found. Fund transfer is unavailable.</div>
                <?php endif; ?>

                <!-- VULNERABLE: No CSRF token in this form -->
                <form method="POST" action="/transfer.php">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Transfer Mode</label>
                            <select name="txn_type" class="form-control" id="txn-type">
                                <option value="NEFT">NEFT (Up to Rs 2,00,000)</option>
                                <option value="RTGS">RTGS (Rs 2,00,000 and above)</option>
                                <option value="IMPS">IMPS (Instant, 24x7)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Amount (&#8377;)</label>
                            <input type="number" name="amount" id="transfer-amount" class="form-control" min="1" step="0.01" placeholder="0.00" required <?php echo !$my_account ? 'disabled' : ''; ?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Beneficiary Account Number</label>
                        <input type="text" name="to_account" class="form-control mono" placeholder="Enter account number" required <?php echo !$my_account ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Beneficiary Name</label>
                            <input type="text" name="beneficiary_name" class="form-control" placeholder="As per bank records" <?php echo !$my_account ? 'disabled' : ''; ?>>
                        </div>
                        <div class="form-group">
                            <label>IFSC Code</label>
                            <input type="text" name="ifsc" class="form-control mono" placeholder="e.g. SBIN0001234" maxlength="11" <?php echo !$my_account ? 'disabled' : ''; ?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Remarks / Purpose</label>
                        <input type="text" name="remarks" class="form-control" placeholder="Optional" <?php echo !$my_account ? 'disabled' : ''; ?>>
                    </div>
                    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0;">
                    <div style="display:flex;gap:10px;">
                        <button type="submit" class="btn btn-primary btn-lg" <?php echo !$my_account ? 'disabled' : ''; ?>>&#128184; Confirm Transfer</button>
                        <a href="/dashboard.php" class="btn btn-outline">Cancel</a>
                    </div>
                    <p style="font-size:11.5px;color:var(--text-sec);margin-top:10px;">&#128274; Transactions processed subject to RBI NEFT/RTGS operating hours. IMPS is 24x7.</p>
                </form>
            </div>
        </div>
    </div>

    <div>
        <div class="card">
            <div class="card-header"><h3>&#8505; Transfer Limits</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">NEFT</span><span class="info-value">Up to &#8377;2,00,000<br><small class="text-muted">Batch: 8AM-7PM</small></span></div>
                <div class="info-row"><span class="info-label">RTGS</span><span class="info-value">&#8377;2,00,000+<br><small class="text-muted">8AM-4:30PM</small></span></div>
                <div class="info-row"><span class="info-label">IMPS</span><span class="info-value">Up to &#8377;5,00,000<br><small class="text-muted">24x7 Instant</small></span></div>
                <div class="info-row"><span class="info-label">Charges</span><span class="info-value">NEFT: &#8377;2-25<br>RTGS: &#8377;25-50</span></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3>&#9888; Important</h3></div>
            <div class="card-body" style="font-size:12.5px;line-height:1.8;">
                &#8226; Verify beneficiary details before confirming.<br>
                &#8226; UBI will never ask for OTP or password.<br>
                &#8226; Report fraud: <strong>1800-22-2244</strong><br>
                &#8226; Transactions are final once processed.
            </div>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
