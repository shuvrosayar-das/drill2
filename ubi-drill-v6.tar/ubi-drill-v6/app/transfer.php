<?php
// ================================================================
//  Union Bank of India – Fund Transfer (NEFT / RTGS / IMPS)
//  VULNERABLE: No CSRF token — enables XSS-driven fraudulent transfer
//  Attack Scenario #4: BeEF-hooked admin/banker executes JS that
//  submits this form, initiating unauthorised NEFT/RTGS payment
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(['customer', 'banker', 'admin']);

$db = getDB();
$msg = $err = '';

// Get sender account
$acc_stmt = $db->prepare("SELECT * FROM accounts WHERE user_id = ? LIMIT 1");
$acc_stmt->execute([$session['user_id']]);
$my_account = $acc_stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // VULNERABLE: No CSRF token check at all
    $to_acc    = trim($_POST['to_account'] ?? '');
    $amount    = (float)($_POST['amount'] ?? 0);
    $txn_type  = trim($_POST['txn_type'] ?? 'NEFT');
    $remarks   = trim($_POST['remarks'] ?? '');
    $ben_name  = trim($_POST['beneficiary_name'] ?? '');

    $errors = [];
    if (empty($to_acc))      $errors[] = 'Beneficiary account number is required.';
    if ($amount <= 0)        $errors[] = 'Enter a valid transfer amount.';
    if ($amount > 200000 && $txn_type === 'NEFT') $errors[] = 'NEFT limit is ₹2,00,000 per transaction.';
    if ($amount < 200000 && $txn_type === 'RTGS') $errors[] = 'RTGS minimum amount is ₹2,00,000.';
    if ($my_account && $amount > $my_account['balance']) $errors[] = 'Insufficient balance.';
    if ($to_acc === ($my_account['account_number'] ?? '')) $errors[] = 'Cannot transfer to same account.';

    if (empty($errors)) {
        // Debit sender
        if ($my_account) {
            $db->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?")->execute([$amount, $my_account['id']]);
        }
        // Credit beneficiary if internal account exists
        $ben_stmt = $db->prepare("SELECT id FROM accounts WHERE account_number = ?");
        $ben_stmt->execute([$to_acc]);
        $ben_acc = $ben_stmt->fetch();
        if ($ben_acc) {
            $db->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?")->execute([$amount, $ben_acc['id']]);
        }
        // Log transaction
        $txn_id = 'UBI' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
        $desc = $txn_type . ' to ' . $to_acc . ($ben_name ? ' (' . $ben_name . ')' : '') . ($remarks ? ' - ' . $remarks : '');
        if ($my_account) {
            $db->prepare("INSERT INTO transactions (account_id, txn_id, txn_type, amount, direction, description, beneficiary, beneficiary_acc)
                          VALUES (?,?,?,?,?,?,?,?)")
               ->execute([$my_account['id'], $txn_id, $txn_type, $amount, 'DEBIT', $desc, $ben_name, $to_acc]);
        }
        // Log in transfers table
        $db->prepare("INSERT INTO transfers (from_account, to_account, beneficiary, amount, txn_type, remarks, initiated_by)
                      VALUES (?,?,?,?,?,?,?)")
           ->execute([$my_account['account_number'] ?? 'UNKNOWN', $to_acc, $ben_name, $amount, $txn_type, $remarks, $session['user_id']]);

        // Refresh account balance
        if ($my_account) {
            $acc_stmt->execute([$session['user_id']]);
            $my_account = $acc_stmt->fetch();
        }
        $msg = "&#9989; Transfer Successful! Transaction ID: <strong>{$txn_id}</strong><br>&#8377;" . number_format($amount, 2) . " sent via {$txn_type} to {$to_acc}";
    } else {
        $err = implode(' ', $errors);
    }
}
include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#8594; Fund Transfer</h1>
      <div class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &rsaquo; Fund Transfer</div>
    </div>
  </div>
</div>

<div class="main-content">
<div class="container">
<div class="dashboard-grid">
  <div>
    <?php if ($msg): ?>
    <div class="alert alert-success"><?= $msg ?></div>
    <?php endif; ?>
    <?php if ($err): ?>
    <div class="alert alert-danger">&#9888; <?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">&#128184; Initiate Fund Transfer (NEFT / RTGS / IMPS)</div>
      <div class="card-body">
        <?php if ($my_account): ?>
        <div class="transfer-summary mb-4">
          <div class="row"><span style="font-weight:600;color:var(--ubi-purple);">From Account</span><span style="font-family:monospace;"><?= htmlspecialchars($my_account['account_number']) ?></span></div>
          <div class="row"><span>Account Holder</span><span><?= htmlspecialchars($session['full_name']) ?></span></div>
          <div class="row"><span>Available Balance</span><span style="font-weight:700;color:var(--ubi-success);">&#8377; <?= number_format($my_account['balance'], 2) ?></span></div>
        </div>
        <?php endif; ?>

        <!-- VULNERABLE: No CSRF token in this form -->
        <form method="POST" id="transfer-form">
          <!-- Note: No hidden CSRF token field -->
          <div class="form-row">
            <div class="form-group">
              <label>Transfer Mode</label>
              <select name="txn_type" class="form-control" id="txn-type">
                <option value="NEFT">NEFT (Up to ₹2,00,000)</option>
                <option value="RTGS">RTGS (₹2,00,000 and above)</option>
                <option value="IMPS">IMPS (Instant)</option>
              </select>
            </div>
            <div class="form-group">
              <label>Amount (₹)</label>
              <input type="number" name="amount" id="transfer-amount" class="form-control" min="1" step="0.01" placeholder="0.00" required>
              <div class="form-hint" id="amount-words"></div>
            </div>
          </div>

          <div class="form-group">
            <label>Beneficiary Account Number</label>
            <input type="text" name="to_account" class="form-control" placeholder="Enter 16-digit account number" required pattern="[A-Z0-9]{10,20}" style="font-family:monospace;letter-spacing:1px;">
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Beneficiary Name</label>
              <input type="text" name="beneficiary_name" class="form-control" placeholder="As per bank records">
            </div>
            <div class="form-group">
              <label>IFSC Code</label>
              <input type="text" name="ifsc" class="form-control" placeholder="e.g. SBIN0001234" maxlength="11" style="font-family:monospace;">
            </div>
          </div>

          <div class="form-group">
            <label>Remarks / Purpose</label>
            <input type="text" name="remarks" class="form-control" placeholder="Optional - transfer purpose">
          </div>

          <hr class="divider">
          <div style="display:flex;gap:12px;align-items:center;">
            <button type="submit" class="btn btn-primary btn-lg">&#128184; Confirm Transfer</button>
            <a href="/dashboard.php" class="btn btn-outline">Cancel</a>
          </div>
          <p style="font-size:11.5px;color:var(--ubi-grey);margin-top:10px;">&#128274; Transactions are processed subject to RBI NEFT/RTGS operating hours. IMPS is 24×7.</p>
        </form>
      </div>
    </div>
  </div>

  <div>
    <div class="card mb-4">
      <div class="card-header">&#8505; Transfer Limits</div>
      <div class="card-body">
        <div class="kyc-row"><div class="kyc-label">NEFT</div><div class="kyc-value">Up to ₹2,00,000<br><small class="text-muted">Batch: 8AM–7PM</small></div></div>
        <div class="kyc-row"><div class="kyc-label">RTGS</div><div class="kyc-value">₹2,00,000+<br><small class="text-muted">8AM–4:30PM</small></div></div>
        <div class="kyc-row"><div class="kyc-label">IMPS</div><div class="kyc-value">Up to ₹5,00,000<br><small class="text-muted">24×7 Instant</small></div></div>
        <div class="kyc-row"><div class="kyc-label">Charges</div><div class="kyc-value">NEFT: ₹2–25<br>RTGS: ₹25–50</div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">&#9888; Important Notice</div>
      <div class="card-body">
        <p style="font-size:12.5px;line-height:1.7;color:var(--ubi-text);">
          &#8226; Verify beneficiary details before confirming.<br>
          &#8226; UBI will never ask for OTP or password.<br>
          &#8226; Report fraud: <strong>1800-22-2244</strong><br>
          &#8226; Transactions are final once processed.
        </p>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
