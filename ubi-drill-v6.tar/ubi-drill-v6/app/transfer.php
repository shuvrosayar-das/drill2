<?php
// ================================================================
//  Union Bank of India – Fund Transfer (NEFT / RTGS / IMPS)
//  VULNERABLE: No CSRF token — enables XSS-driven fraudulent transfer
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(['customer', 'banker', 'admin']);
$page_title = 'Fund Transfer – Union Bank of India';

$db = getDB();
$msg = $err = '';

$acc_stmt = $db->prepare("SELECT * FROM accounts WHERE user_id = ? LIMIT 1");
$acc_stmt->execute([$session['user_id']]);
$my_account = $acc_stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // VULNERABLE: No CSRF token check at all
    $to_acc   = trim($_POST['to_account'] ?? '');
    $amount   = (float)($_POST['amount'] ?? 0);
    $txn_type = trim($_POST['txn_type'] ?? 'NEFT');
    $remarks  = trim($_POST['remarks'] ?? '');
    $ben_name = trim($_POST['beneficiary_name'] ?? '');

    $errors = [];
    if (empty($to_acc))    $errors[] = 'Beneficiary account number is required.';
    if ($amount <= 0)      $errors[] = 'Enter a valid transfer amount.';
    if ($amount > 200000 && $txn_type === 'NEFT') $errors[] = 'NEFT limit is ₹2,00,000 per transaction.';
    if ($amount < 200000 && $txn_type === 'RTGS') $errors[] = 'RTGS minimum amount is ₹2,00,000.';
    if ($my_account && $amount > $my_account['balance']) $errors[] = 'Insufficient balance.';

    if (empty($errors)) {
        if ($my_account) {
            $db->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?")->execute([$amount, $my_account['id']]);
        }
        $ben_stmt = $db->prepare("SELECT id FROM accounts WHERE account_number = ?");
        $ben_stmt->execute([$to_acc]);
        $ben_acc = $ben_stmt->fetch();
        if ($ben_acc) $db->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?")->execute([$amount, $ben_acc['id']]);

        $txn_id = 'UBI' . date('Ymd') . strtoupper(bin2hex(random_bytes(4)));
        $desc = $txn_type . ' to ' . $to_acc . ($ben_name ? ' (' . $ben_name . ')' : '') . ($remarks ? ' – ' . $remarks : '');
        if ($my_account) {
            $db->prepare("INSERT INTO transactions (account_id, txn_id, txn_type, amount, direction, description, beneficiary, beneficiary_acc) VALUES (?,?,?,?,?,?,?,?)")
               ->execute([$my_account['id'], $txn_id, $txn_type, $amount, 'DEBIT', $desc, $ben_name, $to_acc]);
        }
        $db->prepare("INSERT INTO transfers (from_account, to_account, beneficiary, amount, txn_type, remarks, initiated_by) VALUES (?,?,?,?,?,?,?)")
           ->execute([$my_account['account_number'] ?? 'UNKNOWN', $to_acc, $ben_name, $amount, $txn_type, $remarks, $session['user_id']]);

        $acc_stmt->execute([$session['user_id']]);
        $my_account = $acc_stmt->fetch();
        $msg = '✅ Transfer Successful! TXN ID: <strong>' . htmlspecialchars($txn_id) . '</strong> &nbsp;|&nbsp; ₹' . number_format($amount, 2) . ' sent via ' . $txn_type;
    } else {
        $err = implode(' ', $errors);
    }
}
include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>💸 Fund Transfer</h2>
    <p class="breadcrumb"><a href="/dashboard.php">Dashboard</a> › Fund Transfer</p>
</div>

<div class="content-grid">
    <!-- Transfer form -->
    <div>
        <?php if ($msg): ?><div class="alert alert-success"><?php echo $msg; ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-danger">⚠ <?php echo htmlspecialchars($err); ?></div><?php endif; ?>

        <div class="card">
            <div class="card-header"><h3>Initiate Transfer — NEFT / RTGS / IMPS</h3></div>
            <div class="card-body">
                <?php if ($my_account): ?>
                <div class="transfer-meta">
                    <div class="row"><span class="info-label">From Account</span><span class="mono info-value"><?php echo htmlspecialchars($my_account['account_number'] ?? $my_account['acc_no'] ?? '', ENT_QUOTES); ?></span></div>
                    <div class="row"><span class="info-label">Account Holder</span><span class="info-value"><?php echo htmlspecialchars($session['full_name'], ENT_QUOTES); ?></span></div>
                    <div class="row"><span class="info-label">Available Balance</span><span class="info-value text-success">&#8377;<?php echo number_format($my_account['balance'], 2); ?></span></div>
                </div>
                <?php endif; ?>

                <!-- VULNERABLE: No CSRF token in this form -->
                <form method="POST" id="transfer-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Transfer Mode</label>
                            <select name="txn_type" class="form-control" id="txn-type">
                                <option value="NEFT">NEFT (Up to ₹2,00,000)</option>
                                <option value="RTGS">RTGS (₹2,00,000 and above)</option>
                                <option value="IMPS">IMPS (Instant, 24×7)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Amount (₹)</label>
                            <input type="number" name="amount" id="transfer-amount" class="form-control" min="1" step="0.01" placeholder="0.00" required>
                            <div class="form-hint" id="amount-words"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Beneficiary Account Number</label>
                        <input type="text" name="to_account" class="form-control mono" placeholder="Enter account number" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Beneficiary Name</label>
                            <input type="text" name="beneficiary_name" class="form-control" placeholder="As per bank records">
                        </div>
                        <div class="form-group">
                            <label>IFSC Code</label>
                            <input type="text" name="ifsc" class="form-control mono" placeholder="e.g. SBIN0001234" maxlength="11">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Remarks / Purpose</label>
                        <input type="text" name="remarks" class="form-control" placeholder="Optional — transfer purpose">
                    </div>
                    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0;">
                    <div style="display:flex;gap:10px;align-items:center;">
                        <button type="submit" class="btn btn-primary btn-lg">💸 Confirm Transfer</button>
                        <a href="/dashboard.php" class="btn btn-outline">Cancel</a>
                    </div>
                    <p style="font-size:11.5px;color:var(--text-sec);margin-top:10px;">🔒 Transactions are processed subject to RBI NEFT/RTGS operating hours.</p>
                </form>
            </div>
        </div>
    </div>

    <!-- Info sidebar -->
    <div>
        <div class="card">
            <div class="card-header"><h3>ℹ Transfer Limits</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">NEFT</span><span class="info-value">Up to ₹2,00,000<br><small class="text-muted">Batch: 8AM–7PM</small></span></div>
                <div class="info-row"><span class="info-label">RTGS</span><span class="info-value">₹2,00,000+<br><small class="text-muted">8AM–4:30PM</small></span></div>
                <div class="info-row"><span class="info-label">IMPS</span><span class="info-value">Up to ₹5,00,000<br><small class="text-muted">24×7 Instant</small></span></div>
                <div class="info-row"><span class="info-label">Charges</span><span class="info-value">NEFT: ₹2–25<br>RTGS: ₹25–50</span></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3>⚠ Important</h3></div>
            <div class="card-body" style="font-size:12.5px;line-height:1.8;">
                • Verify beneficiary details before confirming.<br>
                • UBI will never ask for OTP or password.<br>
                • Report fraud: <strong>1800-22-2244</strong><br>
                • Transactions are final once processed.
            </div>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
