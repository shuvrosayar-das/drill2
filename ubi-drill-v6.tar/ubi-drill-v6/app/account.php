<?php
// ================================================================
//  Union Bank of India – Account Details
//  VULNERABLE: IDOR – account id taken from URL with no ownership check
//  Attack Scenario #3: Any authenticated customer can view any account
// ================================================================
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth(); // any logged-in user

// ── IDOR VULNERABILITY: $id taken directly from URL, no user_id check ──
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: /dashboard.php');
    exit;
}
$db = getDB();

// VULNERABLE: Query uses account id with NO check that user_id = session user_id
// Any authenticated user can supply any account id in the URL
$stmt = $db->prepare("SELECT a.*, u.full_name, u.email, u.phone, u.pan, u.aadhaar, u.username
                      FROM accounts a JOIN users u ON a.user_id = u.id
                      WHERE a.id = ?");
$stmt->execute([$id]);
$account = $stmt->fetch();

if (!$account) {
    http_response_code(404);
    include '/var/www/html/includes/header.php';
    echo '<div class="container mt-4"><div class="alert alert-danger">Account not found.</div></div>';
    include '/var/www/html/includes/footer.php';
    exit;
}

// Get KYC details (no ownership check – IDOR exposes full PII)
$kyc_stmt = $db->prepare("SELECT * FROM kyc WHERE user_id = ?");
$kyc_stmt->execute([$account['user_id']]);
$kyc = $kyc_stmt->fetch();

// Get last 20 transactions
$txn_stmt = $db->prepare("SELECT * FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 20");
$txn_stmt->execute([$id]);
$txns = $txn_stmt->fetchAll();

include '/var/www/html/includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div>
      <h1>&#127970; Account Details</h1>
      <div class="breadcrumb"><a href="/dashboard.php">Dashboard</a> &rsaquo; Account Details</div>
    </div>
    <a href="/dashboard.php" class="btn btn-outline" style="border-color:rgba(255,255,255,0.4);color:#fff;">&#8592; Back</a>
  </div>
</div>

<div class="main-content">
<div class="container">

  <!-- Account Card -->
  <div class="account-card mb-4">
    <div class="ubi-chip"></div>
    <div class="label">Account Holder</div>
    <div style="font-size:20px;font-weight:700;margin-bottom:4px;"><?= htmlspecialchars($account['full_name']) ?></div>
    <div class="acc-number"><?= htmlspecialchars($account['account_number']) ?></div>
    <div class="d-flex gap-2" style="flex-wrap:wrap;">
      <div>
        <div class="balance-label">Available Balance</div>
        <div class="balance"><span class="currency">&#8377; </span><?= number_format($account['balance'], 2) ?></div>
      </div>
      <div style="margin-left:auto;text-align:right;opacity:0.85;">
        <div style="font-size:11px;margin-bottom:3px;">Account Type</div>
        <div style="font-size:15px;font-weight:600;"><?= htmlspecialchars($account['account_type']) ?></div>
        <div style="font-size:11px;margin-top:6px;">IFSC: <?= htmlspecialchars($account['ifsc']) ?></div>
      </div>
    </div>
    <div class="ifsc">Branch: <?= htmlspecialchars($account['branch_code']) ?> &nbsp;|&nbsp; Status: <?= $account['is_active'] ? 'ACTIVE' : 'INACTIVE' ?></div>
  </div>

  <div class="dashboard-grid">
    <div>
      <!-- KYC / Customer Details -->
      <div class="card mb-4">
        <div class="card-header">&#128100; Customer KYC Information</div>
        <div class="card-body">
          <div class="kyc-row"><div class="kyc-label">CIF / Username</div><div class="kyc-value"><?= htmlspecialchars($account['username']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Full Name</div><div class="kyc-value"><?= htmlspecialchars($account['full_name']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Email</div><div class="kyc-value"><?= htmlspecialchars($account['email']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Mobile</div><div class="kyc-value"><?= htmlspecialchars($account['phone']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">PAN Number</div><div class="kyc-value" style="font-weight:700;letter-spacing:1px;"><?= htmlspecialchars($account['pan']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Aadhaar</div><div class="kyc-value" style="font-family:monospace;"><?= htmlspecialchars($account['aadhaar']) ?></div></div>
          <?php if ($kyc): ?>
          <div class="kyc-row"><div class="kyc-label">Date of Birth</div><div class="kyc-value"><?= htmlspecialchars($kyc['dob']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Gender</div><div class="kyc-value"><?= htmlspecialchars($kyc['gender']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Address</div><div class="kyc-value"><?= htmlspecialchars($kyc['address'] . ', ' . $kyc['city'] . ', ' . $kyc['state'] . ' - ' . $kyc['pincode']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Occupation</div><div class="kyc-value"><?= htmlspecialchars($kyc['occupation']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Income Range</div><div class="kyc-value"><?= htmlspecialchars($kyc['income_range']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Nominee</div><div class="kyc-value"><?= htmlspecialchars($kyc['nominee_name']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">KYC Status</div><div class="kyc-value"><span class="badge badge-success"><?= htmlspecialchars($kyc['kyc_status']) ?></span></div></div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Transaction History -->
      <div class="card">
        <div class="card-header">&#128196; Transaction History (Last 20)</div>
        <div class="card-body" style="padding:0;">
          <div class="table-wrap">
            <?php if (empty($txns)): ?>
            <div class="empty-state"><div class="icon">&#128203;</div><p>No transactions found.</p></div>
            <?php else: ?>
            <table class="data-table">
              <thead><tr><th>Date</th><th>TXN ID</th><th>Type</th><th>Description</th><th>Amount</th></tr></thead>
              <tbody>
              <?php foreach ($txns as $t): ?>
              <tr>
                <td><?= date('d M Y', strtotime($t['created_at'])) ?></td>
                <td style="font-family:monospace;font-size:11px;"><?= htmlspecialchars($t['txn_id']) ?></td>
                <td><span class="txn-type-badge badge-<?= strtolower($t['txn_type']) ?>"><?= htmlspecialchars($t['txn_type']) ?></span></td>
                <td><?= htmlspecialchars($t['description']) ?></td>
                <td class="txn-<?= strtolower($t['direction']) ?>">
                  <?= $t['direction'] === 'CREDIT' ? '+' : '-' ?> &#8377;<?= number_format($t['amount'], 2) ?>
                </td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <div>
      <!-- Quick Actions -->
      <div class="card mb-4">
        <div class="card-header">&#9889; Quick Actions</div>
        <div class="card-body">
          <a href="/transfer.php" class="btn btn-primary btn-block mb-2">&#8594; Fund Transfer</a>
          <a href="/support.php" class="btn btn-outline btn-block mb-2">&#128172; Raise Complaint</a>
          <a href="/dashboard.php" class="btn btn-outline btn-block">&#127968; Dashboard</a>
        </div>
      </div>
      <!-- Account Summary -->
      <div class="card">
        <div class="card-header">&#128200; Account Summary</div>
        <div class="card-body">
          <div class="kyc-row"><div class="kyc-label">Account No.</div><div class="kyc-value" style="font-family:monospace;"><?= htmlspecialchars($account['account_number']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">IFSC Code</div><div class="kyc-value"><?= htmlspecialchars($account['ifsc']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Branch</div><div class="kyc-value"><?= htmlspecialchars($account['branch_code']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Currency</div><div class="kyc-value"><?= htmlspecialchars($account['currency']) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Opened On</div><div class="kyc-value"><?= date('d M Y', strtotime($account['created_at'])) ?></div></div>
          <div class="kyc-row"><div class="kyc-label">Total Txns</div><div class="kyc-value"><?= count($txns) ?></div></div>
        </div>
      </div>
    </div>
  </div>

</div>
</div>
<?php include '/var/www/html/includes/footer.php'; ?>
