<?php
/**
 * account.php
 * VULNERABLE: IDOR – account id from URL, NO user_id ownership check (Scenario #3)
 * Columns: account_number, account_type, branch_code, ifsc, balance
 */
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$session = check_auth();
$page_title = 'Account Details - Union Bank of India';

// IDOR: $id taken directly from URL – no ownership check
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { header('Location: /dashboard.php'); exit; }

$db = getDB();

// VULNERABLE: No check that user_id matches session user
$stmt = $db->prepare(
    'SELECT a.id, a.account_number, a.account_type, a.branch_code, a.ifsc, a.balance, a.is_active, a.created_at,
            u.full_name, u.email, u.phone, u.pan, u.aadhaar, u.username, a.user_id
     FROM accounts a
     JOIN users u ON a.user_id = u.id
     WHERE a.id = ?'
);
$stmt->execute([$id]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$account) {
    include '/var/www/html/includes/header.php';
    echo '<div class="alert alert-danger" style="margin:20px;">Account not found.</div>';
    include '/var/www/html/includes/footer.php';
    exit;
}

// KYC (no ownership check either – IDOR exposes full PII)
$kyc = $db->prepare('SELECT * FROM kyc WHERE user_id = ?');
$kyc->execute([$account['user_id'] ?? 0]);
$kyc = $kyc->fetch(PDO::FETCH_ASSOC);

// Last 20 transactions
$txn_st = $db->prepare('SELECT txn_id, txn_type, amount, direction, description, created_at FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 20');
$txn_st->execute([$id]);
$txns = $txn_st->fetchAll(PDO::FETCH_ASSOC);

include '/var/www/html/includes/header.php';
?>

<div class="page-header">
    <h2>&#127970; Account Details</h2>
    <p class="breadcrumb">
        <a href="/dashboard.php">Dashboard</a> &#8250; Account Details
        &nbsp;<a href="/dashboard.php" class="btn btn-sm btn-outline" style="margin-left:8px;">&#8592; Back</a>
    </p>
</div>

<!-- Account card -->
<div class="account-card">
    <div class="acc-type"><?php echo htmlspecialchars($account['account_type'], ENT_QUOTES); ?> Account</div>
    <div style="font-size:18px;font-weight:700;margin-bottom:4px;"><?php echo htmlspecialchars($account['full_name'], ENT_QUOTES); ?></div>
    <div class="acc-number"><?php echo htmlspecialchars($account['account_number'], ENT_QUOTES); ?></div>
    <div style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:12px;">
        <div>
            <div class="balance-label">Available Balance</div>
            <div class="balance-amount">&#8377;<?php echo number_format($account['balance'], 2); ?></div>
        </div>
        <div style="text-align:right;opacity:0.85;font-size:11px;">
            IFSC: <strong><?php echo htmlspecialchars($account['ifsc'], ENT_QUOTES); ?></strong><br>
            Branch: <?php echo htmlspecialchars($account['branch_code'], ENT_QUOTES); ?><br>
            Since: <?php echo date('M Y', strtotime($account['created_at'])); ?>
        </div>
    </div>
    <div class="acc-meta">Status: <?php echo $account['is_active'] ? 'ACTIVE' : 'INACTIVE'; ?> &nbsp;|&nbsp; Currency: INR</div>
</div>

<div class="content-grid">
    <!-- PII exposed via IDOR -->
    <div>
        <div class="card">
            <div class="card-header"><h3>&#128100; Account Holder Details</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">Full Name</span><span class="info-value"><?php echo htmlspecialchars($account['full_name'], ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Username</span><span class="info-value mono"><?php echo htmlspecialchars($account['username'], ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Email</span><span class="info-value"><?php echo htmlspecialchars($account['email'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Phone</span><span class="info-value"><?php echo htmlspecialchars($account['phone'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">PAN Number</span><span class="info-value mono" style="color:var(--accent);font-weight:700;"><?php echo htmlspecialchars($account['pan'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Aadhaar</span><span class="info-value mono" style="color:var(--accent);font-weight:700;"><?php echo htmlspecialchars($account['aadhaar'] ?? '-', ENT_QUOTES); ?></span></div>
            </div>
        </div>
        <?php if ($kyc): ?>
        <div class="card">
            <div class="card-header"><h3>&#128203; KYC Details</h3></div>
            <div class="card-body">
                <div class="info-row"><span class="info-label">Date of Birth</span><span class="info-value"><?php echo htmlspecialchars($kyc['dob'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Gender</span><span class="info-value"><?php echo htmlspecialchars($kyc['gender'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Address</span><span class="info-value" style="text-align:right;max-width:200px;font-size:12px;"><?php echo htmlspecialchars($kyc['address'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">City / State</span><span class="info-value"><?php echo htmlspecialchars(($kyc['city'] ?? '') . ', ' . ($kyc['state'] ?? ''), ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">PIN Code</span><span class="info-value"><?php echo htmlspecialchars($kyc['pincode'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">Occupation</span><span class="info-value"><?php echo htmlspecialchars($kyc['occupation'] ?? '-', ENT_QUOTES); ?></span></div>
                <div class="info-row"><span class="info-label">KYC Status</span><span class="info-value"><span class="badge badge-success"><?php echo htmlspecialchars($kyc['kyc_status'] ?? 'VERIFIED', ENT_QUOTES); ?></span></span></div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Transactions -->
    <div class="card">
        <div class="card-header"><h3>&#128196; Statement (Last 20)</h3></div>
        <div class="card-body no-pad">
            <?php if (!empty($txns)): ?>
            <div class="table-wrapper">
            <table class="data-table">
                <thead><tr><th>Date</th><th>Description</th><th>Mode</th><th>Amount</th></tr></thead>
                <tbody>
                <?php foreach ($txns as $t): ?>
                <tr>
                    <td style="font-size:11px;white-space:nowrap;"><?php echo date('d M Y', strtotime($t['created_at'])); ?></td>
                    <td style="font-size:12px;"><?php echo htmlspecialchars($t['description'] ?? '', ENT_QUOTES); ?></td>
                    <td><span class="badge badge-success"><?php echo htmlspecialchars($t['txn_type'], ENT_QUOTES); ?></span></td>
                    <td class="<?php echo $t['direction'] === 'CREDIT' ? 'text-success' : 'text-danger'; ?>" style="font-weight:600;white-space:nowrap;">
                        <?php echo $t['direction'] === 'CREDIT' ? '+' : '-'; ?>&#8377;<?php echo number_format($t['amount'], 2); ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php else: ?>
            <div class="empty-state"><div class="icon">&#128196;</div><p>No transactions found.</p></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '/var/www/html/includes/footer.php'; ?>
