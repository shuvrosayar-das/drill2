<?php
$page_title = 'Dashboard – Union Bank of India';
require_once '/var/www/html/includes/header.php';
$sess = check_auth(['customer','banker','admin']);
$db   = getDB();
$user_id = $sess['user_id'];

$acc_stmt = $db->prepare('SELECT * FROM accounts WHERE user_id = ? LIMIT 1');
$acc_stmt->execute([$user_id]);
$account = $acc_stmt->fetch();

$txns = [];
if ($account) {
    $t = $db->prepare('SELECT * FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 8');
    $t->execute([$account['id']]);
    $txns = $t->fetchAll();
}

$all_accs = [];
if (in_array($sess['role'], ['admin','banker'])) {
    $all_accs = $db->query('SELECT a.*, u.full_name FROM accounts a JOIN users u ON a.user_id=u.id ORDER BY a.id')->fetchAll();
}
?>

<div class="page-header">
    <h2>Welcome back, <?php echo htmlspecialchars(explode(' ', $sess['full_name'])[0], ENT_QUOTES); ?>!</h2>
    <p>Last login: <?php echo date('d M Y, h:i A'); ?> IST &bull; <?php echo htmlspecialchars($_SERVER['REMOTE_ADDR'] ?? '', ENT_QUOTES); ?></p>
</div>

<?php if ($account): ?>
<!-- Account Card -->
<div class="account-card">
    <div class="acc-type"><?php echo htmlspecialchars(strtoupper($account['account_type']), ENT_QUOTES); ?> Account</div>
    <div class="acc-number"><?php echo htmlspecialchars($account['acc_no'] ?? $account['account_number'] ?? '', ENT_QUOTES); ?></div>
    <div style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:12px;">
        <div>
            <div class="balance-label">Available Balance</div>
            <div class="balance-amount">&#8377;<?php echo number_format($account['balance'], 2); ?></div>
        </div>
        <div style="text-align:right;">
            <div style="font-size:11px;opacity:0.65;">IFSC Code</div>
            <div style="font-size:14px;font-family:monospace;letter-spacing:1px;"><?php echo htmlspecialchars($account['ifsc'] ?? 'UBIN0800001', ENT_QUOTES); ?></div>
            <a href="/account.php?id=<?php echo $account['id']; ?>" class="btn btn-sm btn-secondary" style="margin-top:8px;background:rgba(255,255,255,0.15);border:1px solid rgba(255,255,255,0.3);">View Full Details →</a>
        </div>
    </div>
    <div class="acc-meta">Branch: <?php echo htmlspecialchars($account['branch_code'] ?? 'UBIMUM001', ENT_QUOTES); ?> &nbsp;|&nbsp; Status: ACTIVE &nbsp;|&nbsp; Currency: INR</div>
</div>

<!-- Quick Actions -->
<div class="quick-actions">
    <a href="/transfer.php" class="qaction"><div class="qaction-icon">💸</div><span>Fund Transfer</span></a>
    <a href="/transfer.php?type=neft" class="qaction"><div class="qaction-icon">⚡</div><span>NEFT</span></a>
    <a href="/transfer.php?type=rtgs" class="qaction"><div class="qaction-icon">🏦</div><span>RTGS</span></a>
    <a href="/transfer.php?type=imps" class="qaction"><div class="qaction-icon">📱</div><span>IMPS</span></a>
    <a href="/support.php" class="qaction"><div class="qaction-icon">✉️</div><span>Support</span></a>
</div>
<?php endif; ?>

<!-- Stats -->
<?php if (in_array($sess['role'], ['admin','banker'])): ?>
<?php
$total_users = $db->query("SELECT COUNT(*) FROM users WHERE is_active=1")->fetchColumn();
$total_accs  = $db->query("SELECT COUNT(*) FROM accounts WHERE is_active=1")->fetchColumn();
$total_bal   = $db->query("SELECT SUM(balance) FROM accounts WHERE is_active=1")->fetchColumn();
$open_tickets= $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
?>
<div class="stats-grid" style="margin-bottom:20px;">
    <div class="stat-card">
        <div class="stat-icon blue">👤</div>
        <div><span class="stat-value"><?php echo $total_users; ?></span><span class="stat-label">Active Users</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">🏦</div>
        <div><span class="stat-value"><?php echo $total_accs; ?></span><span class="stat-label">Accounts</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">₹</div>
        <div><span class="stat-value" style="font-size:16px;">&#8377;<?php echo number_format($total_bal/100000, 1); ?>L</span><span class="stat-label">Total Deposits</span></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon darkred">🎫</div>
        <div><span class="stat-value"><?php echo $open_tickets; ?></span><span class="stat-label">Open Tickets</span></div>
    </div>
</div>
<?php endif; ?>

<?php if ($txns): ?>
<div class="card">
    <div class="card-header">
        <h3>Recent Transactions</h3>
        <a href="/account.php?id=<?php echo $account['id'] ?? 0; ?>" class="btn-link">View All →</a>
    </div>
    <div class="card-body no-pad">
        <div class="table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Ref No.</th>
                    <th>Type</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($txns as $t): ?>
            <tr>
                <td><?php echo htmlspecialchars(date('d M Y', strtotime($t['created_at'] ?? 'now')), ENT_QUOTES); ?></td>
                <td><?php echo htmlspecialchars($t['description'] ?? '', ENT_QUOTES); ?></td>
                <td><code><?php echo htmlspecialchars($t['txn_id'] ?? '', ENT_QUOTES); ?></code></td>
                <td><span class="badge <?php echo $t['direction'] === 'CREDIT' ? 'badge-success' : 'badge-warning'; ?>"><?php echo htmlspecialchars($t['txn_type'] ?? '', ENT_QUOTES); ?></span></td>
                <td class="<?php echo $t['direction'] === 'CREDIT' ? 'text-success' : 'text-danger'; ?>">
                    <?php echo $t['direction'] === 'CREDIT' ? '+' : '−'; ?>&#8377;<?php echo number_format($t['amount'], 2); ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php elseif (!$account): ?>
<div class="alert alert-info">No bank account linked to your profile. Please contact your branch.</div>
<?php endif; ?>

<?php if (!empty($all_accs)): ?>
<div class="card">
    <div class="card-header">
        <h3>All Customer Accounts</h3>
        <a href="/admin/index.php" class="btn-link">Admin Panel →</a>
    </div>
    <div class="card-body no-pad">
        <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>#</th><th>Account No.</th><th>Customer</th><th>Type</th><th>Balance</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($all_accs as $i => $a): ?>
            <tr>
                <td><?php echo $i+1; ?></td>
                <td class="mono"><?php echo htmlspecialchars($a['account_number'] ?? $a['acc_no'] ?? '', ENT_QUOTES); ?></td>
                <td><?php echo htmlspecialchars($a['full_name'], ENT_QUOTES); ?></td>
                <td><?php echo htmlspecialchars($a['account_type'], ENT_QUOTES); ?></td>
                <td class="amount">&#8377;<?php echo number_format($a['balance'], 2); ?></td>
                <td><a href="/account.php?id=<?php echo $a['id']; ?>" class="btn btn-sm btn-outline">View</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once '/var/www/html/includes/footer.php'; ?>
