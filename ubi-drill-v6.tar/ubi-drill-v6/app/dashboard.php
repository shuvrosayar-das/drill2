<?php
require_once '/var/www/html/config/database.php';
require_once '/var/www/html/includes/auth.php';
$sess = check_auth(['customer','banker','admin']);
$page_title = 'Dashboard - Union Bank of India';
include '/var/www/html/includes/header.php';
$db   = getDB();

$acc = null;
$txns = [];
$acc_st = $db->prepare('SELECT id, account_number, account_type, branch_code, ifsc, balance FROM accounts WHERE user_id = ? AND is_active = 1 LIMIT 1');
$acc_st->execute([$sess['user_id']]);
$acc = $acc_st->fetch();

if ($acc) {
    $t_st = $db->prepare('SELECT txn_id, txn_type, amount, direction, description, created_at FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 10');
    $t_st->execute([$acc['id']]);
    $txns = $t_st->fetchAll();
}

$all_accs = [];
$stats = [];
if (in_array($sess['role'], ['admin','banker'])) {
    $stats['users']   = $db->query('SELECT COUNT(*) FROM users WHERE is_active=1')->fetchColumn();
    $stats['accs']    = $db->query('SELECT COUNT(*) FROM accounts WHERE is_active=1')->fetchColumn();
    $stats['bal']     = (float)$db->query('SELECT COALESCE(SUM(balance),0) FROM accounts WHERE is_active=1')->fetchColumn();
    $stats['tickets'] = $db->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
    $all_accs = $db->query('SELECT a.id, a.account_number, a.account_type, a.balance, u.full_name FROM accounts a JOIN users u ON a.user_id=u.id WHERE a.is_active=1 ORDER BY a.id')->fetchAll();
}
?>

<div class="page-header">
    <h2>Welcome back, <?php echo htmlspecialchars(explode(' ',$sess['full_name'])[0], ENT_QUOTES); ?>!</h2>
    <p><?php echo date('l, d M Y, h:i A'); ?> IST</p>
</div>

<?php if ($acc): ?>
<div class="account-card">
    <div class="acc-type"><?php echo htmlspecialchars($acc['account_type'],ENT_QUOTES); ?> Account</div>
    <div style="font-size:16px;font-weight:700;margin-bottom:4px;"><?php echo htmlspecialchars($sess['full_name'],ENT_QUOTES); ?></div>
    <div class="acc-number"><?php echo htmlspecialchars($acc['account_number'],ENT_QUOTES); ?></div>
    <div style="display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:12px;">
        <div>
            <div class="balance-label">Available Balance</div>
            <div class="balance-amount">&#8377;<?php echo number_format($acc['balance'],2); ?></div>
        </div>
        <div style="text-align:right;font-size:11px;opacity:.85;">
            IFSC: <strong><?php echo htmlspecialchars($acc['ifsc'],ENT_QUOTES); ?></strong><br>
            Branch: <?php echo htmlspecialchars($acc['branch_code'],ENT_QUOTES); ?>
            <br><a href="/account.php?id=<?php echo (int)$acc['id']; ?>" style="display:inline-block;margin-top:6px;padding:4px 12px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);border-radius:6px;color:#fff;font-size:11px;font-weight:600;text-decoration:none;">View Details &#8594;</a>
        </div>
    </div>
    <div class="acc-meta">Status: ACTIVE &nbsp;|&nbsp; Currency: INR</div>
</div>

<div class="quick-actions">
    <a href="/transfer.php" class="qaction"><div class="qaction-icon">&#128184;</div><span>Transfer</span></a>
    <a href="/transfer.php?type=neft" class="qaction"><div class="qaction-icon">&#9889;</div><span>NEFT</span></a>
    <a href="/transfer.php?type=rtgs" class="qaction"><div class="qaction-icon">&#127970;</div><span>RTGS</span></a>
    <a href="/transfer.php?type=imps" class="qaction"><div class="qaction-icon">&#128241;</div><span>IMPS</span></a>
    <a href="/support.php" class="qaction"><div class="qaction-icon">&#9993;</div><span>Support</span></a>
</div>
<?php elseif ($sess['role'] === 'customer'): ?>
<div class="alert alert-warning">No bank account linked to your profile. Please contact your branch.</div>
<?php endif; ?>

<?php if (!empty($stats)): ?>
<div class="stats-grid">
    <div class="stat-card"><div class="stat-icon blue">&#128100;</div><div><span class="stat-value"><?php echo $stats['users']; ?></span><span class="stat-label">Active Users</span></div></div>
    <div class="stat-card"><div class="stat-icon red">&#127970;</div><div><span class="stat-value"><?php echo $stats['accs']; ?></span><span class="stat-label">Accounts</span></div></div>
    <div class="stat-card"><div class="stat-icon green">&#8377;</div><div><span class="stat-value" style="font-size:15px;">&#8377;<?php echo number_format($stats['bal']/100000,1); ?>L</span><span class="stat-label">Deposits</span></div></div>
    <div class="stat-card"><div class="stat-icon darkred">&#127905;</div><div><span class="stat-value"><?php echo $stats['tickets']; ?></span><span class="stat-label">Open Tickets</span></div></div>
</div>
<?php endif; ?>

<?php if (!empty($txns)): ?>
<div class="card">
    <div class="card-header"><h3>Recent Transactions</h3><a href="/account.php?id=<?php echo (int)($acc['id']??0); ?>" class="btn-link">View All &#8594;</a></div>
    <div class="card-body no-pad">
        <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>Date</th><th>Description</th><th>TXN ID</th><th>Mode</th><th>Amount</th></tr></thead>
            <tbody>
            <?php foreach ($txns as $t): ?>
            <tr>
                <td style="white-space:nowrap;font-size:12px;"><?php echo date('d M Y', strtotime($t['created_at'])); ?></td>
                <td><?php echo htmlspecialchars($t['description']??'',ENT_QUOTES); ?></td>
                <td><code><?php echo htmlspecialchars($t['txn_id']??'',ENT_QUOTES); ?></code></td>
                <td><span class="badge badge-success"><?php echo htmlspecialchars($t['txn_type'],ENT_QUOTES); ?></span></td>
                <td class="<?php echo $t['direction']==='CREDIT'?'text-success':'text-danger'; ?>" style="font-weight:600;white-space:nowrap;">
                    <?php echo $t['direction']==='CREDIT'?'+':'-'; ?>&#8377;<?php echo number_format($t['amount'],2); ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($all_accs)): ?>
<div class="card">
    <div class="card-header"><h3>All Customer Accounts</h3><a href="/admin/index.php" class="btn-link">Admin Panel &#8594;</a></div>
    <div class="card-body no-pad">
        <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>#</th><th>Account No.</th><th>Customer</th><th>Type</th><th>Balance</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($all_accs as $i => $a): ?>
            <tr>
                <td><?php echo $i+1; ?></td>
                <td class="mono"><?php echo htmlspecialchars($a['account_number'],ENT_QUOTES); ?></td>
                <td><?php echo htmlspecialchars($a['full_name'],ENT_QUOTES); ?></td>
                <td><?php echo htmlspecialchars($a['account_type'],ENT_QUOTES); ?></td>
                <td class="amount">&#8377;<?php echo number_format($a['balance'],2); ?></td>
                <td><a href="/account.php?id=<?php echo (int)$a['id']; ?>" class="btn btn-sm btn-outline">View</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once '/var/www/html/includes/footer.php'; ?>
