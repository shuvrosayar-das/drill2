<?php
$page_title = 'Dashboard – Union Bank of India';
require_once '/var/www/html/includes/header.php';
$sess = check_auth(['customer','banker','admin']);
$db = getDB();

$user_id = $sess['user_id'];

// Get primary account (securely – only the logged-in user's account)
$acc_stmt = $db->prepare('SELECT * FROM accounts WHERE user_id = ? LIMIT 1');
$acc_stmt->execute([$user_id]);
$account = $acc_stmt->fetch();

// Get recent transactions for this user's account (secure)
$txn_stmt = null;
$txns = [];
if ($account) {
    $txn_stmt = $db->prepare('SELECT * FROM transactions WHERE acc_no = ? ORDER BY txn_date DESC LIMIT 8');
    $txn_stmt->execute([$account['acc_no']]);
    $txns = $txn_stmt->fetchAll();
}

// For admin/banker – show all accounts (read-only summary)
$all_accs = [];
if (in_array($sess['role'], ['admin','banker'])) {
    $all_accs = $db->query('SELECT a.acc_no, a.balance, a.account_type, u.full_name FROM accounts a JOIN users u ON a.user_id = u.id ORDER BY a.id')->fetchAll();
}
?>

<div class="page-container">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-user">
            <div class="sidebar-avatar"><?= strtoupper(substr($sess['full_name'], 0, 1)) ?></div>
            <div class="sidebar-user-info">
                <strong><?= htmlspecialchars($sess['full_name'], ENT_QUOTES) ?></strong>
                <span class="role-badge role-<?= $sess['role'] ?>"><?= ucfirst($sess['role']) ?></span>
            </div>
        </div>
        <nav class="sidebar-nav">
            <a href="/dashboard.php" class="slink active">&#128202; Dashboard</a>
            <?php if ($account): ?>
            <a href="/account.php?id=<?= $account['id'] ?>" class="slink">&#128179; My Account</a>
            <?php endif; ?>
            <a href="/transfer.php"  class="slink">&#8652; Fund Transfer</a>
            <a href="/support.php"   class="slink">&#128172; Support</a>
            <a href="/profile.php"   class="slink">&#128100; Profile</a>
            <?php if (in_array($sess['role'], ['admin','banker'])): ?>
            <hr>
            <a href="/admin/index.php"   class="slink">&#128736; Admin Panel</a>
            <a href="/admin/tickets.php" class="slink">&#127905; Support Tickets</a>
            <a href="/admin/users.php"   class="slink">&#128101; User Management</a>
            <?php endif; ?>
            <hr>
            <a href="/logout.php" class="slink slink-danger">&#128682; Logout</a>
        </nav>
    </aside>

    <!-- Main content -->
    <div class="page-main">
        <div class="page-header">
            <h1>Welcome back, <?= htmlspecialchars(explode(' ', $sess['full_name'])[0], ENT_QUOTES) ?>!</h1>
            <p class="text-muted">Last login: <?= date('d M Y, h:i A') ?> &bull; <?= htmlspecialchars($_SERVER['REMOTE_ADDR'], ENT_QUOTES) ?></p>
        </div>

        <?php if ($account): ?>
        <!-- Account Summary Card -->
        <div class="account-summary-card">
            <div class="acc-card-left">
                <div class="acc-type"><?= htmlspecialchars(ucfirst($account['account_type']), ENT_QUOTES) ?> Account</div>
                <div class="acc-number">A/C: <?= htmlspecialchars($account['acc_no'], ENT_QUOTES) ?></div>
                <div class="acc-branch">&#128205; <?= htmlspecialchars($account['branch'], ENT_QUOTES) ?></div>
                <div class="acc-ifsc">IFSC: <?= htmlspecialchars($account['ifsc'], ENT_QUOTES) ?></div>
            </div>
            <div class="acc-card-right">
                <div class="balance-label">Available Balance</div>
                <div class="balance-amount">&#8377;<?= number_format($account['balance'], 2) ?></div>
                <a href="/account.php?id=<?= $account['id'] ?>" class="btn btn-gold btn-sm">View Full Details</a>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="/transfer.php" class="qaction">
                <div class="qaction-icon">&#8652;</div>
                <span>Fund Transfer</span>
            </a>
            <a href="/transfer.php?type=neft" class="qaction">
                <div class="qaction-icon">&#9889;</div>
                <span>NEFT</span>
            </a>
            <a href="/transfer.php?type=rtgs" class="qaction">
                <div class="qaction-icon">&#128176;</div>
                <span>RTGS</span>
            </a>
            <a href="/support.php" class="qaction">
                <div class="qaction-icon">&#128172;</div>
                <span>Support</span>
            </a>
            <a href="/profile.php" class="qaction">
                <div class="qaction-icon">&#128100;</div>
                <span>Profile</span>
            </a>
        </div>

        <!-- Recent Transactions -->
        <div class="card">
            <div class="card-header">
                <h3>Recent Transactions</h3>
                <a href="/account.php?id=<?= $account['id'] ?>" class="btn btn-outline btn-sm">View All</a>
            </div>
            <div class="card-body">
                <?php if ($txns): ?>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Description</th>
                                <th>Ref No.</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($txns as $t): ?>
                            <tr>
                                <td><?= htmlspecialchars(date('d M Y', strtotime($t['txn_date'])), ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($t['description'], ENT_QUOTES) ?></td>
                                <td class="mono"><?= htmlspecialchars($t['reference_no'], ENT_QUOTES) ?></td>
                                <td><span class="badge badge-<?= $t['txn_type'] === 'credit' ? 'success' : 'danger' ?>"><?= strtoupper(htmlspecialchars($t['txn_type'], ENT_QUOTES)) ?></span></td>
                                <td class="<?= $t['txn_type'] === 'credit' ? 'text-success' : 'text-danger' ?>">
                                    <?= $t['txn_type'] === 'credit' ? '+' : '-' ?>&#8377;<?= number_format($t['amount'], 2) ?>
                                </td>
                                <td class="mono">&#8377;<?= number_format($t['balance_after'], 2) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <p class="text-muted text-center">No recent transactions found.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-info">No bank account linked to your profile. Please contact your branch.</div>
        <?php endif; ?>

        <?php if (!empty($all_accs)): ?>
        <!-- Admin/Banker: All Accounts -->
        <div class="card" style="margin-top:1.5rem">
            <div class="card-header"><h3>All Customer Accounts</h3></div>
            <div class="card-body">
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead><tr><th>Account No.</th><th>Customer</th><th>Type</th><th>Balance</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($all_accs as $a): ?>
                            <tr>
                                <td class="mono"><?= htmlspecialchars($a['acc_no'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($a['full_name'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars(ucfirst($a['account_type']), ENT_QUOTES) ?></td>
                                <td>&#8377;<?= number_format($a['balance'], 2) ?></td>
                                <td><a href="/api/v1/statement.php?account_number=<?= htmlspecialchars($a['acc_no'], ENT_QUOTES) ?>" class="btn btn-outline btn-sm">Statement</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '/var/www/html/includes/footer.php'; ?>
