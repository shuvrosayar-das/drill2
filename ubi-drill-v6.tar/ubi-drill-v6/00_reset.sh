#!/usr/bin/env bash
# =============================================================
#  UBI Cyber Drill v6 – RESET SCRIPT
#  Reverts everything done by 01_configure.sh and 02_run.sh
#  Does NOT remove packages installed by 00_prereq.sh
#  Does NOT remove the bankops OS user
#  Does NOT re-enable SELinux or firewalld
#
#  After running this script:
#    1. Extract the new tar
#    2. Run sudo bash 01_configure.sh
#    3. Run sudo bash 02_run.sh
# =============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()     { echo -e "${GREEN}[RESET OK]${NC}  $1"; }
warn()   { echo -e "${YELLOW}[SKIP]${NC}     $1"; }
info()   { echo -e "${CYAN}[INFO]${NC}     $1"; }
banner() {
    echo ""
    echo -e "${CYAN}══════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}══════════════════════════════════════════${NC}"
}

[ "$(id -u)" -ne 0 ] && { echo -e "${RED}Must run as root${NC}"; exit 1; }

echo ""
echo -e "${RED}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║       UBI CYBER DRILL v6 — RESET SCRIPT             ║${NC}"
echo -e "${RED}║  This will undo all changes from 01 and 02 scripts  ║${NC}"
echo -e "${RED}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
read -rp "Proceed with full reset? [y/N]: " CONFIRM
[[ "$CONFIRM" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 0; }

# ─── 1. Kill the 02_run.sh monitoring loop ──────────────────
banner "Stopping 02_run.sh monitor process..."
PIDS=$(pgrep -f "02_run.sh" 2>/dev/null || true)
if [ -n "$PIDS" ]; then
    kill $PIDS 2>/dev/null && ok "Killed 02_run.sh monitor (PIDs: $PIDS)"
else
    warn "02_run.sh not currently running"
fi

# ─── 2. Stop Apache ─────────────────────────────────────────
banner "Stopping Apache (httpd)..."
if systemctl is-active httpd &>/dev/null; then
    systemctl stop httpd && ok "Apache stopped"
else
    warn "Apache was not running"
fi

# ─── 3. Stop Telnet service ──────────────────────────────────
banner "Stopping and disabling Telnet service..."
OS_VERSION=$(. /etc/os-release; echo "${VERSION_ID%%.*}")

if [[ "$OS_VERSION" == "7" ]]; then
    if [ -f /etc/xinetd.d/telnet ]; then
        sed -i 's/disable\s*=\s*no/disable = yes/' /etc/xinetd.d/telnet 2>/dev/null || true
        systemctl restart xinetd 2>/dev/null && ok "Telnet disabled via xinetd" || warn "xinetd restart failed"
    else
        warn "/etc/xinetd.d/telnet not found"
    fi
else
    if systemctl is-active telnet.socket &>/dev/null; then
        systemctl stop telnet.socket && ok "telnet.socket stopped"
    else
        warn "telnet.socket was not running"
    fi
    systemctl disable telnet.socket 2>/dev/null && ok "telnet.socket disabled" || warn "telnet.socket was not enabled"
fi

# ─── 4. Remove web application files ────────────────────────
banner "Removing deployed app files from /var/www/html/..."
WEBROOT="/var/www/html"

# Directories deployed by 01_configure.sh
for dir in config includes admin api backup assets db; do
    if [ -d "$WEBROOT/$dir" ]; then
        rm -rf "$WEBROOT/$dir" && ok "Removed $WEBROOT/$dir"
    else
        warn "$WEBROOT/$dir not found"
    fi
done

# Root-level PHP files deployed by 01_configure.sh
for f in index.php login.php logout.php dashboard.php account.php transfer.php support.php profile.php; do
    if [ -f "$WEBROOT/$f" ]; then
        rm -f "$WEBROOT/$f" && ok "Removed $WEBROOT/$f"
    else
        warn "$WEBROOT/$f not found"
    fi
done

# Ransomware note if scenario #5 was run
if [ -f "$WEBROOT/RANSOM_NOTE.txt" ]; then
    rm -f "$WEBROOT/RANSOM_NOTE.txt" && ok "Removed RANSOM_NOTE.txt"
fi

# ─── 5. Remove database and data directory ───────────────────
banner "Removing SQLite database and data directory..."
if [ -d "/var/lib/ubibank" ]; then
    rm -rf /var/lib/ubibank && ok "Removed /var/lib/ubibank (DB + data files)"
else
    warn "/var/lib/ubibank not found"
fi

# Also remove any leftover .enc files if ransomware sim ran
if [ -d "/var/lib/ubibank" ]; then
    find /var/lib/ubibank -name "*.enc" -delete 2>/dev/null && ok "Removed .enc ransomware files"
fi

# ─── 6. Remove Apache vhost config ──────────────────────────
banner "Removing Apache vhost config..."
if [ -f /etc/httpd/conf.d/ubibank.conf ]; then
    rm -f /etc/httpd/conf.d/ubibank.conf && ok "Removed /etc/httpd/conf.d/ubibank.conf"
else
    warn "ubibank.conf not found"
fi

# ─── 7. Revert httpd.conf (remove ServerTokens/Signature lines) ──
banner "Reverting httpd.conf (removing ServerTokens Full / ServerSignature On)..."
HTTPD_CONF="/etc/httpd/conf/httpd.conf"
if [ -f "$HTTPD_CONF" ]; then
    # Remove the exact lines appended by 01_configure.sh
    sed -i '/^ServerTokens Full$/d'  "$HTTPD_CONF"
    sed -i '/^ServerSignature On$/d' "$HTTPD_CONF"
    ok "Removed ServerTokens Full and ServerSignature On from httpd.conf"
else
    warn "$HTTPD_CONF not found"
fi

# Revert ModSecurity if it was changed
if [ -f /etc/httpd/conf.d/mod_security.conf ]; then
    sed -i 's/^SecRuleEngine Off/SecRuleEngine On/' /etc/httpd/conf.d/mod_security.conf 2>/dev/null || true
    ok "ModSecurity SecRuleEngine re-enabled (if it was present)"
fi

# ─── 8. Revert PHP ini settings ─────────────────────────────
banner "Reverting PHP ini settings..."
PHP_INI=$(php --ini 2>/dev/null | grep "Loaded Configuration" | awk '{print $NF}')
[ -z "$PHP_INI" ] && PHP_INI="/etc/php.ini"

if [ -f "$PHP_INI" ]; then
    # Revert session.cookie_httponly back to 1 (secure default)
    sed -i 's/^session\.cookie_httponly\s*=\s*0/session.cookie_httponly = 1/' "$PHP_INI" 2>/dev/null || true

    # Revert display_errors back to Off
    sed -i 's/^display_errors\s*=\s*On/display_errors = Off/' "$PHP_INI" 2>/dev/null || true

    # Revert expose_php back to Off
    sed -i 's/^expose_php\s*=\s*On/expose_php = Off/' "$PHP_INI" 2>/dev/null || true

    ok "PHP ini reverted: cookie_httponly=1, display_errors=Off, expose_php=Off"
    info "PHP ini file: $PHP_INI"
else
    warn "PHP ini file not found at $PHP_INI"
fi

# ─── 9. Remove securetty entries added for Telnet ────────────
banner "Reverting /etc/securetty (removing pts/0, pts/1, pts/2)..."
if [ -f /etc/securetty ]; then
    sed -i '/^pts\/0$/d' /etc/securetty
    sed -i '/^pts\/1$/d' /etc/securetty
    sed -i '/^pts\/2$/d' /etc/securetty
    ok "Removed pts/0, pts/1, pts/2 from /etc/securetty"
else
    warn "/etc/securetty not found"
fi

# ─── 10. Remove Telnet simulation cron job and script ────────
banner "Removing Telnet simulation cron and script..."
# Remove cron entry
crontab -l 2>/dev/null | grep -v "bankops_telnet_sim" | crontab - 2>/dev/null \
    && ok "Removed bankops_telnet_sim from crontab" \
    || warn "No crontab entry found for bankops_telnet_sim"

# Remove the simulation script
if [ -f /usr/local/bin/bankops_telnet_sim.sh ]; then
    rm -f /usr/local/bin/bankops_telnet_sim.sh && ok "Removed /usr/local/bin/bankops_telnet_sim.sh"
else
    warn "/usr/local/bin/bankops_telnet_sim.sh not found"
fi

# ─── 11. Remove drill log files ─────────────────────────────
banner "Removing drill log files..."
for logfile in /var/log/ubi_configure.log /var/log/ubi_run.log; do
    if [ -f "$logfile" ]; then
        rm -f "$logfile" && ok "Removed $logfile"
    else
        warn "$logfile not found"
    fi
done

# ─── 12. Clean up PHP sessions ──────────────────────────────
banner "Clearing PHP session files..."
if [ -d /var/lib/php/sessions ]; then
    find /var/lib/php/sessions -type f -name "sess_*" -delete 2>/dev/null && ok "Cleared PHP session files"
else
    warn "/var/lib/php/sessions not found"
fi

# ─── 13. Verify Apache config is clean ───────────────────────
banner "Verifying Apache config after reset..."
apachectl configtest 2>&1 | grep -i "syntax" && ok "Apache config clean" || warn "Apache config check — review manually"

# ─── Summary ────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║             RESET COMPLETE                          ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  What was removed / reverted:                       ║${NC}"
echo -e "${GREEN}║  ✓ App files deleted from /var/www/html/            ║${NC}"
echo -e "${GREEN}║  ✓ /var/lib/ubibank/ (DB + data) deleted            ║${NC}"
echo -e "${GREEN}║  ✓ /etc/httpd/conf.d/ubibank.conf deleted           ║${NC}"
echo -e "${GREEN}║  ✓ ServerTokens/ServerSignature removed from        ║${NC}"
echo -e "${GREEN}║    httpd.conf                                        ║${NC}"
echo -e "${GREEN}║  ✓ PHP ini reverted (httponly, display_errors)      ║${NC}"
echo -e "${GREEN}║  ✓ securetty pts entries removed                    ║${NC}"
echo -e "${GREEN}║  ✓ Telnet cron + sim script removed                 ║${NC}"
echo -e "${GREEN}║  ✓ telnet.socket stopped and disabled               ║${NC}"
echo -e "${GREEN}║  ✓ Apache stopped                                   ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  What was kept (from 00_prereq.sh):                 ║${NC}"
echo -e "${GREEN}║  • Packages: httpd, php, sqlite3, telnet-server     ║${NC}"
echo -e "${GREEN}║  • OS user: bankops (BankOps@2024)                  ║${NC}"
echo -e "${GREEN}║  • SELinux: permissive (unchanged)                  ║${NC}"
echo -e "${GREEN}║  • firewalld: disabled (unchanged)                  ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  Next steps:                                         ║${NC}"
echo -e "${GREEN}║  1. Extract new tar: tar -xzf ubi-drill-v6.tar.gz   ║${NC}"
echo -e "${GREEN}║  2. sudo bash ubi-drill-v6/01_configure.sh          ║${NC}"
echo -e "${GREEN}║  3. sudo bash ubi-drill-v6/02_run.sh                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
