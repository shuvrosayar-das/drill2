#!/usr/bin/env bash
# =============================================================
#  UBI Cyber Drill v6 – Configuration Script
#  Deploys application, configures vulnerabilities, seeds DB
# =============================================================
set -e
LOGFILE="/var/log/ubi_configure.log"
exec > >(tee -a "$LOGFILE") 2>&1

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()     { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()   { echo -e "${YELLOW}[WARN]${NC}  $1"; }
err()    { echo -e "${RED}[ERR]${NC}   $1"; exit 1; }
info()   { echo -e "${CYAN}[INFO]${NC}  $1"; }
banner() { echo -e "\n${GREEN}══════════════════════════════════════════${NC}"; echo -e "${GREEN}  $1${NC}"; echo -e "${GREEN}══════════════════════════════════════════${NC}"; }

[ "$(id -u)" -ne 0 ] && err "Must run as root"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEBROOT="/var/www/html"
DBDIR="/var/lib/ubibank"
DATADIR="/var/lib/ubibank/data"

banner "Deploying application to $WEBROOT..."
# Remove old deployment if exists
[ -d "$WEBROOT/config" ] && rm -rf "$WEBROOT/config"
[ -d "$WEBROOT/includes" ] && rm -rf "$WEBROOT/includes"
[ -d "$WEBROOT/admin" ] && rm -rf "$WEBROOT/admin"
[ -d "$WEBROOT/api" ] && rm -rf "$WEBROOT/api"
[ -d "$WEBROOT/backup" ] && rm -rf "$WEBROOT/backup"
[ -d "$WEBROOT/assets" ] && rm -rf "$WEBROOT/assets"

# Copy application files
cp -r "$SCRIPT_DIR/app/config"   "$WEBROOT/config"
cp -r "$SCRIPT_DIR/app/includes" "$WEBROOT/includes"
cp -r "$SCRIPT_DIR/app/admin"    "$WEBROOT/admin"
cp -r "$SCRIPT_DIR/app/api"      "$WEBROOT/api"
mkdir -p "$WEBROOT/backup"
cp -r "$SCRIPT_DIR/app/assets"   "$WEBROOT/assets"

# Copy root-level PHP files
for f in index.php login.php logout.php dashboard.php account.php transfer.php support.php profile.php; do
    [ -f "$SCRIPT_DIR/app/$f" ] && cp "$SCRIPT_DIR/app/$f" "$WEBROOT/$f"
done
ok "Application files deployed to $WEBROOT"

banner "Setting up data directory ($DBDIR)..."
mkdir -p "$DBDIR" "$DATADIR"
ok "Directories created"

banner "Configuring Apache (httpd)..."
# Copy Apache vhost config
cp "$SCRIPT_DIR/apache/ubibank.conf" /etc/httpd/conf.d/ubibank.conf

# VULNERABLE: Disable default Apache security headers for realism
# Comment out ModSecurity if present
[ -f /etc/httpd/conf.d/mod_security.conf ] && sed -i 's/^SecRuleEngine On/SecRuleEngine Off/' /etc/httpd/conf.d/mod_security.conf 2>/dev/null || true

# Set ServerTokens to Full (verbose banner – info disclosure)
grep -qxF "ServerTokens Full" /etc/httpd/conf/httpd.conf || echo "ServerTokens Full" >> /etc/httpd/conf/httpd.conf
grep -qxF "ServerSignature On" /etc/httpd/conf/httpd.conf || echo "ServerSignature On" >> /etc/httpd/conf/httpd.conf

ok "Apache configured"

banner "Configuring PHP settings..."
PHP_INI=$(php --ini | grep "Loaded Configuration" | awk '{print $NF}')
[ -z "$PHP_INI" ] && PHP_INI="/etc/php.ini"

# VULNERABLE: Disable HttpOnly on session cookie (allows JS to steal PHPSESSID – Stored XSS scenario #4)
sed -i 's/^session.cookie_httponly\s*=.*/session.cookie_httponly = 0/' "$PHP_INI" 2>/dev/null || true
grep -qF "session.cookie_httponly" "$PHP_INI" || echo "session.cookie_httponly = 0" >> "$PHP_INI"

# VULNERABLE: Enable error display (info disclosure)
sed -i 's/^display_errors\s*=.*/display_errors = On/' "$PHP_INI" 2>/dev/null || true
grep -qF "display_errors" "$PHP_INI" || echo "display_errors = On" >> "$PHP_INI"

# VULNERABLE: expose_php = On (version disclosure)
sed -i 's/^expose_php\s*=.*/expose_php = On/' "$PHP_INI" 2>/dev/null || true

# Session save path
mkdir -p /var/lib/php/sessions
chown apache:apache /var/lib/php/sessions 2>/dev/null || chown www-data:www-data /var/lib/php/sessions 2>/dev/null || true
ok "PHP configured (HttpOnly=0 for XSS drill)"

banner "Initializing SQLite database..."
DB_PATH="$DBDIR/banking.db"

# Run PHP init script to create schema + seed data
php "$SCRIPT_DIR/db/db_init.php" "$DB_PATH" && ok "Database initialized with schema and data" || err "Database initialization failed"

# VULNERABLE: World-readable DB (for hardcoded creds scenario #8)
chmod 644 "$DB_PATH"
ok "DB permissions set to 644 (world-readable – vulnerability #8)"

banner "Setting file permissions..."
# Normal permissions for web files
chown -R apache:apache "$WEBROOT" 2>/dev/null || chown -R www-data:www-data "$WEBROOT" 2>/dev/null || true

# VULNERABLE: config/database.php world-readable (vulnerability #8 - insider threat)
chmod 644 "$WEBROOT/config/database.php"
ok "config/database.php set to 644 (world-readable – vulnerability #8)"

# Backup dir world-readable with directory listing (vulnerability #7)
chmod -R 755 "$WEBROOT/backup"
ok "backup/ set to 755 (directory listing enabled – vulnerability #7)"

# Set DB dir permissions
chown -R apache:apache "$DBDIR" 2>/dev/null || chown -R www-data:www-data "$DBDIR" 2>/dev/null || true
chmod 755 "$DBDIR"
# VULNERABLE: DB world-readable
chmod 644 "$DB_PATH"

banner "Setting data directory permissions (ransomware target #5)..."
# Data files and backup files are generated by db_init.php above
chown -R root:root "$DATADIR" 2>/dev/null || true
chmod -R 600 "$DATADIR" 2>/dev/null || true
ok "Sensitive data files ready at $DATADIR"

banner "Configuring Telnet service (scenario #9)..."
OS_VERSION=$(. /etc/os-release; echo "${VERSION_ID%%.*}")

if [[ "$OS_VERSION" == "7" ]]; then
    # xinetd-based
    if [ -f /etc/xinetd.d/telnet ]; then
        sed -i 's/disable\s*=\s*yes/disable = no/' /etc/xinetd.d/telnet
        systemctl restart xinetd && ok "Telnet enabled via xinetd"
    fi
else
    # systemd socket-based
    systemctl enable telnet.socket 2>/dev/null || true
    systemctl start telnet.socket 2>/dev/null \
        && ok "Telnet socket started" \
        || warn "Telnet socket start failed – check systemctl status telnet.socket"
fi

# Ensure bankops can login via Telnet
grep -qxF "pts/0" /etc/securetty 2>/dev/null || echo "pts/0" >> /etc/securetty
grep -qxF "pts/1" /etc/securetty 2>/dev/null || echo "pts/1" >> /etc/securetty
grep -qxF "pts/2" /etc/securetty 2>/dev/null || echo "pts/2" >> /etc/securetty

banner "Setting up Telnet simulation cron (scenario #9 – passive sniff target)..."
# Create the simulation script
cat > /usr/local/bin/bankops_telnet_sim.sh << 'SIMEOF'
#!/usr/bin/env bash
# Simulates routine Telnet administration by bankops staff
# This creates cleartext credentials visible to passive sniffers
VM_IP=$(ip route get 8.8.8.8 2>/dev/null | awk '/src/{print $7; exit}')
[ -z "$VM_IP" ] && VM_IP="127.0.0.1"

if command -v expect &>/dev/null; then
    /usr/bin/expect -c "
        set timeout 10
        spawn telnet $VM_IP
        expect -re {login|Login}
        send \"bankops\r\"
        expect -re {[Pp]assword}
        send \"BankOps@2024\r\"
        expect -re {\\$|>|#}
        send \"ls /var/www/html/ && echo STATUS:OK\r\"
        expect -re {STATUS:OK}
        send \"exit\r\"
        expect eof
    " 2>/dev/null
elif command -v python3 &>/dev/null; then
    python3 -c "
import socket, time
try:
    s = socket.socket()
    s.settimeout(10)
    s.connect(('$VM_IP', 23))
    time.sleep(2)
    s.recv(4096)
    s.send(b'bankops\r\n')
    time.sleep(1)
    s.recv(4096)
    s.send(b'BankOps@2024\r\n')
    time.sleep(1)
    s.recv(4096)
    s.send(b'ls /var/www/html/\r\n')
    time.sleep(1)
    s.recv(4096)
    s.send(b'exit\r\n')
    s.close()
except: pass
" 2>/dev/null
fi
SIMEOF
chmod +x /usr/local/bin/bankops_telnet_sim.sh

# Schedule cron every 5 minutes for Telnet simulation
(crontab -l 2>/dev/null | grep -v bankops_telnet_sim; echo "*/5 * * * * /usr/local/bin/bankops_telnet_sim.sh") | crontab -
ok "Telnet simulation cron set (every 5 minutes)"

banner "Restarting Apache..."
systemctl restart httpd && ok "Apache restarted" || {
    apachectl configtest 2>&1
    err "Apache failed to restart – check config above"
}

banner "Verifying deployment..."
check() {
    local label="$1"; local path="$2"
    [ -e "$path" ] && ok "$label: $path" || warn "MISSING: $label: $path"
}
check "Index page"     "$WEBROOT/index.php"
check "Login page"     "$WEBROOT/login.php"
check "Dashboard"      "$WEBROOT/dashboard.php"
check "Account page"   "$WEBROOT/account.php"
check "Transfer page"  "$WEBROOT/transfer.php"
check "Support page"   "$WEBROOT/support.php"
check "Admin dir"      "$WEBROOT/admin/index.php"
check "API register"   "$WEBROOT/api/v1/register.php"
check "API accounts"   "$WEBROOT/api/v1/accounts.php"
check "API statement"  "$WEBROOT/api/v1/statement.php"
check "Backup dir"     "$WEBROOT/backup"
check "Config file"    "$WEBROOT/config/database.php"
check "Database"       "$DB_PATH"

echo ""
echo -e "${GREEN}══════════════════════════════════════════${NC}"
echo -e "${GREEN}  Configuration complete!${NC}"
echo -e "${GREEN}  Next step: sudo bash 02_run.sh${NC}"
echo -e "${GREEN}══════════════════════════════════════════${NC}"
